// Copies the screens (public/) from the office version into this Firebase version and
// re-applies the few Firebase-only differences. Run after changing the office screens:
//   node sync-from-office.js
const fs = require('fs');
const path = require('path');

// SYNC_SRC: copy from another folder (e.g. a tested staging copy) instead of the office public/
const SRC = process.env.SYNC_SRC || path.join(__dirname, '..', 'public');
const DST = path.join(__dirname, 'public');

for (const f of fs.readdirSync(SRC)) {
  if (f === 'index.html') continue; // index.html has its own small differences
  fs.copyFileSync(path.join(SRC, f), path.join(DST, f));
}

const appFile = path.join(DST, 'app.js');
let js = fs.readFileSync(appFile, 'utf8').replace(/\r\n/g, '\n');
const edits = [
  // admin: download a full backup from My Account
  ['      <button class="btn primary" id="pw-btn">🔑 Change password</button>\n',
    `      \${u.role === 'admin' ? \`<div class="row"><button class="btn primary" id="pw-btn">🔑 Change password</button>
          <a class="btn" href="/api/admin/backup" download>⬇ Download full backup</a></div>
        <div class="hint" style="margin-top:10px">Backup = complete copy of all data. A copy is also saved automatically in Firebase every evening at 7 PM (last 30 days kept).</div>\`
        : '<button class="btn primary" id="pw-btn">🔑 Change password</button>'}\n`],
  // employee PC setup text: online instead of office server
  ['everything stays safely on this office server.</div>', 'everything stays safely online (HTTPS). Works from office or home.</div>'],
];
for (const [from, to] of edits) {
  if (!js.includes(from)) { console.error('Could not apply Firebase change:', from.slice(0, 60)); process.exit(1); }
  js = js.replace(from, to);
}
fs.writeFileSync(appFile, js);
console.log('Firebase screens updated from the office version.');

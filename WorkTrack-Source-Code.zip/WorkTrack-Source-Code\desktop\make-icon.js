// Draws the WorkTrack app icon (gradient tile + check mark) and saves desktop/worktrack.ico
const fs = require('fs');
const path = require('path');
const zlib = require('zlib');

function crc32(buf) {
  let c, crc = 0xffffffff;
  for (let n = 0; n < buf.length; n++) {
    c = (crc ^ buf[n]) & 0xff;
    for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    crc = (crc >>> 8) ^ c;
  }
  return (crc ^ 0xffffffff) >>> 0;
}
function chunk(type, data) {
  const len = Buffer.alloc(4); len.writeUInt32BE(data.length);
  const td = Buffer.concat([Buffer.from(type), data]);
  const crc = Buffer.alloc(4); crc.writeUInt32BE(crc32(td));
  return Buffer.concat([len, td, crc]);
}
function png(size, rgba) {
  const raw = Buffer.alloc((size * 4 + 1) * size);
  for (let y = 0; y < size; y++) { raw[y * (size * 4 + 1)] = 0; rgba.copy(raw, y * (size * 4 + 1) + 1, y * size * 4, (y + 1) * size * 4); }
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(size, 0); ihdr.writeUInt32BE(size, 4); ihdr[8] = 8; ihdr[9] = 6;
  return Buffer.concat([Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]), chunk('IHDR', ihdr), chunk('IDAT', zlib.deflateSync(raw)), chunk('IEND', Buffer.alloc(0))]);
}

function distSeg(px, py, ax, ay, bx, by) {
  const dx = bx - ax, dy = by - ay;
  const t = Math.max(0, Math.min(1, ((px - ax) * dx + (py - ay) * dy) / (dx * dx + dy * dy)));
  return Math.hypot(px - (ax + t * dx), py - (ay + t * dy));
}

function draw(size) {
  const buf = Buffer.alloc(size * size * 4);
  const S = 4; // supersampling
  const r = size * 0.22, stroke = size * 0.085;
  const c1 = [79, 70, 229], c2 = [124, 58, 237];
  const p1 = [0.28 * size, 0.53 * size], p2 = [0.44 * size, 0.68 * size], p3 = [0.73 * size, 0.35 * size];
  for (let y = 0; y < size; y++) for (let x = 0; x < size; x++) {
    let cover = 0, white = 0;
    for (let sy = 0; sy < S; sy++) for (let sx = 0; sx < S; sx++) {
      const px = x + (sx + 0.5) / S, py = y + (sy + 0.5) / S;
      const qx = Math.max(r - px, px - (size - r), 0), qy = Math.max(r - py, py - (size - r), 0);
      if (Math.hypot(qx, qy) > r) continue;
      cover++;
      if (Math.min(distSeg(px, py, ...p1, ...p2), distSeg(px, py, ...p2, ...p3)) <= stroke / 2) white++;
    }
    const i = (y * size + x) * 4, t = (x + y) / (2 * size);
    const base = c1.map((v, k) => v + (c2[k] - v) * t);
    const w = cover ? white / cover : 0;
    buf[i] = base[0] + (255 - base[0]) * w;
    buf[i + 1] = base[1] + (255 - base[1]) * w;
    buf[i + 2] = base[2] + (255 - base[2]) * w;
    buf[i + 3] = Math.round((cover / (S * S)) * 255);
  }
  return png(size, buf);
}

const sizes = [256, 64, 48, 32, 16];
const images = sizes.map(draw);
const header = Buffer.alloc(6); header.writeUInt16LE(0, 0); header.writeUInt16LE(1, 2); header.writeUInt16LE(sizes.length, 4);
let offset = 6 + 16 * sizes.length;
const dir = sizes.map((s, i) => {
  const e = Buffer.alloc(16);
  e[0] = s === 256 ? 0 : s; e[1] = s === 256 ? 0 : s; e.writeUInt16LE(1, 4); e.writeUInt16LE(32, 6);
  e.writeUInt32LE(images[i].length, 8); e.writeUInt32LE(offset, 12);
  offset += images[i].length;
  return e;
});
fs.writeFileSync(path.join(__dirname, 'worktrack.ico'), Buffer.concat([header, ...dir, ...images]));
fs.writeFileSync(path.join(__dirname, '..', 'public', 'icon-256.png'), images[0]);
console.log('Icon created: desktop/worktrack.ico');

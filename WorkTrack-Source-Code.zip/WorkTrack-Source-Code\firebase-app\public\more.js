// WorkTrack - extra screens: requests (time fix, review, leave, password help), change history,
// breaks, overtime, "how is my progress calculated", sign-in info, forgot password.
// Loaded after app.js and uses its helpers ($, api, modal, esc, dur, state, ...).

// ============================================================ pages in the menu
NAV.admin.splice(NAV.admin.findIndex((n) => n[0] === 'reviews') + 1, 0, ['requests', '📨', 'Requests']);
NAV.admin.splice(NAV.admin.findIndex((n) => n[0] === 'leaves') + 1, 0, ['history', '🕘', 'Change History']);
NAV.employee.splice(NAV.employee.findIndex((n) => n[0] === 'calendar') + 1, 0, ['requests', '📨', 'My Requests']);
ROUTES.requests = { title: 'Requests', render: () => renderRequests() };
ROUTES.history = { title: 'Change History', render: () => renderHistory() };

const REQ_KIND = {
  time: ['🛠', 'Time correction'], review: ['⚖️', 'Task review'], leave: ['🌴', 'Leave request'], password: ['🔑', 'Password help'],
};
const REQ_STATUS = { pending: ['Waiting', 's-on_hold'], approved: ['Approved', 's-completed'], rejected: ['Not approved', 's-overdue'], cancelled: ['Cancelled', 's-pending'] };
const reqBadge = (r) => `<span class="badge ${REQ_STATUS[r.status][1]}">${REQ_STATUS[r.status][0]}</span>`;
const dayLabel = (d) => new Date(d + 'T12:00').toLocaleDateString('en-IN', { weekday: 'short', day: 'numeric', month: 'short' });

// admin: number of waiting requests next to "Requests"
window.extraPills = async () => {
  if (state.user?.role !== 'admin') return;
  try {
    const r = await api('GET', '/api/requests?status=pending');
    const pill = $('[data-pill=requests]');
    if (pill) { pill.textContent = r.length; pill.classList.toggle('hidden', !r.length); }
  } catch { /* ignore */ }
};

// What the request asks for, old -> new
function reqWhat(r) {
  const p = r.payload, o = r.original;
  if (r.kind === 'time') {
    const rows = [];
    if (p.start_time) rows.push(`<div>Start: <s>${fmtDT(o.start_time)}</s> → <b>${fmtDT(p.start_time)}</b></div>`);
    if (p.actual_end) rows.push(`<div>Finish: <s>${fmtDT(o.actual_end)}</s> → <b>${fmtDT(p.actual_end)}</b></div>`);
    if (p.break_minutes) rows.push(`<div>Add a break of <b>${dur(p.break_minutes)}</b> (not counted as work)</div>`);
    return rows.join('');
  }
  if (r.kind === 'review') return `<div>Count this task as on time${o.is_late ? ` <span class="t-sub">(finished ${dur(o.late_by_minutes)} late · plan ${dur(o.planned_minutes)}, took ${dur(o.worked_minutes)})</span>` : ''}</div>`;
  if (r.kind === 'leave') return `<div><b>${p.type === 'half_day' ? 'Half day' : 'Full day leave'}</b>: ${dayLabel(p.from)}${p.to !== p.from ? ` → ${dayLabel(p.to)}` : ''}${p.skip_sundays ? ' <span class="t-sub">(Sundays skipped)</span>' : ''}</div>`;
  if (r.kind === 'password') return '<div>Cannot sign in - needs a temporary password</div>';
  return '';
}

function reqCard(r, admin) {
  const [ico, label] = REQ_KIND[r.kind];
  return `<div class="req-card ${r.status}">
    <div class="req-top"><span class="req-ico">${ico}</span>
      <div class="req-main"><div class="req-title">${label}${r.task_title ? ` · <a href="#" data-open="${r.task_id}">${esc(r.task_title)}</a>` : ''}</div>
        <div class="t-sub">${admin ? `<b>${esc(r.user_name)}</b> · ` : ''}asked ${fmtSmart(r.created_at)}</div></div>
      ${reqBadge(r)}</div>
    <div class="req-what">${reqWhat(r)}</div>
    ${r.message ? `<div class="req-msg">“${esc(r.message)}”</div>` : ''}
    ${r.status !== 'pending' && r.status !== 'cancelled' ? `<div class="req-dec"><b>${r.status === 'approved' ? '✓ Approved' : '✕ Not approved'}</b> by ${esc(r.decided_by_name || 'admin')} · ${fmtSmart(r.decided_at)}${r.decision_note ? `<div>“${esc(r.decision_note)}”</div>` : ''}</div>` : ''}
    ${r.status === 'pending' ? `<div class="req-btns">${admin
      ? `<button class="btn sm danger" data-decide="${r.id}" data-d="rejected">✕ Reject</button><button class="btn sm success" data-decide="${r.id}" data-d="approved">${r.kind === 'password' ? '🔑 Set temporary password' : '✓ Approve'}</button>`
      : `<button class="btn sm" data-cancel-req="${r.id}">Cancel request</button>`}</div>` : ''}
  </div>`;
}

// ============================================================ Requests page
async function renderRequests() {
  const admin = amAdmin();
  const tab = state.reqTab || 'pending';
  const all = await api('GET', '/api/requests');
  const list = tab === 'pending' ? all.filter((r) => r.status === 'pending') : all.filter((r) => r.status !== 'pending');
  const pendingN = all.filter((r) => r.status === 'pending').length;
  $('#view').innerHTML = `
    <div class="page-head"><div><h2>${admin ? 'Requests' : 'My requests'}</h2>
      <div class="muted">${admin ? 'Time corrections, task reviews, leave and password help asked by employees. Your decision and note are saved in the history.'
        : 'Ask for leave here. To correct a time or ask for a review, open the task and use 🛠 Fix time or ⚖ Ask for review.'}</div></div>
      ${admin ? '' : '<div class="right"><button class="btn primary" id="req-leave">🌴 Request leave</button></div>'}</div>
    <div class="card">
      <div class="tabs"><button data-rtab="pending" class="${tab === 'pending' ? 'on' : ''}">Waiting (${pendingN})</button>
        <button data-rtab="done" class="${tab === 'done' ? 'on' : ''}">Decided</button></div>
      <div class="card-b">${list.length ? `<div class="req-list">${list.map((r) => reqCard(r, admin)).join('')}</div>`
        : empty('📭', tab === 'pending' ? 'No requests waiting' : 'No decided requests yet')}</div>
    </div>
    ${admin ? '' : `<div class="card card-b small muted" style="margin-top:16px">
      <b>When to use a request</b><br>
      🛠 <b>Fix time</b> — you forgot to start, pause or finish a task on time. Your admin sees the old and the new time.<br>
      ⚖ <b>Ask for review</b> — a finished task was late for a reason outside your control (power cut, system down, waiting for someone).<br>
      🌴 <b>Leave</b> — days off. Approved leave days are not counted in your progress.</div>`}`;
  $$('[data-rtab]').forEach((b) => b.onclick = () => { state.reqTab = b.dataset.rtab; renderRequests(); });
  $('#req-leave')?.addEventListener('click', () => leaveRequestModal());
  $$('[data-cancel-req]').forEach((b) => b.onclick = async () => {
    if (!(await confirmBox('Cancel this request?', 'Your admin will no longer see it as waiting.', 'Cancel request', 'primary'))) return;
    await api('POST', `/api/requests/${b.dataset.cancelReq}/cancel`); toast('Request cancelled'); renderRequests();
  });
  $$('[data-decide]').forEach((b) => b.onclick = () => decideModal(all.find((r) => r.id === Number(b.dataset.decide)), b.dataset.d));
}

function decideModal(r, decision) {
  const [ico, label] = REQ_KIND[r.kind];
  const approve = decision === 'approved';
  const effect = {
    time: 'The task times will be changed. The original times stay saved in the request and the history.',
    review: 'This task will count as on time (100%) in ratings, on-time % and accuracy.',
    leave: 'These days will be added to Leave & Holidays. Ratings are not reduced on leave days.',
    password: 'They will be signed out everywhere and must choose their own password when they sign in.',
  }[r.kind];
  modal({
    title: `${ico} ${approve ? 'Approve' : 'Reject'}: ${label}`,
    body: `<div class="row" style="margin-bottom:12px">${avatar(r.user_name)}<div><b>${esc(r.user_name)}</b>${r.task_title ? `<div class="t-sub">${esc(r.task_title)}</div>` : ''}</div></div>
      <div class="req-what" style="margin-bottom:10px">${reqWhat(r)}</div>
      ${r.message ? `<div class="callout blue">“${esc(r.message)}”</div>` : ''}
      ${approve ? `<div class="callout green">${effect}</div>` : ''}
      ${approve && r.kind === 'password' ? '<label>Temporary password<input name="password" required minlength="6" autocomplete="off"><div class="hint">Give it to them in person or by phone.</div></label>' : ''}
      <label>Note to ${esc(r.user_name.split(' ')[0])} ${approve ? '(optional)' : '(why not?)'}<textarea name="note" ${approve ? '' : 'required'} placeholder="${approve ? 'e.g. OK, confirmed with the team' : 'e.g. The system log shows the task was started later'}"></textarea></label>`,
    submitText: approve ? (r.kind === 'password' ? '🔑 Set password' : '✓ Approve') : '✕ Reject',
    submitClass: approve ? 'success' : 'danger',
    onSubmit: async (d) => {
      await api('POST', `/api/requests/${r.id}/decide`, { decision, note: d.note, password: d.password });
      toast(approve ? 'Approved' : 'Rejected');
      refresh();
    },
  });
}

// ============================================================ employee: ask for something
function leaveRequestModal() {
  const today = dayKey(new Date());
  modal({
    title: '🌴 Request leave',
    body: `<div class="form-grid">
        <label>From<input type="date" name="from" required value="${today}"></label>
        <label>To<input type="date" name="to" required value="${today}"></label>
      </div>
      <div class="seg" id="lv-type" style="margin-bottom:12px"><button type="button" class="on" data-t="leave">🌴 Full day</button><button type="button" data-t="half_day">½ Half day</button></div>
      <input type="hidden" name="type" value="leave">
      <label class="row" style="gap:8px;font-size:14px;color:var(--text)"><input type="checkbox" name="skip_sundays" checked style="width:auto"> Do not count Sundays</label>
      <label>Reason<textarea name="message" required placeholder="e.g. Family function, doctor appointment"></textarea></label>
      <div class="hint">Your admin approves or rejects it. Approved leave days do not reduce your progress.</div>`,
    submitText: 'Send request',
    onOpen: (form) => {
      $$('[data-t]', form).forEach((b) => b.onclick = () => { $$('[data-t]', form).forEach((x) => x.classList.toggle('on', x === b)); form.elements.type.value = b.dataset.t; });
      form.elements.from.addEventListener('change', () => { if (form.elements.to.value < form.elements.from.value) form.elements.to.value = form.elements.from.value; });
    },
    onSubmit: async (d) => {
      await api('POST', '/api/requests', { kind: 'leave', from: d.from, to: d.to, type: d.type, skip_sundays: !!d.skip_sundays, message: d.message });
      toast('Leave request sent to admin');
      if (location.hash === '#/requests') renderRequests();
    },
  });
}

function fixTimeModal(t) {
  const done = t.status === 'completed';
  modal({
    title: `🛠 Fix time: ${esc(t.title)}`,
    body: `<div class="callout blue">Forgot to start, pause or finish on time? Ask your admin to correct it. The original time is kept in the record.</div>
      <div class="detail-grid" style="grid-template-columns:1fr 1fr 1fr;margin-bottom:12px">
        <div><span>Started</span><b>${fmtDT(t.start_time)}</b></div>
        <div><span>Finished</span><b>${done ? fmtDT(t.actual_end) : '—'}</b></div>
        <div><span>Worked</span><b>${dur(t.worked_minutes)}</b></div></div>
      <label class="row fx-check"><input type="checkbox" name="fix_start"> I really started at…</label>
      <div class="fx-box hidden" data-fx="fix_start">${whenPicker('start_time', t.start_time, { chips: 'past', days: ['yesterday', 'today'] })}</div>
      ${done ? `<label class="row fx-check"><input type="checkbox" name="fix_end"> I really finished at…</label>
      <div class="fx-box hidden" data-fx="fix_end">${whenPicker('actual_end', t.actual_end, { chips: 'past', days: ['yesterday', 'today'] })}</div>` : ''}
      <label class="row fx-check"><input type="checkbox" name="fix_break"> I forgot to pause - I was not working for…</label>
      <div class="fx-box hidden" data-fx="fix_break"><select name="break_minutes">${[5, 10, 15, 20, 30, 45, 60, 90, 120].map((m) => `<option value="${m}">${dur(m)}</option>`).join('')}</select></div>
      <label>What happened?<textarea name="message" required placeholder="e.g. I started at 10:00 but forgot to click Start until 10:40"></textarea></label>`,
    submitText: 'Send to admin',
    onOpen: (form) => {
      initTimePickers(form);
      $$('.fx-check input', form).forEach((c) => c.addEventListener('change', () => $(`[data-fx="${c.name}"]`, form).classList.toggle('hidden', !c.checked)));
    },
    onSubmit: async (d, form) => {
      const body = { kind: 'time', task_id: t.id, message: d.message };
      if (d.fix_start) body.start_time = pickedDate(form, 'start_time').toISOString();
      if (d.fix_end) body.actual_end = pickedDate(form, 'actual_end').toISOString();
      if (d.fix_break) body.break_minutes = Number(d.break_minutes);
      if (!d.fix_start && !d.fix_end && !d.fix_break) throw new Error('Tick what you want to correct');
      await api('POST', '/api/requests', body);
      toast('Correction request sent to admin');
      refresh();
    },
  });
}

function reviewRequestModal(t) {
  modal({
    title: `⚖ Ask for review: ${esc(t.title)}`,
    body: `<div class="callout blue">If this task was late for a reason outside your control, explain it. If your admin agrees, the task counts as <b>on time (100%)</b>.</div>
      <div class="detail-grid" style="grid-template-columns:1fr 1fr 1fr;margin-bottom:12px">
        <div><span>Planned</span><b>${dur(t.planned_minutes)}</b></div>
        <div><span>Took</span><b>${dur(t.worked_minutes)}</b></div>
        <div><span>Result</span><b>${t.is_late ? `Late by ${dur(t.late_by_minutes)}` : 'On time'}</b></div></div>
      <label>Why should it be reviewed?<textarea name="message" required placeholder="e.g. The power was off for 40 minutes. The client changed the file twice."></textarea></label>`,
    submitText: 'Send to admin',
    onSubmit: async (d) => {
      await api('POST', '/api/requests', { kind: 'review', task_id: t.id, message: d.message });
      toast('Review request sent to admin');
      refresh();
    },
  });
}

window.EXTRA_ACTS = { fixtime: fixTimeModal, askreview: reviewRequestModal };

// buttons in the task window (the task owner)
window.taskExtraButtons = (t) => {
  if (amAdmin() || t.user_id !== state.user.id || t.archived_at || t.status === 'pending') return '';
  const waiting = (k) => (t.requests || []).some((r) => r.kind === k && r.status === 'pending');
  return `${waiting('time') ? '' : `<button type="button" class="btn" data-act="fixtime" data-id="${t.id}" data-close>🛠 Fix time</button>`}
    ${t.status === 'completed' && !t.excused && !waiting('review') ? `<button type="button" class="btn" data-act="askreview" data-id="${t.id}" data-close>⚖ Ask for review</button>` : ''}`;
};

// "How this task counts" + its requests, inside the task window
window.taskExtras = (t) => {
  const done = t.status === 'completed';
  const acc = taskAccuracy(t);
  let how = '';
  if (done) {
    const steps = [
      `Planned time: <b>${dur(t.planned_minutes)}</b>`,
      `Time worked: <b>${dur(t.worked_minutes)}</b>${t.hold_minutes ? ` <span class="t-sub">(${dur(t.hold_minutes)} on hold / break is not counted)</span>` : ''}`,
      t.excused ? '✅ Your admin approved a review - this task counts as <b>on time, 100%</b>.'
        : t.worked_minutes <= t.planned_minutes ? 'Finished within the plan → <b>accuracy 100%</b>'
          : `Took longer → accuracy = ${dur(t.planned_minutes)} ÷ ${dur(t.worked_minutes)} = <b>${acc}%</b>`,
      t.excused ? '' : !t.is_late ? 'Finished by the planned end time → <b>on time</b> ✓'
        : t.reason_status === 'accepted' ? `Finished ${dur(t.late_by_minutes)} late, but your reason was accepted → <b>counts as on time</b> ✓`
          : `Finished ${dur(t.late_by_minutes)} after the planned end → <b>late</b>${t.reason_status === 'pending' ? ' (your reason is waiting for review)' : t.reason_status === 'rejected' ? ' (reason not accepted)' : ''}`,
    ].filter(Boolean);
    if (amAdmin() && t.score != null) {
      steps.push(`Rating score (admin only): <b>${t.score}%</b> — ${t.excused || !t.is_late || t.reason_status === 'accepted' ? 'on time or excused = 100%'
        : `planned ÷ worked${t.reason_status === 'rejected' ? ', minus 10 because the reason was rejected' : ''}`}`);
    }
    how = `<div class="how-box"><h4>📐 How this task counts</h4><ul>${steps.map((s) => `<li>${s}</li>`).join('')}</ul>
      ${amAdmin() ? '' : '<a href="#" onclick="event.preventDefault();explainProgress()">How is my progress calculated? →</a>'}</div>`;
  } else if (t.status !== 'pending') {
    how = `<div class="how-box"><h4>📐 How this task will count</h4><ul>
      <li>Plan: <b>${dur(t.planned_minutes)}</b>. Worked so far: <b>${dur(t.worked_minutes)}</b>${t.hold_minutes ? ` (hold / break ${dur(t.hold_minutes)} not counted)` : ''}.</li>
      <li>Finish by <b>${fmtDT(t.effective_expected_end)}</b> to be on time with 100% accuracy.</li></ul></div>`;
  }
  const reqs = t.requests || [];
  return how + (reqs.length ? `<h4 style="margin:6px 0 10px">📨 Requests for this task</h4><div class="req-list">${reqs.map((r) => reqCard(r, false).replace(/<div class="req-btns">[\s\S]*?<\/div>/, '')).join('')}</div>` : '');
};

// ============================================================ explain progress (employee)
window.explainProgress = () => modal({
  title: '📐 How your progress is calculated',
  wide: true,
  body: `<div class="explain">
      <div class="ex-row"><div class="ex-ico">🎯</div><div><b>Accuracy</b> — how close each finished task was to its planned time.
        <ul><li>Finished within the planned time → <b>100%</b></li>
          <li>Took longer → <b>planned ÷ time taken</b>. Example: plan 30 min, took 36 min → 30 ÷ 36 = <b>83%</b></li>
          <li>Your day, week and month show the <b>average</b> of the tasks finished in them.</li></ul></div></div>
      <div class="ex-row"><div class="ex-ico">⏱</div><div><b>On time</b> — a task is on time when it is finished by its planned end time.
        <ul><li>Time on hold and breaks <b>move the end time forward</b> - they never count against you.</li>
          <li>Late, but your delay reason was <b>accepted</b> → counts as on time.</li>
          <li>A review your admin <b>approved</b> → on time and 100% accuracy.</li></ul></div></div>
      <div class="ex-row"><div class="ex-ico">🚫</div><div><b>Not counted</b>
        <ul><li>Pause / hold time and breaks</li><li>Approved leave days and holidays</li><li>Archived tasks (added by mistake)</li></ul></div></div>
      <div class="ex-row"><div class="ex-ico">🛠</div><div><b>Something is not right?</b>
        <ul><li>Forgot to start, pause or finish? Open the task → <b>🛠 Fix time</b>.</li>
          <li>Late because of something outside your control? Open the task → <b>⚖ Ask for review</b>.</li>
          <li>Your admin decides and you see the decision and their note in <b>My requests</b>.</li></ul></div></div>
    </div>`,
  footer: '<button type="button" class="btn primary" data-close>Got it</button>',
});

// ============================================================ breaks + today's worked time (employee Today page)
const BREAK_KIND = { tea: ['☕', 'Tea / short break'], lunch: ['🍽', 'Lunch'], personal: ['🚶', 'Personal'], prayer: ['🙏', 'Prayer'] };
window.initBreakUI = async () => {
  const btn = $('#break-btn'), bar = $('#break-bar');
  if (!btn || !bar) return;
  let cur = null;
  try { cur = await api('GET', '/api/breaks/current'); } catch { return; }
  if (cur) {
    const [ico, label] = BREAK_KIND[cur.kind] || BREAK_KIND.tea;
    btn.classList.add('hidden');
    bar.innerHTML = `<div class="break-bar"><span class="bb-ico">${ico}</span>
      <div><b>You are on a break</b> · ${label} since ${hhmm(cur.started_at)} <span class="t-sub" data-break-since="${cur.started_at}"></span>
      <div class="t-sub">Your tasks are on hold - break time is not counted as work.</div></div>
      <button class="btn primary" id="break-end">▶ Back to work</button></div>`;
    const tickBreak = () => { const el = $('[data-break-since]'); if (el) el.textContent = `(${dur((Date.now() - Date.parse(cur.started_at)) / 60000)})`; };
    tickBreak(); clearInterval(state.breakTimer); state.breakTimer = setInterval(tickBreak, 30000);
    $('#break-end').onclick = async () => {
      try { const r = await api('POST', '/api/breaks/end'); toast(`Welcome back! Break: ${dur(r.minutes)}${r.resumed ? ` · ${r.resumed} task(s) running again` : ''}`); refresh(); } catch (x) { toast(x.message, 'error'); }
    };
  } else {
    bar.innerHTML = '';
    btn.onclick = () => modal({
      title: '☕ Take a break',
      body: `<div class="callout blue">Your running task is put on hold. Break time is not counted as work and does not make a task late.</div>
        <div class="break-kinds">${Object.entries(BREAK_KIND).map(([k, [i, l]]) => `<button type="button" class="break-kind" data-bk="${k}"><span>${i}</span>${l}</button>`).join('')}</div>`,
      footer: '<button type="button" class="btn" data-close>Cancel</button>',
      onOpen: (form, close) => $$('[data-bk]', form).forEach((b) => b.onclick = async () => {
        try { const r = await api('POST', '/api/breaks/start', { kind: b.dataset.bk }); close(); toast(`Break started${r.paused ? ` · ${r.paused} task(s) on hold` : ''}`, 'warn'); refresh(); } catch (x) { toast(x.message, 'error'); }
      }),
    });
  }
};

window.loadDayExtras = async () => {
  const box = $('#day-extras');
  if (!box) return;
  const d0 = new Date(); d0.setHours(0, 0, 0, 0);
  const d1 = new Date(d0); d1.setDate(d1.getDate() + 1);
  try {
    const [r] = await api('GET', `/api/reports/daily?${qs({ from: d0.toISOString(), to: d1.toISOString() })}`);
    if (!r) return;
    const hrs = r.work_hours || 8;
    box.innerHTML = `<div class="day-extras">
      <span title="Time worked on tasks today (hold and breaks not counted)">⏱ Worked <b>${dur(r.worked_minutes || 0)}</b> of ${hrs}h</span>
      <span title="Breaks taken today">☕ Breaks <b>${dur(r.break_minutes || 0)}</b></span>
      <span class="${r.overtime_minutes ? 'ot' : ''}" title="Time worked beyond ${hrs} hours today">⏰ Overtime <b>${r.overtime_minutes ? dur(r.overtime_minutes) : '—'}</b></span></div>`;
  } catch { /* optional */ }
};

// ============================================================ Change History (admin)
const AUDIT_LABEL = {
  created: 'Task created', started: 'Started', paused: 'Put on hold', resumed: 'Resumed', completed: 'Completed', edited: 'Edited',
  reviewed: 'Delay reason reviewed', reason: 'Delay reason updated', archived: 'Archived', restored: 'Restored', deleted: 'Deleted permanently',
  corrected: 'Time corrected', excused: 'Counted as on time', requested: 'Request sent', request_rejected: 'Request not approved',
  request_approved: 'Request approved', request_cancelled: 'Request cancelled', user_created: 'User created', user_updated: 'User details changed',
  user_deactivated: 'User deactivated', user_reactivated: 'User reactivated', password_reset: 'Password reset by admin', password_changed: 'Password changed',
  password_help: 'Asked for password help', signed_out_everywhere: 'Signed out of all devices', signed_out_by_admin: 'Signed out by admin',
  leave_added: 'Leave / holiday added', leave_removed: 'Leave / holiday removed', settings_changed: 'Settings changed',
};
const AUDIT_ICO = { task: '🗂️', user: '👤', leave: '🌴', request: '📨', settings: '⚙️' };

async function renderHistory() {
  const f = state.histFilters || (state.histFilters = { user_id: '', entity: '', q: '', period: 'month' });
  const users = state.users || await api('GET', '/api/users');
  const params = () => ({ user_id: f.user_id, entity: f.entity, q: f.q, ...(f.period === 'all' ? {} : periodRange(f.period)) });
  $('#view').innerHTML = `
    <div class="page-head"><div><h2>Change history</h2><div class="muted">Who changed what, and when. Kept permanently — also after a user is deactivated or a task is deleted.</div></div></div>
    <div class="card">
      <div class="filters">
        <input type="search" id="h-q" placeholder="Search task, name, details…" value="${esc(f.q)}">
        <select id="h-user"><option value="">Everyone</option>${users.map((u) => `<option value="${u.id}" ${String(u.id) === String(f.user_id) ? 'selected' : ''}>${esc(u.name)}${u.active ? '' : ' (deactivated)'}</option>`).join('')}</select>
        <select id="h-entity"><option value="">All changes</option>${[['task', 'Tasks'], ['user', 'Users & passwords'], ['request', 'Requests'], ['leave', 'Leave & holidays'], ['settings', 'Settings']].map(([v, l]) => `<option value="${v}" ${f.entity === v ? 'selected' : ''}>${l}</option>`).join('')}</select>
        <select id="h-period">${[...PERIODS, ['all', 'All time']].map(([v, l]) => `<option value="${v}" ${f.period === v ? 'selected' : ''}>${l}</option>`).join('')}</select>
      </div>
      <div id="h-list"><div class="empty">Loading…</div></div>
    </div>`;
  let rows = [];
  const row = (h) => `<tr ${h.entity === 'task' && h.action !== 'deleted' ? `class="click" data-open="${h.entity_id}"` : ''}>
      <td class="nowrap">${fmtDT(h.at)}</td>
      <td class="nowrap"><b>${esc(h.actor_name)}</b></td>
      <td><span class="hist-act">${AUDIT_ICO[h.entity] || '•'} ${esc(AUDIT_LABEL[h.action] || h.action)}</span></td>
      <td>${h.label ? `<div class="t-title">${esc(h.label)}</div>` : ''}${h.subject_name && h.subject_name !== h.actor_name ? `<div class="t-sub">for ${esc(h.subject_name)}</div>` : ''}</td>
      <td class="hist-det">${esc(h.details)}</td></tr>`;
  const draw = (more) => {
    $('#h-list').innerHTML = rows.length ? `<div class="table-wrap"><table><thead><tr><th>When</th><th>Who</th><th>What</th><th>Record</th><th>Details</th></tr></thead>
      <tbody>${rows.map(row).join('')}</tbody></table></div>
      <div class="card-b" style="display:flex;justify-content:space-between;align-items:center"><span class="t-sub">${rows.length} change(s)</span>${more ? '<button class="btn sm" id="h-more">Load older</button>' : ''}</div>`
      : empty('🕘', 'No changes found');
    $('#h-more')?.addEventListener('click', load.bind(null, true));
  };
  const load = async (older = false) => {
    const batch = await api('GET', `/api/audit?${qs({ ...params(), before: older && rows.length ? rows[rows.length - 1].id : '' })}`);
    rows = older ? rows.concat(batch) : batch;
    draw(batch.length === 200);
  };
  const bind = (id, key, ev = 'change') => $(id).addEventListener(ev, (e) => { f[key] = e.target.value; load(); });
  bind('#h-user', 'user_id'); bind('#h-entity', 'entity'); bind('#h-period', 'period');
  let tmr; $('#h-q').addEventListener('input', (e) => { clearTimeout(tmr); tmr = setTimeout(() => { f.q = e.target.value; load(); }, 300); });
  await load();
}

// ============================================================ Account: sign-in period + sign out
window.renderSessionCard = async () => {
  const box = $('#session-card');
  if (!box) return;
  let s = null;
  try { s = (await api('GET', '/api/me')).session; } catch { return; }
  const ends = s && s.expires_at ? new Date(s.expires_at) : null;
  box.innerHTML = `<h3 style="margin-bottom:6px">🔐 Sign-in</h3>
    <div class="muted" style="margin-bottom:12px">You stay signed in for <b>${s ? s.hours : 12} hours</b> after you sign in. After that you sign in again with your password.</div>
    ${ends ? `<div class="detail-grid" style="grid-template-columns:1fr 1fr;margin-bottom:14px"><div><span>This sign-in ends</span><b>${fmtSmart(ends.toISOString())}</b></div>
      <div><span>Time left</span><b>${dur((ends - Date.now()) / 60000)}</b></div></div>` : ''}
    <div class="row"><button class="btn" id="so-me">Log out</button>
      <button class="btn danger" id="so-all" title="Use this if you signed in on a shared or lost computer">Sign out of all devices</button></div>
    <div class="hint" style="margin-top:8px">Used a shared computer, or lost a device? “Sign out of all devices” ends every sign-in, including this one.</div>`;
  $('#so-me').onclick = () => $('#logout-btn').click();
  $('#so-all').onclick = async () => {
    if (!(await confirmBox('Sign out of all devices?', 'Every computer where you are signed in will be signed out, including this one.', 'Sign out everywhere'))) return;
    await api('POST', '/api/me/signout-all').catch(() => {});
    location.hash = ''; showLogin(); toast('Signed out of all devices');
  };
};

// ============================================================ login: forgot password
$('#forgot-link')?.addEventListener('click', (e) => {
  e.preventDefault();
  modal({
    title: '🔑 Forgot your password?',
    body: `<div class="callout blue">Your admin will get a request and give you a <b>temporary password</b>. You then choose your own password when you sign in.</div>
      <label>Your username<input name="username" required autocomplete="username" value="${esc($('#login-form [name=username]').value)}"></label>
      <label>Message for the admin (optional)<textarea name="message" placeholder="e.g. I am at my desk, please call me"></textarea></label>`,
    submitText: 'Send request',
    onSubmit: async (d) => { const r = await api('POST', '/api/password-help', d); toast(r.message); },
  });
});

/* WorkTrack - Office Task Manager (frontend) */
'use strict';

// ============================================================ basics
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const state = { user: null, users: [], period: 'month', watch: [], notified: new Set(), refreshTimer: null, unread: new Map(), unreadRows: [], unreadReady: false, shownNotif: new Set() };

const esc = (v) => String(v ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const initials = (n) => String(n || '?').split(/\s+/).map((p) => p[0]).slice(0, 2).join('').toUpperCase();
const pad = (n) => String(n).padStart(2, '0');

async function api(method, url, body) {
  const res = await fetch(url, {
    method, headers: body ? { 'Content-Type': 'application/json' } : {},
    body: body ? JSON.stringify(body) : undefined, credentials: 'same-origin',
  });
  let data = null;
  try { data = await res.json(); } catch { /* empty */ }
  if (res.status === 401 && url !== '/api/login') { showLogin(); throw new Error('Session expired, please log in again'); }
  if (!res.ok) throw new Error((data && data.error) || `Request failed (${res.status})`);
  return data;
}

function toast(msg, type = 'ok') {
  const el = document.createElement('div');
  el.className = `toast ${type}`;
  el.textContent = msg;
  $('#toasts').appendChild(el);
  setTimeout(() => el.remove(), type === 'error' ? 6000 : 3500);
}

// ============================================================ formatting
const fmtDT = (iso) => (iso ? new Date(iso).toLocaleString('en-IN', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit', hour12: true }) : '—');
const fmtDate = (iso) => (iso ? new Date(iso).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' }) : '—');
function fmtSmart(iso) {
  if (!iso) return '—';
  const d = new Date(iso);
  const t = d.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', hour12: true });
  return d.toDateString() === new Date().toDateString() ? `Today, ${t}` : fmtDT(iso);
}
function dur(min) {
  if (min == null || Number.isNaN(min)) return '—';
  min = Math.max(0, Math.round(min));
  if (min < 60) return `${min}m`;
  const h = Math.floor(min / 60), m = min % 60;
  if (h < 24) return `${h}h${m ? ` ${m}m` : ''}`;
  return `${Math.floor(h / 24)}d ${h % 24}h`;
}
function hms(ms) {
  const s = Math.max(0, Math.floor(ms / 1000));
  return `${pad(Math.floor(s / 3600))}:${pad(Math.floor((s % 3600) / 60))}:${pad(s % 60)}`;
}
const toLocalInput = (d) => {
  d = d instanceof Date ? d : new Date(d);
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
};
const fromLocal = (v) => (v ? new Date(v).toISOString() : null);

const STATUS_LABEL = { pending: 'Planned', in_progress: 'In Progress', on_hold: 'On Hold', completed: 'Completed' };
const PRIORITY_LABEL = { urgent: 'Urgent', high: 'High', medium: 'Medium', low: 'Low' };
const REASON_LABEL = { pending: 'Reason: Pending review', accepted: 'Reason accepted', rejected: 'Reason rejected' };

const prBadge = (p) => `<span class="badge p-${p}">${PRIORITY_LABEL[p] || p}</span>`;
function stBadges(t) {
  if (t.archived_at) return '<span class="badge s-archived">🗃 Archived</span>';
  let h = `<span class="badge s-${t.status}">${STATUS_LABEL[t.status]}</span>`;
  if (t.overdue) h += ` <span class="badge s-overdue">Overdue ${dur(t.late_by_minutes)}</span>`;
  if (t.is_late) h += ` <span class="badge s-overdue">Late ${dur(t.late_by_minutes)}</span>`;
  return h;
}
const scoreColor = (s) => (s == null ? '#cbd5e1' : s >= 90 ? 'var(--green)' : s >= 75 ? 'var(--primary)' : s >= 60 ? 'var(--amber)' : 'var(--red)');
const scoreCell = (s) => (s == null ? '<span class="muted">—</span>'
  : `<div class="score-cell"><b>${s}%</b><div class="bar" style="flex:1"><i style="width:${s}%;background:${scoreColor(s)}"></i></div></div>`);
const stars = (n) => `<span class="stars">${'★'.repeat(n)}<span class="off">${'★'.repeat(5 - n)}</span></span>`;
const amAdmin = () => state.user?.role === 'admin';
const gradeText = (s) => (s >= 90 ? 'Excellent' : s >= 75 ? 'Good' : s >= 60 ? 'Average' : s >= 40 ? 'Needs improvement' : 'Poor');
const avatar = (name, cls = '') => `<div class="avatar ${cls}">${esc(initials(name))}</div>`;
const empty = (icon, text) => `<div class="empty"><div class="e-ico">${icon}</div>${text}</div>`;

function periodRange(p) {
  const now = new Date();
  const d0 = new Date(now); d0.setHours(0, 0, 0, 0);
  let from = null;
  if (p === 'today') from = d0;
  else if (p === 'week') { from = new Date(d0); from.setDate(from.getDate() - ((from.getDay() + 6) % 7)); }
  else if (p === 'month') from = new Date(now.getFullYear(), now.getMonth(), 1);
  else if (p === 'lastmonth') {
    from = new Date(now.getFullYear(), now.getMonth() - 1, 1);
    return { from: from.toISOString(), to: new Date(now.getFullYear(), now.getMonth(), 1).toISOString() };
  } else if (p === '30d') { from = new Date(d0); from.setDate(from.getDate() - 30); }
  return { from: from ? from.toISOString() : '', to: '' };
}
const PERIODS = [['today', 'Today'], ['week', 'This Week'], ['month', 'This Month'], ['lastmonth', 'Last Month'], ['30d', 'Last 30 Days'], ['all', 'All Time']];
const periodSelect = (id = 'period') => `<select id="${id}" style="width:auto">${PERIODS.map(([v, l]) => `<option value="${v}" ${state.period === v ? 'selected' : ''}>${l}</option>`).join('')}</select>`;
const qs = (o) => new URLSearchParams(Object.entries(o).filter(([, v]) => v !== '' && v != null)).toString();

// ============================================================ modal
function modal({ title, body, submitText = 'Save', submitClass = 'primary', wide = false, onSubmit, footer, locked = false, onOpen }) {
  const root = $('#modal-root');
  const back = document.createElement('div');
  back.className = 'modal-back';
  back.innerHTML = `
    <form class="modal ${wide ? 'wide' : ''}" novalidate>
      <div class="modal-h"><h3>${title}</h3>${locked ? '' : '<button type="button" class="icon-btn" data-close>✕</button>'}</div>
      <div class="modal-b">${body}<div class="form-error"></div></div>
      <div class="modal-f">${footer ?? `${locked ? '' : '<button type="button" class="btn" data-close>Cancel</button>'}
        ${onSubmit ? `<button type="submit" class="btn ${submitClass}">${submitText}</button>` : ''}`}</div>
    </form>`;
  root.appendChild(back);
  const form = $('form', back);
  const close = () => back.remove();
  if (!locked) {
    back.addEventListener('mousedown', (e) => { if (e.target === back) close(); });
    $$('[data-close]', back).forEach((b) => b.addEventListener('click', close));
  }
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    if (!onSubmit) return;
    const btn = $('button[type=submit]', form);
    const err = $('.form-error', form);
    err.textContent = '';
    btn.disabled = true;
    try {
      const data = Object.fromEntries(new FormData(form));
      const keep = await onSubmit(data, form, e.submitter);
      if (keep !== true) close();
    } catch (ex) {
      err.textContent = ex.message;
    } finally { btn.disabled = false; }
  });
  setTimeout(() => { const f = $('input:not([type=hidden]),textarea,select', form); if (f) f.focus(); }, 30);
  if (onOpen) onOpen(form, close);
  return { form, close };
}
const confirmBox = (title, text, okText = 'Yes', cls = 'danger') => new Promise((resolve) => {
  const m = modal({ title, body: `<p style="margin:0">${text}</p>`, submitText: okText, submitClass: cls, onSubmit: () => resolve(true) });
  $$('[data-close]', m.form.parentElement).forEach((b) => b.addEventListener('click', () => resolve(false)));
});

// ============================================================ auth
function showLogin() {
  state.user = null;
  $('#app').classList.add('hidden');
  $('#login-screen').classList.remove('hidden');
  $('#modal-root').innerHTML = '';
  $('#alerts').innerHTML = '';
}

$('#login-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const f = Object.fromEntries(new FormData(e.target));
  $('#login-error').textContent = '';
  try {
    const { user } = await api('POST', '/api/login', f);
    e.target.reset();
    await startApp(user);
  } catch (ex) { $('#login-error').textContent = ex.message; }
});

$('#logout-btn').addEventListener('click', async () => {
  await api('POST', '/api/logout').catch(() => {});
  location.hash = '';
  showLogin();
});

function passwordModal(forced) {
  modal({
    title: forced ? 'Set your own password' : 'Change password',
    locked: forced,
    body: `${forced ? '<div class="callout blue">🔑 You signed in with a <b>temporary password</b> from your admin. Please choose your own password to continue.</div>' : ''}
      <label>${forced ? 'Temporary password' : 'Current password'}<input type="password" name="current" required autocomplete="current-password"></label>
      <label>New password<input type="password" name="next" required minlength="8" autocomplete="new-password"><div class="hint">At least 8 characters, with letters and numbers. Do not share it with anyone.</div></label>
      <label>Confirm new password<input type="password" name="confirm" required autocomplete="new-password"></label>
      ${forced ? '<div class="t-sub">Not you? <a href="#" id="pw-logout">Log out</a></div>' : '<div class="t-sub">Your other devices will be signed out.</div>'}`,
    submitText: forced ? 'Save and continue' : 'Update password',
    onOpen: (form) => $('#pw-logout', form)?.addEventListener('click', async (e) => { e.preventDefault(); await api('POST', '/api/logout').catch(() => {}); location.reload(); }),
    onSubmit: async (d) => {
      if (d.next !== d.confirm) throw new Error('New passwords do not match');
      await api('POST', '/api/me/password', d);
      if (state.user) state.user.must_change_password = false;
      toast('Password updated');
      if (forced) setTimeout(() => location.reload(), 600);
    },
  });
}

// ============================================================ app shell
const NAV = {
  admin: [
    ['label', 'Overview'],
    ['dashboard', '🏠', 'Overview'],
    ['daily', '📅', 'Daily Report'],
    ['label', 'Work'],
    ['tasks', '🗂️', 'All Tasks'],
    ['reviews', '📝', 'Delay Reviews'],
    ['label', 'Team'],
    ['performance', '📈', 'Office Progress'],
    ['employees', '👥', 'Employees'],
    ['leaves', '🌴', 'Leave & Holidays'],
    ['label', 'Account'],
    ['profile', '⚙️', 'My Account'],
  ],
  // employees get only 3 simple pages
  employee: [
    ['label', 'My work'],
    ['my', '🏠', 'Today'],
    ['calendar', '🗓️', 'Calendar'],
    ['label', 'Account'],
    ['profile', '⚙️', 'Account'],
  ],
};

async function startApp(user) {
  state.user = user;
  $('#login-screen').classList.add('hidden');
  $('#app').classList.remove('hidden');
  $('#me-avatar').textContent = initials(user.name);
  $('#me-name').textContent = user.name;
  $('#me-role').textContent = user.role === 'admin' ? 'Administrator' : (user.designation || 'Employee');
  // (state.user stays empty, so the background checks wait until the password is set)
  if (user.must_change_password) { state.user = null; $('#nav').innerHTML = ''; $('#view').innerHTML = ''; $('#top-action').innerHTML = ''; passwordModal(true); return; }
  if (user.role === 'admin') state.users = await api('GET', '/api/users');
  renderNav();
  // employees add tasks from their simple "Today" page; the top button is only for admin
  $('#top-action').innerHTML = user.role === 'admin' ? '<button class="btn primary sm" id="top-new">＋ Assign task</button>' : '';
  if ($('#top-new')) $('#top-new').onclick = () => taskFormModal();
  state.unread = new Map(); state.unreadRows = []; state.unreadReady = false; state.pendingMine = null; state.overdueSeen = null;
  pollUnread();
  state.shownNotif = new Set(); $('#alerts').innerHTML = '';
  pollNotifications();
  if (!location.hash || !routeAllowed(location.hash)) location.hash = user.role === 'admin' ? '#/dashboard' : '#/my';
  else router();
}

function routeAllowed(hash) {
  const page = hash.replace(/^#\//, '').split('/')[0];
  const allowed = NAV[state.user.role].filter((n) => n[0] !== 'label').map((n) => n[0]);
  return allowed.includes(page) || (state.user.role === 'admin' && page === 'employee');
}

async function renderNav() {
  const items = NAV[state.user.role];
  $('#nav').innerHTML = items.map((n) => (n[0] === 'label'
    ? `<div class="nav-label">${n[1]}</div>`
    : `<a href="#/${n[0]}" data-page="${n[0]}"><span class="ico">${n[1]}</span>${n[2]}<span class="pill hidden" data-pill="${n[0]}"></span></a>`)).join('');
  updateNavActive();
  updatePills();
}
function updateNavActive() {
  const page = location.hash.replace(/^#\//, '').split('/')[0];
  $$('#nav a').forEach((a) => a.classList.toggle('active', a.dataset.page === page || (page === 'employee' && a.dataset.page === 'employees')));
}
async function updatePills() {
  if (state.user?.role !== 'admin') return;
  try {
    const r = await api('GET', '/api/tasks?reason_status=pending');
    const pill = $('[data-pill=reviews]');
    if (pill) { pill.textContent = r.length; pill.classList.toggle('hidden', !r.length); }
    window.extraPills?.();
  } catch { /* ignore */ }
}

$('#menu-btn').addEventListener('click', () => $('#sidebar').classList.toggle('open'));
$('#nav').addEventListener('click', () => $('#sidebar').classList.remove('open'));

const ROUTES = {
  daily: { title: 'Daily Report', render: renderDailyReport },
  dashboard: { title: 'Overview', render: renderAdminDashboard },
  tasks: { title: 'All Tasks', render: renderAllTasks },
  reviews: { title: 'Delay Reviews', render: renderReviews },
  performance: { title: 'Office Progress', render: renderPerformance },
  employees: { title: 'Employees', render: renderEmployees },
  leaves: { title: 'Leave & Holidays', render: renderLeaves },
  employee: { title: 'Employee Report', render: renderEmployeeReport },
  my: { title: 'Today', render: renderMyDashboard },
  calendar: { title: 'Calendar', render: renderMyCalendar },
  mytasks: { title: 'My Tasks', render: renderMyTasks },
  myperf: { title: 'My Performance', render: renderMyPerformance },
  profile: { title: 'My Account', render: renderProfile },
};

async function router() {
  if (!state.user) return;
  if (!routeAllowed(location.hash)) { location.hash = state.user.role === 'admin' ? '#/dashboard' : '#/my'; return; }
  const [page, arg] = location.hash.replace(/^#\//, '').split('/');
  const r = ROUTES[page];
  clearInterval(state.refreshTimer);
  $('#page-title').textContent = r.title;
  updateNavActive();
  try { await r.render(arg); } catch (e) { $('#view').innerHTML = `<div class="callout red">${esc(e.message)}</div>`; }
}
window.addEventListener('hashchange', router);
const refresh = () => { router(); updatePills(); };

// ============================================================ live timers & reminders
function liveAttrs(t) {
  return `data-start="${t.start_time}" data-expected="${t.expected_end}" data-paused="${t.paused_minutes || 0}" data-pausedat="${t.paused_at || ''}" data-status="${t.status}"`;
}
function tick() {
  $('#clock').textContent = new Date().toLocaleString('en-IN', { weekday: 'short', day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: true });
  const now = Date.now();
  $$('[data-live]').forEach((el) => {
    const start = Date.parse(el.dataset.start), exp = Date.parse(el.dataset.expected);
    let paused = Number(el.dataset.paused || 0) * 60000;
    const onHold = el.dataset.status === 'on_hold';
    if (onHold && el.dataset.pausedat) paused += now - Date.parse(el.dataset.pausedat);
    const worked = Math.max(0, now - start - paused);
    // hold time stops the clock: the deadline moves forward by every minute spent on hold
    const effExp = exp + paused;
    const late = !onHold && now > effExp;
    const kind = el.dataset.live;
    if (kind === 'timer') { el.textContent = hms(worked); el.classList.toggle('late', late); el.classList.toggle('frozen', onHold); }
    else if (kind === 'remain' && el.dataset.hi) {
      // short wording for the employee's main card
      el.textContent = onHold ? '⏸ Paused — time is not counted' : late ? `${dur((now - effExp) / 60000)} over the planned time` : `${dur((effExp - now) / 60000)} remaining`;
      el.style.color = late ? 'var(--red)' : ''; el.style.fontWeight = '700';
    } else if (kind === 'remain') {
      el.textContent = onHold ? `⏸ Clock stopped · ${dur(Math.max(0, effExp - now) / 60000)} left when resumed`
        : late ? `Overdue by ${dur((now - effExp) / 60000)}` : `${dur((effExp - now) / 60000)} left`;
      el.style.color = late ? 'var(--red)' : onHold ? 'var(--amber)' : ''; el.style.fontWeight = late || onHold ? '700' : '';
    } else if (kind === 'holdfor') {
      el.textContent = el.dataset.pausedat ? dur((now - Date.parse(el.dataset.pausedat)) / 60000) : '';
    } else if (kind === 'progress') {
      el.firstElementChild.style.width = `${Math.min(100, (worked / Math.max(60000, exp - start)) * 100)}%`;
      el.classList.toggle('late', late); el.classList.toggle('hold', onHold);
    }
  });
  checkPlanReminders(now);
  // Reminders for the employee's own running tasks (deadline includes time spent on hold)
  for (const t of state.watch) {
    const left = (Date.parse(t.expected_end) + (t.paused_minutes || 0) * 60000 - now) / 60000;
    if (left <= remindMinutes() && left > 0 && !state.notified.has(`soon-${t.id}`) && onceForTask(`soon-${t.id}`)) {
      showDeadlineSoon(t, left);
    }
    // planned time is over: ask "is it done?" - and ask again every 15 minutes until answered
    if (left <= 0) {
      const round = Math.floor(-left / 15);
      if (!state.notified.has(`over-${t.id}-${round}`)) {
        state.notified.add(`over-${t.id}-${round}`);
        showOvertimeCard(t, round);
      }
    }
  }
}
setInterval(tick, 1000);

// ============================================================ shared task UI
function taskActions(t, compact = true) {
  const mine = t.user_id === state.user.id;
  const sm = compact ? 'sm' : '';
  if (t.archived_at) return state.user.role === 'admin' ? `<button type="button" class="btn ${sm}" data-act="restore" data-id="${t.id}">↩ Restore</button>` : '';
  const b = [];
  if (mine) {
    if (t.status === 'pending') b.push(`<button class="btn primary ${sm}" data-act="start" data-id="${t.id}">▶ Start</button>`);
    if (t.status === 'in_progress') b.push(`<button class="btn warn ${sm}" data-act="pause" data-id="${t.id}">⏸ Hold / New work</button>`);
    if (t.status === 'on_hold') b.push(`<button class="btn primary ${sm}" data-act="resume" data-id="${t.id}">▶ Resume</button>`);
    if (t.status === 'in_progress' || t.status === 'on_hold') b.push(`<button class="btn success ${sm}" data-act="complete" data-id="${t.id}">✓ Complete</button>`);
    if (t.status === 'completed' && t.is_late && t.reason_status !== 'accepted') b.push(`<button class="btn ${sm}" data-act="reason" data-id="${t.id}">✎ Reason</button>`);
  }
  if (state.user.role === 'admin' && t.reason_status === 'pending') b.push(`<button class="btn warn ${sm}" data-act="review" data-id="${t.id}">Review</button>`);
  return b.join(' ');
}

function taskTable(tasks, { showUser = false, emptyText = 'No tasks found' } = {}) {
  if (!tasks.length) return empty('🗒️', emptyText);
  return `<div class="table-wrap"><table>
    <thead><tr><th>Task</th>${showUser ? '<th>Employee</th>' : ''}<th>Priority</th><th>Status</th><th>Start</th><th>Expected End</th><th>Actual End</th><th>Worked / Planned</th>${amAdmin() ? '<th>Score</th>' : ''}<th></th></tr></thead>
    <tbody>${tasks.map((t) => `
      <tr class="click" data-open="${t.id}">
        <td><div class="t-title">${esc(t.title)}</div>
          <div class="t-sub">${t.category ? esc(t.category) + ' · ' : ''}${t.parent_title ? `↳ came in during "${esc(t.parent_title)}" · ` : ''}${t.assigned_by_name ? `Assigned by ${esc(t.assigned_by_name)}` : 'Self-added'}</div>
          ${t.delay_reason ? `<div class="t-sub" style="color:var(--amber)">Reason: ${esc(t.delay_reason.slice(0, 80))}${t.delay_reason.length > 80 ? '…' : ''}</div>` : ''}</td>
        ${showUser ? `<td class="nowrap"><div class="row" style="gap:8px">${avatar(t.user_name, 'sm')}${esc(t.user_name)}</div></td>` : ''}
        <td>${prBadge(t.priority)}</td>
        <td>${stBadges(t)}${t.reason_status !== 'none' ? `<div style="margin-top:4px"><span class="badge r-${t.reason_status}">${REASON_LABEL[t.reason_status]}</span></div>` : ''}</td>
        <td class="nowrap">${fmtSmart(t.start_time)}</td>
        <td class="nowrap">${fmtSmart(t.expected_end)}</td>
        <td class="nowrap">${t.status === 'completed' ? fmtSmart(t.actual_end) : (t.status === 'pending' ? '—' : `<span data-live="remain" ${liveAttrs(t)}></span>`)}</td>
        <td class="nowrap">${dur(t.worked_minutes)} / ${dur(t.planned_minutes)}</td>
        ${amAdmin() ? `<td>${scoreCell(t.score)}</td>` : ''}
        <td class="nowrap">${commentBtn(t)} ${taskActions(t)}</td>
      </tr>`).join('')}</tbody></table></div>`;
}

function liveTaskCard(t) {
  const hold = t.status === 'on_hold';
  return `<div class="task-card ${hold ? 'hold' : ''} ${t.overdue ? 'late' : ''}">
    <div class="tc-top">
      <div style="flex:1;min-width:0">
        <div class="t-title" data-open="${t.id}" style="cursor:pointer">${hold ? '⏸ ' : '<span class="dot working" style="margin-right:8px"></span>'}${esc(t.title)}</div>
        <div class="t-sub">${t.category ? esc(t.category) + ' · ' : ''}${t.parent_title ? `↳ came in during "${esc(t.parent_title)}"` : ''}</div>
      </div>
      ${prBadge(t.priority)} <span class="badge s-${t.status}">${STATUS_LABEL[t.status]}</span>
    </div>
    ${hold ? `<div class="hold-strip">⏸ On hold since <b>${fmtSmart(t.paused_at)}</b> (<span data-live="holdfor" ${liveAttrs(t)}></span>)
      ${t.hold_reason ? ` · ${esc(t.hold_reason)}` : ''}<span class="hs-note">Clock is stopped — this time is not counted</span></div>` : ''}
    <div class="tc-meta">
      <span>Started <b>${fmtSmart(t.start_time)}</b></span>
      <span>Plan <b>${dur(t.planned_minutes)}</b></span>
      <span>Finish by <b>${fmtSmart(t.effective_expected_end || t.expected_end)}</b>${t.hold_minutes ? ` <span class="t-sub">(+${dur(t.hold_minutes)} hold)</span>` : ''}</span>
      <span>Worked <b class="timer" data-live="timer" ${liveAttrs(t)}>--:--:--</b></span>
      <span data-live="remain" ${liveAttrs(t)}></span>
    </div>
    <div class="progress" data-live="progress" ${liveAttrs(t)}><i></i></div>
    <div class="tc-actions">${taskActions(t, false)}<span style="flex:1"></span>${commentBtn(t)}</div>
  </div>`;
}

// Delegated clicks for every task button / row on the page
document.addEventListener('click', async (e) => {
  const cm = e.target.closest('[data-comments]');
  if (cm) {
    e.preventDefault(); e.stopPropagation();
    $('#bell-panel').classList.add('hidden');
    taskDetail(cm.dataset.comments, 'comments').catch((ex) => toast(ex.message, 'error'));
    return;
  }
  const jump = e.target.closest('[data-scroll-emp]');
  if (jump) { state.scrollTo = jump.dataset.scrollEmp; state.reportDate = toLocalInput(new Date()).slice(0, 10); }
  const act = e.target.closest('[data-act]');
  if (act) {
    e.stopPropagation();
    const id = act.dataset.id;
    try {
      const t = await api('GET', `/api/tasks/${id}`);
      ({ start: startModal, qstart: quickStart, pause: pauseModal, resume: resumeTask, complete: completeModal, reason: reasonModal,
        review: reviewModal, edit: (x) => taskFormModal(x), archive: archiveTask, restore: restoreTask, delete: deleteTask, view: (x) => taskDetail(x.id), ...(window.EXTRA_ACTS || {}) })[act.dataset.act](t);
    } catch (ex) { toast(ex.message, 'error'); }
    return;
  }
  const open = e.target.closest('[data-open]');
  if (!open) return;
  const inner = e.target.closest('button, a, select, input');
  if (!inner || inner === open) { e.preventDefault(); taskDetail(open.dataset.open).catch((ex) => toast(ex.message, 'error')); }
});

// ------------------------------------------------------------ easy time pickers (no calendar typing)
// whenPicker: [Yesterday | Today | Tomorrow] + simple time box + one-tap chips ("Now", "15 min ago"...)
// durationPicker: "How long will it take?" chips (30 min, 1 hr...) + −/+ buttons; shows the finish time
const dayStr = (d) => toLocalInput(d).slice(0, 10);
const timeStr = (d) => toLocalInput(d).slice(11, 16);
const roundTo5 = (d) => { const x = new Date(d); x.setSeconds(0, 0); x.setMinutes(Math.round(x.getMinutes() / 5) * 5); return x; };
const niceTime = (d) => {
  const t = d.toLocaleTimeString('en-IN', { hour: 'numeric', minute: '2-digit', hour12: true });
  const k = dayStr(d), today = dayStr(new Date());
  const y = new Date(); y.setDate(y.getDate() - 1); const tm = new Date(); tm.setDate(tm.getDate() + 1);
  const day = k === today ? 'today' : k === dayStr(tm) ? 'tomorrow' : k === dayStr(y) ? 'yesterday'
    : d.toLocaleDateString('en-IN', { weekday: 'short', day: 'numeric', month: 'short' });
  return `${t} ${day}`;
};

const WHEN_CHIPS = {
  past: [['Now', 0], ['15 min ago', -15], ['30 min ago', -30], ['1 hr ago', -60], ['2 hrs ago', -120]],
  future: [['In 30 min', 30], ['In 1 hr', 60], ['In 2 hrs', 120], ['2:00 PM', '14:00'], ['Tomorrow 10 AM', 'tm10:00']],
};

function whenPicker(name, value, { chips = 'past', days = ['yesterday', 'today', 'tomorrow'], extra = [] } = {}) {
  const v = new Date(value);
  const dayBtn = { yesterday: [-1, 'Yesterday'], today: [0, 'Today'], tomorrow: [1, 'Tomorrow'] };
  return `<div class="tp" data-when="${name}">
    <div class="tp-row">
      <div class="seg mini tp-days">${days.map((d) => `<button type="button" data-off="${dayBtn[d][0]}">${dayBtn[d][1]}</button>`).join('')}
        <button type="button" data-off="other">📅 Other</button></div>
      <input type="date" class="tp-date hidden" value="${dayStr(v)}">
      <input type="time" class="tp-time" value="${timeStr(v)}" step="300">
    </div>
    <div class="tp-chips">${extra.map(([l, d]) => `<button type="button" class="chip accent" data-q="@${new Date(d).toISOString()}">${esc(l)}</button>`).join('')}${WHEN_CHIPS[chips].map(([l, x]) => `<button type="button" class="chip" data-q="${x}">${l}</button>`).join('')}</div>
    <input type="hidden" name="${name}" value="${v.toISOString()}">
  </div>`;
}

const DUR_CHIPS = [[15, '15 min'], [30, '30 min'], [45, '45 min'], [60, '1 hr'], [90, '1½ hrs'], [120, '2 hrs'], [180, '3 hrs'], [240, '4 hrs'], [480, 'Full day']];
function durationPicker(name, minutes, { base, label = 'Finishes around' } = {}) {
  const m = Math.max(5, Math.round(minutes || 60));
  return `<div class="dp" data-duration="${name}" data-base="${base || ''}" data-label="${esc(label)}">
    <div class="tp-chips">${DUR_CHIPS.map(([v, l]) => `<button type="button" class="chip ${v === m ? 'on' : ''}" data-m="${v}">${l}</button>`).join('')}</div>
    <div class="dp-row">
      <button type="button" class="btn sm" data-step="-15">− 15 min</button>
      <b class="dp-val">${dur(m)}</b>
      <button type="button" class="btn sm" data-step="15">+ 15 min</button>
      <span class="dp-end"></span>
    </div>
    <input type="hidden" name="${name}" value="${m}">
  </div>`;
}

// Wires every picker inside a form. Fires a "change" event on the form whenever a value changes.
function initTimePickers(form, root = form) {
  const fire = () => form.dispatchEvent(new Event('change'));
  $$('.tp', root).forEach((tp) => {
    const hidden = $('input[type=hidden]', tp), dateIn = $('.tp-date', tp), timeIn = $('.tp-time', tp);
    const set = (d) => { dateIn.value = dayStr(d); timeIn.value = timeStr(d); sync(); };
    const sync = () => {
      if (!timeIn.value) timeIn.value = timeStr(new Date());
      let d = new Date(`${dateIn.value}T${timeIn.value}`);
      // the time box has no seconds: if the current minute is chosen, use the exact current moment
      if (`${dateIn.value}T${timeIn.value}` === toLocalInput(new Date())) d = new Date();
      hidden.value = d.toISOString();
      const k = dateIn.value;
      let match = false;
      $$('.tp-days button', tp).forEach((b) => {
        if (b.dataset.off === 'other') return;
        const x = new Date(); x.setDate(x.getDate() + Number(b.dataset.off));
        const on = dayStr(x) === k; b.classList.toggle('on', on); match = match || on;
      });
      $('.tp-days [data-off=other]', tp)?.classList.toggle('on', !match);
      dateIn.classList.toggle('hidden', match && !tp.dataset.showDate);
      fire();
    };
    $('.tp-days', tp).addEventListener('click', (e) => {
      const b = e.target.closest('button'); if (!b) return;
      if (b.dataset.off === 'other') { tp.dataset.showDate = '1'; dateIn.classList.remove('hidden'); dateIn.focus(); dateIn.showPicker?.(); return; }
      delete tp.dataset.showDate;
      const x = new Date(); x.setDate(x.getDate() + Number(b.dataset.off)); dateIn.value = dayStr(x); sync();
    });
    $('.tp-chips', tp).addEventListener('click', (e) => {
      const b = e.target.closest('[data-q]'); if (!b) return;
      const q = b.dataset.q;
      if (q.startsWith('@')) set(new Date(q.slice(1)));
      else if (/^-?\d+$/.test(q)) set(Number(q) === 0 ? new Date() : roundTo5(new Date(Date.now() + Number(q) * 60000)));
      else { const tm = q.startsWith('tm'); const [h, mi] = q.replace('tm', '').split(':'); const d = new Date(); if (tm) d.setDate(d.getDate() + 1); d.setHours(+h, +mi, 0, 0); set(d); }
    });
    dateIn.addEventListener('change', sync);
    timeIn.addEventListener('input', sync);
    tp.whenSync = sync;
    sync();
  });
  $$('.dp', root).forEach((dp) => {
    const hidden = $('input[type=hidden]', dp);
    const show = () => {
      if (!form.contains(dp)) return;
      const m = Number(hidden.value);
      $('.dp-val', dp).textContent = dur(m);
      $$('[data-m]', dp).forEach((b) => b.classList.toggle('on', Number(b.dataset.m) === m));
      const baseEl = dp.dataset.base ? form.elements[dp.dataset.base] : null;
      const start = baseEl && baseEl.value ? new Date(baseEl.value) : new Date();
      $('.dp-end', dp).textContent = `${dp.dataset.label} ${niceTime(new Date(start.getTime() + m * 60000))}`;
    };
    dp.addEventListener('click', (e) => {
      const b = e.target.closest('[data-m],[data-step]'); if (!b) return;
      hidden.value = b.dataset.m ? b.dataset.m : Math.max(5, Number(hidden.value) + Number(b.dataset.step));
      show(); fire();
    });
    form.addEventListener('change', show);
    show();
  });
}
const pickedDate = (form, name) => (form.elements[name]?.value ? new Date(form.elements[name].value) : null);
const prioritySelect = (name = 'priority', val = 'medium') => `<select name="${name}">${Object.entries(PRIORITY_LABEL).map(([v, l]) => `<option value="${v}" ${v === val ? 'selected' : ''}>${l}</option>`).join('')}</select>`;

// ------------------------------------------------------------ create / edit task
function taskFormModal(task) {
  const isAdmin = state.user.role === 'admin';
  const editing = !!task;
  const now = new Date();
  const t = task || { title: '', description: '', category: '', priority: 'medium' };
  const assign = isAdmin && !editing;
  const employees = state.users.filter((u) => u.role === 'employee' && u.active);
  const origMin = t.start_time && t.expected_end ? Math.round((Date.parse(t.expected_end) - Date.parse(t.start_time)) / 60000) : 60;
  const inOneHour = roundTo5(new Date(now.getTime() + 3600000));

  // the time part changes with the chosen mode, so it is drawn separately
  const timeSection = (mode) => {
    if (editing) {
      return `<div class="tsec"><div class="tsec-h">${task.status === 'pending' ? 'Planned start' : 'Started at'}</div>
          ${whenPicker('start_time', t.start_time || inOneHour, { chips: task.status === 'pending' ? 'future' : 'past' })}</div>
        <div class="tsec"><div class="tsec-h">How long should it take?</div>${durationPicker('dur', origMin, { base: 'start_time' })}</div>
        ${task.status === 'completed' && isAdmin ? `<div class="tsec"><div class="tsec-h">Finished at</div>${whenPicker('actual_end', t.actual_end, { chips: 'past' })}</div>` : ''}`;
    }
    if (mode === 'plan') {
      return `<div class="tsec"><div class="tsec-h">${assign ? 'When should they start?' : 'When will you start?'}</div>
          ${whenPicker('start_time', assign ? inOneHour : now, { chips: 'future', days: ['today', 'tomorrow'] })}</div>
        <div class="tsec"><div class="tsec-h">${assign ? 'Time allowed for this task' : 'How long will it take?'}</div>${durationPicker('dur', 60, { base: 'start_time', label: 'Should finish by' })}</div>`;
    }
    if (mode === 'completed') {
      return `<div class="tsec"><div class="tsec-h">Started at</div>${whenPicker('start_time', roundTo5(new Date(now.getTime() - 3600000)), { chips: 'past', days: ['yesterday', 'today'] })}</div>
        <div class="tsec"><div class="tsec-h">How long should it have taken? <span class="t-sub">(your plan)</span></div>${durationPicker('dur', 60, { base: 'start_time', label: 'Planned finish' })}</div>
        <div class="tsec"><div class="tsec-h">Finished at</div>${whenPicker('actual_end', now, { chips: 'past', days: ['yesterday', 'today'] })}</div>`;
    }
    return `<div class="tsec"><div class="tsec-h">Started at</div>${whenPicker('start_time', now, { chips: 'past', days: ['yesterday', 'today'] })}</div>
      <div class="tsec"><div class="tsec-h">How long will it take?</div>${durationPicker('dur', 60, { base: 'start_time' })}</div>`;
  };

  const body = `
    ${assign ? `<label>Assign to employee<select name="user_id" required><option value="">— Select employee —</option>${employees.map((u) => `<option value="${u.id}">${esc(u.name)}${u.department ? ' · ' + esc(u.department) : ''}</option>`).join('')}</select></label>` : ''}
    ${!editing && !isAdmin ? `<input type="hidden" name="mode" value="plan">
      <div class="seg" id="mode-seg"><button type="button" class="on" data-mode="plan">📝 Add to my list</button><button type="button" data-mode="completed">✓ Already done</button></div>` : ''}
    ${assign ? '<input type="hidden" name="mode" value="plan">' : ''}
    <label>Task title<input name="title" required maxlength="150" value="${esc(t.title)}" placeholder="e.g. Prepare monthly sales report"></label>
    <div class="form-grid">
      <label>Priority${prioritySelect('priority', t.priority)}</label>
      <label>Category / Project<input name="category" maxlength="60" value="${esc(t.category)}" placeholder="e.g. Accounts, Client ABC"></label>
    </div>
    <div id="time-section">${timeSection(isAdmin && !assign ? 'start' : 'plan')}</div>
    <div id="late-wrap" class="hidden"><div class="callout amber">This finished after the planned time. Please write why it took longer.</div>
      <label>Reason for delay<textarea name="delay_reason" placeholder="e.g. Client changed requirements, system was down…"></textarea></label></div>
    <div id="change-wrap" class="hidden"><div class="callout amber">You are changing the time of a task that has already started. Admin will see this change.</div>
      <label>Why are you changing it?<textarea name="change_reason"></textarea></label></div>
    <label>Description / Notes<textarea name="description" placeholder="Optional details">${esc(t.description)}</textarea></label>`;

  const expectedFrom = (form) => {
    const s = pickedDate(form, 'start_time');
    return s ? new Date(s.getTime() + Number(form.elements.dur.value) * 60000) : null;
  };

  modal({
    title: editing ? 'Edit task' : assign ? 'Assign a new task' : 'Add a new task',
    body, submitText: editing ? 'Save changes' : assign ? 'Assign task' : 'Add task',
    onOpen: (form) => {
      initTimePickers(form);
      const seg = $('#mode-seg', form);
      const sync = () => {
        const mode = form.elements.mode?.value;
        const exp = expectedFrom(form), a = pickedDate(form, 'actual_end');
        const late = mode === 'completed' && a && exp && a.getTime() > exp.getTime() + 60000;
        $('#late-wrap', form).classList.toggle('hidden', !late);
        if (editing && !isAdmin && task.status !== 'pending') {
          $('#change-wrap', form).classList.toggle('hidden', Math.abs(exp - Date.parse(task.expected_end)) < 60000);
        }
      };
      if (seg) seg.addEventListener('click', (e) => {
        const b = e.target.closest('[data-mode]'); if (!b) return;
        $$('button', seg).forEach((x) => x.classList.toggle('on', x === b));
        form.elements.mode.value = b.dataset.mode;
        $('#time-section', form).innerHTML = timeSection(b.dataset.mode);
        initTimePickers(form, $('#time-section', form));
        sync();
      });
      form.addEventListener('change', sync);
      sync();
    },
    onSubmit: async (d, form) => {
      const start = pickedDate(form, 'start_time');
      const exp = expectedFrom(form);
      const payload = { ...d, start_time: start.toISOString(), expected_end: exp.toISOString(), actual_end: d.actual_end || undefined };
      delete payload.dur;
      if (editing) {
        if (!isAdmin || task.status !== 'completed') delete payload.actual_end;
        // keep the exact stored values if the user did not really change them
        if (task.start_time && Math.abs(start - Date.parse(task.start_time)) < 60000) payload.start_time = task.start_time;
        if (Math.abs(exp - Date.parse(task.expected_end)) < 60000) payload.expected_end = task.expected_end;
        if (task.actual_end && payload.actual_end && Math.abs(Date.parse(payload.actual_end) - Date.parse(task.actual_end)) < 60000) payload.actual_end = task.actual_end;
        await api('PUT', `/api/tasks/${task.id}`, payload);
        toast('Task updated');
      } else {
        const created = await api('POST', '/api/tasks', payload);
        if (!isAdmin && created.status === 'pending') { state.flashTaskId = created.id; refresh(); askToStart(created); return; } // never auto-start: ask
        toast(assign ? 'Task assigned' : created.status === 'completed' ? 'Saved as done' : 'Task added');
      }
      refresh();
    },
  });
}

// My other running tasks (used to offer "put that one on hold and switch")
async function myRunningTasks(exceptId) {
  const list = await api('GET', '/api/tasks?status=in_progress');
  return list.filter((x) => x.user_id === state.user.id && x.id !== exceptId);
}
const switchBox = (running, target) => (running.length ? `
  <label class="switch-box"><input type="checkbox" name="hold_others" checked style="width:auto">
    <span><b>Switch tasks:</b> put ${running.map((r) => `“${esc(r.title)}”`).join(', ')} on hold
    <span class="t-sub">— its clock stops while you work on ${esc(target)}</span></span></label>` : '');
async function holdOthers(running, targetTitle) {
  for (const r of running) await api('POST', `/api/tasks/${r.id}/pause`, { reason: `Switched to “${targetTitle}”` });
}

async function startModal(t) {
  const running = await myRunningTasks(t.id);
  const planned = t.start_time ? Math.round((Date.parse(t.expected_end) - Date.parse(t.start_time)) / 60000) : 60;
  modal({
    title: `▶ Start: ${esc(t.title)}`,
    body: `${switchBox(running, 'this task')}
      <div class="tsec"><div class="tsec-h">Started at</div>${whenPicker('start_time', new Date(), { chips: 'past', days: ['yesterday', 'today'] })}</div>
      <div class="tsec"><div class="tsec-h">How long will it take?</div>${durationPicker('dur', planned > 0 ? planned : 60, { base: 'start_time' })}</div>
      <div class="hint">Your rating depends on finishing within this time. Time on hold is never counted.</div>`,
    submitText: '▶ Start task',
    onOpen: (form) => initTimePickers(form),
    onSubmit: async (d, form) => {
      const s = pickedDate(form, 'start_time');
      if (d.hold_others) await holdOthers(running, t.title);
      await api('POST', `/api/tasks/${t.id}/start`, { start_time: s.toISOString(), expected_end: new Date(s.getTime() + Number(d.dur) * 60000).toISOString() });
      toast(d.hold_others && running.length ? `Switched to “${t.title}”` : 'Task started — timer running');
      refresh();
    },
  });
}

const HOLD_REASONS = ['Urgent work from boss / admin', 'Client call / client work', 'Meeting', 'Waiting for information / approval', 'System / internet issue', 'Lunch / break'];
function pauseModal(t) {
  modal({
    title: `Hold: ${esc(t.title)}`,
    body: `<div class="callout blue">⏸ The clock of this task <b>stops</b> while it is on hold — the hold time is not counted, and its finish time moves forward automatically. Resume it any time.</div>
      <label>Why are you stopping this task?<textarea name="reason" required placeholder="Write the reason, or pick one below"></textarea></label>
      <div class="row" style="gap:6px;margin:-4px 0 14px">${HOLD_REASONS.map((r) => `<button type="button" class="btn sm" data-reason="${esc(r)}">${esc(r)}</button>`).join('')}</div>
      <label class="row" style="gap:8px;font-size:14px;color:var(--text)"><input type="checkbox" name="add_new" style="width:auto"> New work came in — add it now and start it</label>
      <div id="nw" class="hidden card" style="padding:14px;background:var(--surface-2);margin-bottom:12px">
        <label>New work title<input name="nt_title" placeholder="What is the new work?"></label>
        <label>Priority${prioritySelect('nt_priority', 'high')}</label>
        <div class="tsec"><div class="tsec-h">How long will the new work take? <span class="t-sub">(starts now)</span></div>${durationPicker('nt_dur', 30)}</div>
        <label>Notes<textarea name="nt_description" style="min-height:50px"></textarea></label>
      </div>`,
    submitText: '⏸ Put on hold', submitClass: 'warn',
    onOpen: (form) => {
      initTimePickers(form);
      $$('[data-reason]', form).forEach((b) => b.addEventListener('click', () => { form.elements.reason.value = b.dataset.reason; }));
      form.elements.add_new.addEventListener('change', (e) => $('#nw', form).classList.toggle('hidden', !e.target.checked));
    },
    onSubmit: async (d) => {
      const body = { reason: d.reason };
      if (d.add_new) {
        if (!d.nt_title.trim()) throw new Error('Please write the new work title');
        body.new_task = { title: d.nt_title, priority: d.nt_priority, expected_end: new Date(Date.now() + Number(d.nt_dur) * 60000).toISOString(), description: d.nt_description };
      }
      const r = await api('POST', `/api/tasks/${t.id}/pause`, body);
      toast(r.new_task ? `On hold. Started new work: ${r.new_task.title}` : 'Task put on hold', 'warn');
      refresh();
    },
  });
}

// Resume a task that is on hold. If another task is running, offer to switch (hold that one).
async function resumeTask(t) {
  const running = await myRunningTasks(t.id);
  const doResume = async (holdRunning) => {
    if (holdRunning) await holdOthers(running, t.title);
    await api('POST', `/api/tasks/${t.id}/resume`);
    toast(holdRunning ? `Switched back to “${t.title}”` : `Resumed “${t.title}” — clock running again`);
    refresh();
  };
  if (!running.length) return doResume(false);
  modal({
    title: '🔁 Switch task?',
    body: `<div class="switch-flow">
        <div class="sf-card"><span class="badge s-in_progress">Working now</span>${running.map((r) => `<b>${esc(r.title)}</b>`).join('<br>')}<div class="t-sub">→ goes on hold (clock stops)</div></div>
        <div class="sf-arrow">➜</div>
        <div class="sf-card on"><span class="badge s-on_hold">On hold</span><b>${esc(t.title)}</b><div class="t-sub">→ resumes (clock starts again)</div></div>
      </div>
      <div class="hint" style="margin-top:12px">Only working time is counted. Time on hold never counts against anyone.</div>`,
    footer: `<button type="button" class="btn" data-close>Cancel</button>
      <button type="button" class="btn" id="sw-both" data-close>${running.length > 1 ? 'Keep others running' : 'Keep both running'}</button>
      <button type="button" class="btn primary" id="sw-yes" data-close>⏸ Hold current & ▶ resume this</button>`,
    onOpen: (form) => {
      $('#sw-yes', form).addEventListener('click', () => doResume(true).catch((e) => toast(e.message, 'error')));
      $('#sw-both', form).addEventListener('click', () => doResume(false).catch((e) => toast(e.message, 'error')));
    },
  });
}

// After finishing work that interrupted another task, offer to go back to it
async function offerBackToParent(t) {
  if (!t.parent_task_id) return;
  const p = await api('GET', `/api/tasks/${t.parent_task_id}`).catch(() => null);
  if (!p || p.status !== 'on_hold' || p.user_id !== state.user.id) return;
  modal({
    title: '↩ Back to your earlier task?',
    body: `<div class="callout blue">“${esc(t.title)}” is done. Your earlier task <b>“${esc(p.title)}”</b> is still on hold
      (since ${fmtSmart(p.paused_at)}). Its clock was stopped the whole time.</div>`,
    footer: `<button type="button" class="btn" data-close>Later</button><button type="button" class="btn primary" id="back-go" data-close>▶ Resume “${esc(p.title)}”</button>`,
    onOpen: (form) => $('#back-go', form).addEventListener('click', () => resumeTask(p).catch((e) => toast(e.message, 'error'))),
  });
}

function completeModal(t) {
  // planned finish = planned end + earlier holds; if it is on hold now, the current hold counts up to the chosen finish time
  const prevHold = (t.paused_minutes || 0) * 60000;
  const planEnd = Date.parse(t.expected_end) + prevHold;
  const effExpAt = (a) => planEnd + (t.status === 'on_hold' && t.paused_at ? Math.max(0, a - Date.parse(t.paused_at)) : 0);
  // a forgotten task: suggest the moment its clock stopped (or the planned end, if earlier)
  const stoppedAt = t.status === 'on_hold' && t.paused_at ? Date.parse(t.paused_at) : null;
  const suggested = stoppedAt && t.auto_paused ? new Date(Math.min(stoppedAt, planEnd)) : new Date();
  modal({
    title: `✓ Complete: ${esc(t.title)}`,
    body: `<div class="detail-grid" style="grid-template-columns:1fr 1fr 1fr">
        <div><span>Started</span><b>${fmtSmart(t.start_time)}</b></div>
        <div><span>Plan</span><b>${dur(t.planned_minutes)}</b></div>
        <div><span>Finish by</span><b>${fmtSmart(t.effective_expected_end || t.expected_end)}</b>${t.hold_minutes ? `<div class="t-sub">incl. ${dur(t.hold_minutes)} on hold</div>` : ''}</div>
      </div>
      <div class="tsec"><div class="tsec-h">Finished at</div>${whenPicker('actual_end', suggested, { chips: 'past', days: ['yesterday', 'today'], extra: [[`At planned end (${hhmm(new Date(Math.min(planEnd, stoppedAt || Infinity)))})`, new Date(Math.min(planEnd, stoppedAt || Infinity))]] })}</div>
      <div id="late-wrap" class="hidden">
        <div class="callout amber" id="late-msg"></div>
        <label>Reason — why did it take more time?<textarea name="delay_reason" placeholder="e.g. Requirement changed, waited for data from accounts, extra corrections…"></textarea>
        <div class="hint">Your admin will review this reason. If accepted, the delay will not reduce your rating.</div></label>
      </div>
      <label>Completion note (optional)<textarea name="note" style="min-height:50px" placeholder="Anything to add?"></textarea></label>`,
    submitText: '✓ Mark completed', submitClass: 'success',
    onOpen: (form) => {
      const sync = () => {
        const a = pickedDate(form, 'actual_end').getTime();
        const due = effExpAt(a);
        const late = a > due + 60000;
        $('#late-wrap', form).classList.toggle('hidden', !late);
        if (late) $('#late-msg', form).textContent = `This is ${dur((a - due) / 60000)} later than your planned finish time.`;
      };
      initTimePickers(form);
      form.addEventListener('change', sync);
      sync();
    },
    onSubmit: async (d) => {
      const reason = [d.delay_reason, d.note ? `Note: ${d.note}` : ''].filter((x) => x && x.trim()).join(' | ');
      const r = await api('POST', `/api/tasks/${t.id}/complete`, { actual_end: d.actual_end, delay_reason: d.delay_reason ? reason : d.note });
      toast(r.is_late ? 'Completed (late). Reason sent to admin.' : '🎉 Completed on time!', r.is_late ? 'warn' : 'ok');
      refresh();
      offerBackToParent(r).catch(() => {});
    },
  });
}

function reasonModal(t) {
  modal({
    title: 'Reason for delay',
    body: `<div class="callout amber">"${esc(t.title)}" finished ${dur(t.late_by_minutes)} after the expected time.</div>
      ${t.reason_status === 'rejected' && t.admin_note ? `<div class="callout red"><b>Admin note:</b> ${esc(t.admin_note)}</div>` : ''}
      <label>Reason<textarea name="delay_reason" required>${esc(t.delay_reason)}</textarea></label>`,
    submitText: 'Send to admin',
    onSubmit: async (d) => { await api('POST', `/api/tasks/${t.id}/reason`, d); toast('Reason sent for review'); refresh(); },
  });
}

function reviewModal(t) {
  const m = modal({
    title: 'Review delay reason',
    body: `<div class="row" style="margin-bottom:12px">${avatar(t.user_name)}<div><b>${esc(t.user_name)}</b><div class="t-sub">${esc(t.title)}</div></div></div>
      <div class="detail-grid">
        <div><span>Expected end</span><b>${fmtDT(t.expected_end)}</b></div>
        <div><span>Actual end</span><b>${fmtDT(t.actual_end)}</b></div>
        <div><span>Late by</span><b style="color:var(--red)">${dur(t.late_by_minutes)}</b></div>
        <div><span>Planned</span><b>${dur(t.planned_minutes)}</b></div>
        <div><span>Actually worked</span><b>${dur(t.worked_minutes)}</b></div>
        <div><span>Time on hold</span><b>${dur(t.paused_minutes)}</b></div>
      </div>
      <div class="callout amber"><b>Employee's reason:</b><br>${esc(t.delay_reason) || '<i>No reason given</i>'}</div>
      <label>Your note to the employee (optional)<textarea name="note">${esc(t.admin_note)}</textarea></label>
      <div class="hint">Accepted → the delay does not reduce the score (100%). Rejected → score is based on time taken, minus 10 points.</div>`,
    footer: `<button type="button" class="btn" data-close>Cancel</button>
      <button type="submit" class="btn danger" name="decision" value="rejected">✕ Reject</button>
      <button type="submit" class="btn success" name="decision" value="accepted">✓ Accept reason</button>`,
    onSubmit: async (d, form, submitter) => {
      await api('POST', `/api/tasks/${t.id}/review`, { decision: submitter.value, note: d.note });
      toast(`Reason ${submitter.value}`);
      refresh();
    },
  });
  return m;
}

// Employees never delete. A task added by mistake is archived: it leaves their list and is not
// counted anywhere, but the admin can still see it (and restore it).
// Same rule as the server: own task, not assigned by admin; "To do" any time,
// started / done only if it was added less than 30 minutes ago.
const ARCHIVE_WINDOW_MIN = 30;
function canArchiveTask(t) {
  if (t.archived_at) return false;
  if (state.user.role === 'admin') return true;
  if (t.user_id !== state.user.id || t.assigned_by) return false;
  return t.status === 'pending' || Date.now() - Date.parse(t.created_at) < ARCHIVE_WINDOW_MIN * 60000;
}
function archiveTask(t) {
  const reasons = ['Added by mistake', 'Added twice', 'Not needed any more'];
  modal({
    title: '🗃 Archive this task?',
    body: `<p style="margin:0 0 12px">“<b>${esc(t.title)}</b>” will be removed from your list and will not count in your progress.
        <span class="t-sub">It is not deleted - admin can still see it.</span></p>
      <label>Why?<input name="reason" maxlength="300" value="${reasons[0]}"></label>
      <div class="row" style="margin-top:8px;flex-wrap:wrap;gap:6px">${reasons.map((r) => `<button type="button" class="chip" data-r="${r}">${r}</button>`).join('')}</div>`,
    submitText: '🗃 Archive', submitClass: 'primary',
    onOpen: (form) => $$('[data-r]', form).forEach((b) => b.addEventListener('click', () => { form.elements.reason.value = b.dataset.r; })),
    onSubmit: async (d) => {
      await api('POST', `/api/tasks/${t.id}/archive`, { reason: d.reason });
      toast(`Archived: ${t.title}`);
      state.pendingMine = null;
      refresh();
    },
  });
}
async function restoreTask(t) {
  await api('POST', `/api/tasks/${t.id}/restore`);
  toast(`Restored: ${t.title}`);
  refresh();
}
// Permanent delete: admin only
async function deleteTask(t) {
  if (state.user.role !== 'admin') return;
  const extra = t.status === 'pending' ? '' : '<br><span class="t-sub">Its recorded time will also be removed.</span>';
  if (!(await confirmBox('Delete this task permanently?', `“${esc(t.title)}” will be deleted. This cannot be undone.${extra}`, '🗑 Delete'))) return;
  await api('DELETE', `/api/tasks/${t.id}`);
  toast(`Deleted: ${t.title}`);
  state.pendingMine = null;
  refresh();
}

async function taskDetail(id, startTab = 'details') {
  const t = await api('GET', `/api/tasks/${id}`);
  const isAdmin = state.user.role === 'admin';
  const mine = t.user_id === state.user.id;
  const canEdit = isAdmin || (mine && t.status !== 'completed');
  const canArchive = canArchiveTask(t);
  const evIcon = { corrected: '🛠', excused: '✅', requested: '📨', request_rejected: '✕', archived: '🗃', restored: '↩', created: '➕', started: '▶', paused: '⏸', resumed: '▶', completed: '✓', edited: '✎', reviewed: '⚖', reason: '✎' };
  const unread = state.unread.get(t.id) || 0;
  modal({
    title: `${esc(t.title)}`,
    wide: true,
    onOpen: (form) => initComments(form, t, startTab),
    body: `
      <div class="tabs modal-tabs">
        <button type="button" data-dtab="details" class="${startTab === 'details' ? 'on' : ''}">📋 Details</button>
        <button type="button" data-dtab="comments" class="${startTab === 'comments' ? 'on' : ''}">💬 Comments
          <span class="count" id="cmt-count">${t.comment_count || 0}</span>${unread ? `<span class="new-dot">${unread} new</span>` : ''}</button>
      </div>
      <div data-dpane="comments" class="${startTab === 'comments' ? '' : 'hidden'}">
        <div class="chat" id="chat-list"><div class="empty">Loading…</div></div>
        <div class="chat-input">
          <textarea id="chat-text" rows="2" maxlength="2000" placeholder="Write a comment for ${esc(isAdmin ? t.user_name : 'admin')}…  (Enter = send, Shift+Enter = new line)"></textarea>
          <button type="button" class="btn primary" id="chat-send">Send ➤</button>
        </div>
      </div>
      <div data-dpane="details" class="${startTab === 'details' ? '' : 'hidden'}">
      <div class="row" style="margin-bottom:14px">${prBadge(t.priority)} ${stBadges(t)}
        ${t.reason_status !== 'none' ? `<span class="badge r-${t.reason_status}">${REASON_LABEL[t.reason_status]}</span>` : ''}
        <span style="margin-left:auto" class="row">${avatar(t.user_name, 'sm')} <b>${esc(t.user_name)}</b></span></div>
      ${t.archived_at ? `<div class="callout amber">🗃 <b>Archived</b> on ${fmtDT(t.archived_at)}. It is hidden from the employee's list and not counted in scores.</div>` : ''}
      ${t.parent_title ? `<div class="callout blue">↳ This work came in while working on "<b>${esc(t.parent_title)}</b>"</div>` : ''}
      ${t.children?.length ? `<div class="callout blue">New work that came in during this task: ${t.children.map((c) => `<a href="#" data-open="${c.id}">${esc(c.title)}</a>`).join(', ')}</div>` : ''}
      <div class="detail-grid">
        <div><span>Start time</span><b>${fmtDT(t.start_time)}</b></div>
        <div><span>Expected end</span><b>${fmtDT(t.expected_end)}</b></div>
        <div><span>Actual end</span><b>${t.status === 'completed' ? fmtDT(t.actual_end) : '—'}</b></div>
        <div><span>Planned time</span><b>${dur(t.planned_minutes)}</b></div>
        <div><span>Worked time</span><b>${dur(t.worked_minutes)}</b></div>
        <div><span>On hold</span><b>${dur(t.paused_minutes)}</b></div>
        <div><span>Category</span><b>${esc(t.category) || '—'}</b></div>
        <div><span>Added by</span><b>${t.assigned_by_name ? esc(t.assigned_by_name) : 'Self'}</b></div>
        ${isAdmin ? `<div><span>Task score</span><b style="color:${scoreColor(t.score)}">${t.score != null ? t.score + '%' : '—'}</b></div>`
          : `<div><span>Priority</span><b>${PRIORITY_LABEL[t.priority]}</b></div>`}
      </div>
      ${t.description ? `<div class="callout" style="background:var(--surface-2);border:1px solid var(--border)">${esc(t.description).replace(/\n/g, '<br>')}</div>` : ''}
      ${t.delay_reason ? `<div class="callout amber"><b>Reason for delay:</b> ${esc(t.delay_reason)}</div>` : ''}
      ${t.admin_note ? `<div class="callout ${t.reason_status === 'accepted' ? 'green' : 'red'}"><b>Admin note:</b> ${esc(t.admin_note)}</div>` : ''}
      ${window.taskExtras ? taskExtras(t) : ''}
      <h4 style="margin:6px 0 12px">Activity timeline</h4>
      <div class="timeline">${t.events.map((e) => `<div class="tl-item ${e.type}">
        <div><b>${evIcon[e.type] || '•'} ${esc(e.type[0].toUpperCase() + e.type.slice(1))}</b> <span class="muted">by ${esc(e.user_name || '—')}</span></div>
        ${e.note ? `<div>${esc(e.note)}</div>` : ''}<div class="tl-when">${fmtDT(e.at)}</div></div>`).join('')}</div>
      </div>`,
    footer: `${isAdmin ? `<button type="button" class="btn danger" data-act="delete" data-id="${t.id}" data-close>Delete</button>` : ''}
      ${canArchive ? `<button type="button" class="btn" data-act="archive" data-id="${t.id}" data-close>🗃 Archive</button>` : ''}
      ${window.taskExtraButtons ? taskExtraButtons(t) : ''}
      <span style="flex:1"></span>
      ${canEdit && !t.archived_at ? `<button type="button" class="btn" data-act="edit" data-id="${t.id}" data-close>✎ Edit</button>` : ''}
      ${taskActions(t, false).replace(/data-id=/g, 'data-close data-id=')}
      <button type="button" class="btn" data-close>Close</button>`,
  });
}

// ============================================================ task comments (chat between admin and employee)
function chatDayLabel(iso) {
  const d = new Date(iso), today = new Date(), y = new Date(); y.setDate(y.getDate() - 1);
  if (d.toDateString() === today.toDateString()) return 'Today';
  if (d.toDateString() === y.toDateString()) return 'Yesterday';
  return d.toLocaleDateString('en-IN', { weekday: 'short', day: 'numeric', month: 'short', year: 'numeric' });
}

function renderChat(list) {
  if (!list.length) {
    return `<div class="chat-empty"><div class="e-ico">💬</div><b>No comments yet</b>
      <div>${state.user.role === 'admin' ? 'Give an instruction or feedback to the employee about this task.' : 'Ask a question or give an update to your admin about this task.'}</div></div>`;
  }
  let lastDay = '';
  return list.map((c) => {
    const day = chatDayLabel(c.created_at);
    const sep = day !== lastDay ? `<div class="chat-day"><span>${day}</span></div>` : '';
    lastDay = day;
    const mine = c.user_id === state.user.id;
    const time = new Date(c.created_at).toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', hour12: true });
    return `${sep}<div class="msg ${mine ? 'mine' : 'theirs'}">
      ${mine ? '' : avatar(c.user_name || '?', 'sm')}
      <div class="msg-col">
        <div class="msg-head">${mine ? 'You' : esc(c.user_name || 'Deleted user')}${c.user_role === 'admin' ? ' <span class="role-tag">Admin</span>' : ''}<span>${time}</span></div>
        <div class="msg-body">${esc(c.body).replace(/\n/g, '<br>')}</div>
      </div></div>`;
  }).join('');
}

function initComments(form, t, startTab) {
  const list = $('#chat-list', form), text = $('#chat-text', form), send = $('#chat-send', form);
  let loaded = false, lastCount = -1;
  const load = async () => {
    const rows = await api('GET', `/api/tasks/${t.id}/comments`);
    if (rows.length !== lastCount) {
      const atBottom = list.scrollHeight - list.scrollTop - list.clientHeight < 60;
      list.innerHTML = renderChat(rows);
      if (atBottom || lastCount === -1) list.scrollTop = list.scrollHeight;
      lastCount = rows.length;
      $('#cmt-count', form).textContent = rows.length;
    }
    $('.new-dot', form)?.remove();
    if (state.unread.has(t.id)) { state.unread.delete(t.id); renderBell(); }
  };
  const show = (tab) => {
    $$('[data-dtab]', form).forEach((b) => b.classList.toggle('on', b.dataset.dtab === tab));
    $$('[data-dpane]', form).forEach((p) => p.classList.toggle('hidden', p.dataset.dpane !== tab));
    if (tab === 'comments') {
      if (!loaded) { loaded = true; load().catch((e) => toast(e.message, 'error')); }
      setTimeout(() => text.focus(), 30);
    }
  };
  $$('[data-dtab]', form).forEach((b) => b.addEventListener('click', () => show(b.dataset.dtab)));
  const submit = async () => {
    const body = text.value.trim();
    if (!body) return;
    send.disabled = true;
    try {
      await api('POST', `/api/tasks/${t.id}/comments`, { body });
      text.value = '';
      lastCount = -2;
      await load();
      list.scrollTop = list.scrollHeight;
    } catch (e) { toast(e.message, 'error'); } finally { send.disabled = false; text.focus(); }
  };
  send.addEventListener('click', submit);
  text.addEventListener('keydown', (e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); submit(); } });
  // live refresh while the window is open
  const timer = setInterval(() => {
    if (!document.body.contains(form)) return clearInterval(timer);
    if (loaded) load().catch(() => {});
  }, 8000);
  show(startTab);
}

// ------------------------------------------------------------ unread comments bell
async function pollUnread() {
  if (!state.user) return;
  try {
    const rows = await api('GET', '/api/comments/unread');
    const prev = state.unread;
    state.unread = new Map(rows.map((r) => [r.task_id, r.count]));
    state.unreadRows = rows;
    if (state.unreadReady) {
      rows.filter((r) => r.count > (prev.get(r.task_id) || 0))
        .forEach((r) => toast(`💬 ${r.last_by}: "${r.last_body.slice(0, 70)}${r.last_body.length > 70 ? '…' : ''}" — on ${r.title}`));
    }
    state.unreadReady = true;
    renderBell();
  } catch { /* ignore */ }
}

function renderBell() {
  const n = [...state.unread.values()].reduce((s, v) => s + v, 0);
  const c = $('#bell-count');
  c.textContent = n > 99 ? '99+' : n;
  c.classList.toggle('hidden', !n);
  $$('[data-cmt-unread]').forEach((el) => {
    const u = state.unread.get(Number(el.dataset.cmtUnread)) || 0;
    el.classList.toggle('new', !!u);
  });
  const rows = (state.unreadRows || []).filter((r) => state.unread.has(r.task_id));
  $('#bell-panel').innerHTML = `<div class="bp-head">New comments</div>${rows.length ? rows.map((r) => `
    <a href="#" class="bp-item" data-comments="${r.task_id}">
      ${avatar(r.last_by || '?', 'sm')}
      <div style="min-width:0;flex:1"><div class="bp-title"><b>${esc(r.last_by || '')}</b> on <b>${esc(r.title)}</b></div>
        <div class="bp-body">${esc(r.last_body)}</div>
        <div class="t-sub">${state.user.role === 'admin' ? esc(r.owner_name) + ' · ' : ''}${fmtSmart(r.last_at)}${r.count > 1 ? ` · ${r.count} new` : ''}</div></div>
    </a>`).join('') : '<div class="empty" style="padding:24px">You are all caught up ✅</div>'}`;
}

$('#bell').addEventListener('click', (e) => { e.stopPropagation(); $('#bell-panel').classList.toggle('hidden'); });
document.addEventListener('click', (e) => { if (!e.target.closest('.bell-wrap')) $('#bell-panel').classList.add('hidden'); });
setInterval(() => { pollUnread(); pollNotifications(); }, 15000);

// ------------------------------------------------------------ pop-up alerts (task assigned, reason reviewed) + sound
let audioCtx = null;
document.addEventListener('pointerdown', () => {
  try { audioCtx = audioCtx || new (window.AudioContext || window.webkitAudioContext)(); if (audioCtx.state === 'suspended') audioCtx.resume(); } catch { /* no audio */ }
}, { capture: true });

function playChime() {
  try {
    audioCtx = audioCtx || new (window.AudioContext || window.webkitAudioContext)();
    const t0 = audioCtx.currentTime;
    [[880, 0], [1175, 0.16], [1568, 0.32]].forEach(([f, d]) => {
      const o = audioCtx.createOscillator(), g = audioCtx.createGain();
      o.type = 'sine'; o.frequency.value = f;
      g.gain.setValueAtTime(0.0001, t0 + d);
      g.gain.exponentialRampToValueAtTime(0.35, t0 + d + 0.02);
      g.gain.exponentialRampToValueAtTime(0.0001, t0 + d + 0.45);
      o.connect(g).connect(audioCtx.destination);
      o.start(t0 + d); o.stop(t0 + d + 0.5);
    });
  } catch { /* sound not available */ }
}

let titleFlash = null;
function flashTitle(text) {
  const base = 'WorkTrack — Office Task Manager';
  clearInterval(titleFlash);
  let on = false;
  titleFlash = setInterval(() => { document.title = (on = !on) ? text : base; }, 1000);
  const stop = () => { clearInterval(titleFlash); document.title = base; window.removeEventListener('focus', stop); document.removeEventListener('pointerdown', stop); };
  window.addEventListener('focus', stop); document.addEventListener('pointerdown', stop);
}

async function markNotifRead(ids) {
  await api('POST', '/api/notifications/read', { ids }).catch(() => {});
}

function showAlertCard(n) {
  const box = $('#alerts');
  const assigned = n.type === 'assigned';
  const canStart = assigned && n.task_status === 'pending' && state.user.role !== 'admin';
  const el = document.createElement('div');
  el.className = `alert-card ${n.type}`;
  el.innerHTML = `
    <div class="ac-ico">${assigned ? '📌' : n.type === 'request' ? '📨' : n.type === 'autostop' ? '🌙' : n.title.includes('accepted') ? '✅' : '⚖️'}</div>
    <div class="ac-main">
      <div class="ac-title">${esc(n.title)}</div>
      <div class="ac-body">${esc(n.body)}</div>
      ${assigned && n.priority ? `<div style="margin-top:6px">${prBadge(n.priority)}</div>` : ''}
      <div class="ac-actions">
        ${canStart ? '<button class="btn primary sm" data-a="start">▶ Start now</button>' : ''}
        ${n.task_id ? '<button class="btn sm" data-a="view">View task</button>' : ''}
        ${n.type === 'request' ? '<button class="btn sm" data-a="requests">Open requests</button>' : ''}
        <button class="btn sm" data-a="ok">${canStart ? 'Later' : 'OK'}</button>
      </div>
    </div>
    <button class="icon-btn ac-x" data-a="ok" aria-label="Dismiss">✕</button>`;
  el.addEventListener('click', async (e) => {
    const a = e.target.closest('[data-a]')?.dataset.a;
    if (!a) return;
    el.classList.add('out'); setTimeout(() => el.remove(), 200);
    await markNotifRead([n.id]);
    try {
      if (a === 'start') startModal(await api('GET', `/api/tasks/${n.task_id}`));
      if (a === 'view') taskDetail(n.task_id);
      if (a === 'requests') location.hash = '#/requests';
    } catch (ex) { toast(ex.message, 'error'); }
  });
  pushAlert(el);
}

// ------------------------------------------------------------ popup queue: at most 3 on screen, the rest wait their turn
const MAX_ALERTS = 3;
const alertQueue = [];
function pushAlert(el) {
  const box = $('#alerts');
  if (box.children.length < MAX_ALERTS) box.appendChild(el); else alertQueue.push(el);
  // also show it as a Windows notification when WorkTrack is minimized or another app is in front
  systemNotify($('.ac-title', el)?.textContent || 'WorkTrack', $('.ac-body', el)?.textContent || '');
}

// ------------------------------------------------------------ Windows (system) notifications
const notifySupported = () => 'Notification' in window && window.isSecureContext;
function systemNotify(title, body) {
  if (!notifySupported() || Notification.permission !== 'granted') return;
  if (!document.hidden && document.hasFocus()) return; // the person is looking at WorkTrack: the popup is enough
  try {
    const n = new Notification(title, { body: body.replace(/\s+/g, ' ').trim().slice(0, 180), icon: 'icon-256.png', tag: title, requireInteraction: false });
    n.onclick = () => { window.focus(); n.close(); };
  } catch { /* some browsers only allow notifications from a service worker */ }
}
async function enableNotifications() {
  if (!notifySupported()) return 'unsupported';
  const p = await Notification.requestPermission();
  if (p === 'granted') {
    toast('🔔 Desktop notifications are on');
    try { new Notification('WorkTrack notifications are on', { body: 'You will be reminded before tasks start and before deadlines.', icon: 'icon-256.png' }); } catch { /* ignore */ }
  } else if (p === 'denied') {
    toast('Notifications are blocked. Allow them from the 🔒 icon next to the address, then reload.', 'warn');
  }
  return p;
}

// status line + button for desktop notifications (Account page and the Today page banner)
function renderNotifState(box) {
  if (!box) return;
  if (!notifySupported()) {
    box.innerHTML = `<div class="callout amber" style="margin:0">Desktop notifications are not available in this window.
      Open WorkTrack from the <b>WorkTrack desktop icon</b> (install it from the login page) to get notifications even when WorkTrack is minimized.</div>`;
    return;
  }
  const p = Notification.permission;
  box.innerHTML = p === 'granted' ? '<div class="callout green" style="margin:0">✅ Desktop notifications are on. Reminders also appear in the corner of your screen when WorkTrack is minimized.</div>'
    : p === 'denied' ? '<div class="callout amber" style="margin:0">Desktop notifications are blocked. Click the 🔒 icon next to the address, allow Notifications, then reload WorkTrack.</div>'
    : '<div class="row"><button class="btn primary" id="notif-on">🔔 Turn on desktop notifications</button><span class="t-sub">So you never miss a reminder, even when WorkTrack is minimized.</span></div>';
  $('#notif-on', box)?.addEventListener('click', async () => { await enableNotifications(); renderNotifState(box); $('#notif-banner')?.remove(); });
}

// one-line banner on the Today page until notifications are turned on ("Not now" hides it for the day)
function notifyBanner() {
  if (!notifySupported() || Notification.permission !== 'default') return '';
  try { if (localStorage.getItem('wt-notif-later') === dayKey(new Date())) return ''; } catch { /* ignore */ }
  return `<div class="notif-banner" id="notif-banner"><span>🔔</span>
    <div><b>Never miss a deadline.</b> Turn on desktop notifications — reminders will appear on your screen even when WorkTrack is minimized.</div>
    <button class="btn primary sm" id="notif-yes">Turn on</button><button class="btn sm" id="notif-later">Not now</button></div>`;
}

// how many minutes before a start time / deadline to remind (each person chooses; default 10)
const REMIND_KEY = 'wt-remind-min';
function remindMinutes() {
  try { const v = Number(localStorage.getItem(REMIND_KEY)); return [5, 10, 15, 30].includes(v) ? v : 10; } catch { return 10; }
}
new MutationObserver(() => {
  const box = $('#alerts');
  while (alertQueue.length && box.children.length < MAX_ALERTS) box.appendChild(alertQueue.shift());
}).observe($('#alerts'), { childList: true });

// one simple popup: icon, title, text and buttons ({ label, cls, run })
function makeAlert({ icon, title, body = '', kind = '', key, buttons = [], sound = true }) {
  if (key) { if ($(`.alert-card[data-key="${key}"]`)) return; }
  const el = document.createElement('div');
  el.className = `alert-card ${kind}`;
  if (key) el.dataset.key = key;
  el.innerHTML = `<div class="ac-ico">${icon}</div>
    <div class="ac-main"><div class="ac-title">${title}</div>${body ? `<div class="ac-body">${body}</div>` : ''}
      <div class="ac-actions">${buttons.map((b, i) => `<button class="btn sm ${b.cls || ''}" data-i="${i}">${b.label}</button>`).join('')}</div></div>
    <button class="icon-btn ac-x" data-i="x" aria-label="Dismiss">✕</button>`;
  el.addEventListener('click', async (e) => {
    const i = e.target.closest('[data-i]')?.dataset.i; if (i == null) return;
    el.classList.add('out'); setTimeout(() => el.remove(), 200);
    try { if (i !== 'x' && buttons[i].run) await buttons[i].run(); } catch (x) { toast(x.message, 'error'); }
  });
  pushAlert(el);
  if (sound) playChime();
}

// move a planned task to a new start, keeping its planned length
async function reschedule(t, newStart) {
  const len = Date.parse(t.expected_end) - Date.parse(t.start_time);
  await api('PUT', `/api/tasks/${t.id}`, { start_time: newStart.toISOString(), expected_end: new Date(newStart.getTime() + len).toISOString() });
  toast(`Moved “${t.title}” to ${niceTime(newStart)}`);
  state.pendingMine = null; pollNotifications(); refresh();
}
const inOneHourFrom = (d = new Date()) => { const x = new Date(d.getTime() + 3600000); x.setSeconds(0, 0); x.setMinutes(Math.ceil(x.getMinutes() / 5) * 5); return x; };
const sameTimeTomorrow = (iso) => { const x = new Date(iso); const n = new Date(); x.setFullYear(n.getFullYear(), n.getMonth(), n.getDate() + 1); return x; };

// running task: 10 minutes before its deadline
function showDeadlineSoon(t, minsLeft) {
  makeAlert({
    icon: '⏳', kind: 'soon', key: `soon-${t.id}`,
    title: `${Math.max(1, Math.ceil(minsLeft))} min left: ${esc(t.title)}`,
    body: `Planned to finish at ${hhmm(new Date(Date.parse(t.expected_end) + (t.paused_minutes || 0) * 60000))}.`,
    buttons: [
      { label: '✓ Done', cls: 'success', run: async () => { const r = await api('POST', `/api/tasks/${t.id}/complete`, {}); toast(`✓ “${t.title}” completed`); refresh(); offerBackToParent(r).catch(() => {}); } },
      { label: 'OK' },
    ],
  });
}

// planned task not started (late start) or its whole planned time has passed (missed)
function showNotStarted(t, missed) {
  makeAlert({
    icon: missed ? '❌' : '⚠️', kind: missed ? 'missed' : 'latestart', key: `${missed ? 'missed' : 'ls'}-${t.id}`,
    title: missed ? `Missed: ${esc(t.title)}` : `Not started yet: ${esc(t.title)}`,
    body: missed ? `It was planned for ${hhmm(t.start_time)} – ${hhmm(t.expected_end)}. Start it now or move it.`
      : `It was planned to start at ${hhmm(t.start_time)}.`,
    buttons: [
      { label: '▶ Start now', cls: 'primary', run: async () => quickStart(await api('GET', `/api/tasks/${t.id}`)) },
      { label: '⏰ Move +1 hour', run: () => reschedule(t, inOneHourFrom()) },
      ...(missed ? [{ label: 'Tomorrow', run: () => reschedule(t, sameTimeTomorrow(t.start_time)) }] : []),
    ],
  });
}

// several missed / late tasks at once -> one summary instead of many popups
function showMissedSummary(list) {
  makeAlert({
    icon: '⚠️', kind: 'missed', key: 'missed-summary',
    title: `${list.length} planned tasks need attention`,
    body: list.slice(0, 4).map((t) => `<div class="dp-line"><b>${hhmm(t.start_time)}</b> ${esc(t.title)}</div>`).join('') + (list.length > 4 ? `<div class="dp-line">+ ${list.length - 4} more</div>` : ''),
    buttons: [{ label: 'Open Today', cls: 'primary', run: () => { location.hash = '#/my'; } }, { label: 'OK' }],
  });
}

// admin: tasks of employees that became overdue
async function checkOverdueForAdmin() {
  const rows = (await api('GET', '/api/tasks?status=overdue')).filter((t) => t.user_id !== state.user.id);
  const seen = state.overdueSeen;
  if (!seen) { // first check after login: one quiet summary
    state.overdueSeen = new Set(rows.map((t) => t.id));
    if (rows.length) {
      makeAlert({
        icon: '⚠️', kind: 'missed', key: 'admin-overdue-summary',
        title: `${rows.length} task${rows.length > 1 ? 's are' : ' is'} overdue`,
        body: rows.slice(0, 4).map((t) => `<div class="dp-line"><b>${esc(t.user_name.split(' ')[0])}</b> ${esc(t.title)} · ${dur(t.late_by_minutes)} over</div>`).join('') + (rows.length > 4 ? `<div class="dp-line">+ ${rows.length - 4} more</div>` : ''),
        buttons: [{ label: 'Open Overview', cls: 'primary', run: () => { location.hash = '#/dashboard'; } }, { label: 'OK' }],
        sound: false,
      });
    }
    return;
  }
  const fresh = rows.filter((t) => !seen.has(t.id));
  fresh.forEach((t) => seen.add(t.id));
  if (fresh.length > 2) {
    makeAlert({ icon: '⚠️', kind: 'missed', title: `${fresh.length} more tasks just became overdue`, buttons: [{ label: 'Open Overview', cls: 'primary', run: () => { location.hash = '#/dashboard'; } }, { label: 'OK' }] });
  } else {
    fresh.forEach((t) => makeAlert({
      icon: '⚠️', kind: 'missed', key: `adm-od-${t.id}`,
      title: `Overdue: ${esc(t.title)}`,
      body: `${esc(t.user_name)} · ${t.status === 'pending' ? 'not started' : t.status === 'on_hold' ? 'paused' : 'still running'} · was due ${hhmm(t.effective_expected_end || t.expected_end)}`,
      buttons: [{ label: 'View task', cls: 'primary', run: () => taskDetail(t.id) }, { label: '💬 Message', run: () => taskDetail(t.id, 'comments') }, { label: 'OK' }],
    }));
  }
}

// "Planned time is over — is it done?"  One card per task; it comes back every 15 min while the task keeps running.
function showOvertimeCard(t, round) {
  $(`.alert-card[data-over="${t.id}"]`)?.remove();
  const planEnd = new Date(Date.parse(t.expected_end) + (t.paused_minutes || 0) * 60000);
  const el = document.createElement('div');
  el.className = 'alert-card overtime';
  el.dataset.over = t.id;
  el.innerHTML = `<div class="ac-ico">⏰</div>
    <div class="ac-main"><div class="ac-title">Is “${esc(t.title)}” done?</div>
      <div class="ac-body">${round ? `Still running — ${dur((Date.now() - planEnd) / 60000)} over the planned time.` : `Its planned time ended at ${hhmm(planEnd)}.`}
        If you forgot to stop it, choose when you finished.</div>
      <div class="ac-actions">
        <button class="btn success sm" data-a="end">✓ Done at ${hhmm(planEnd)}</button>
        <button class="btn sm" data-a="now">✓ Done now</button>
        <button class="btn sm" data-a="pick">Other time…</button>
        <button class="btn sm" data-a="more">Still working</button>
      </div></div>
    <button class="icon-btn ac-x" data-a="more" aria-label="Dismiss">✕</button>`;
  el.addEventListener('click', async (e) => {
    const a = e.target.closest('[data-a]')?.dataset.a; if (!a) return;
    el.classList.add('out'); setTimeout(() => el.remove(), 200);
    try {
      if (a === 'end' || a === 'now') {
        const r = await api('POST', `/api/tasks/${t.id}/complete`, { actual_end: (a === 'end' ? planEnd : new Date()).toISOString() });
        toast(`✓ “${t.title}” completed`); refresh(); offerBackToParent(r).catch(() => {});
      }
      if (a === 'pick') completeModal(await api('GET', `/api/tasks/${t.id}`));
      if (a === 'more') toast('OK — I will ask again in 15 minutes');
    } catch (x) {
      // finishing after the planned time needs a reason -> open the normal complete window
      if (/reason/i.test(x.message)) completeModal(await api('GET', `/api/tasks/${t.id}`)); else toast(x.message, 'error');
    }
  });
  pushAlert(el);
  playChime();
  flashTitle(`⏰ Is “${t.title}” done?`);
}

async function pollNotifications() {
  if (!state.user) return;
  // keep my running tasks known on every page, so the "is it done?" reminder works everywhere
  api('GET', '/api/tasks?status=in_progress').then((rows) => { state.watch = rows.filter((x) => x.user_id === state.user.id); }).catch(() => {});
  // my planned tasks (all dates) - used for the reminders
  api('GET', '/api/tasks?status=pending').then((rows) => { state.pendingMine = rows.filter((x) => x.user_id === state.user.id && x.start_time); }).catch(() => {});
  // admin: alert when an employee's task becomes overdue
  if (state.user.role === 'admin') checkOverdueForAdmin().catch(() => {});
  try {
    const rows = await api('GET', '/api/notifications/unread');
    const fresh = rows.filter((n) => !state.shownNotif.has(n.id)).reverse();
    if (!fresh.length) return;
    fresh.forEach((n) => { state.shownNotif.add(n.id); showAlertCard(n); });
    playChime();
    const assignedCount = fresh.filter((n) => n.type === 'assigned').length;
    flashTitle(assignedCount ? `🔔 ${assignedCount} new task${assignedCount > 1 ? 's' : ''}!` : '🔔 New update');
    if (assignedCount && ['my', 'mytasks'].includes(location.hash.replace(/^#\//, '').split('/')[0]) && !$('.modal-back')) router();
  } catch { /* ignore */ }
}

const commentBtn = (t) => `<button type="button" class="btn sm cmt-btn ${state.unread.has(t.id) ? 'new' : ''}" data-comments="${t.id}" data-cmt-unread="${t.id}" title="Comments">💬${t.comment_count ? ` ${t.comment_count}` : ''}</button>`;

// ============================================================ DAILY REPORT (admin: everyone, employee: own)
function dayResult(t) {
  if (t.status === 'pending') return '<span class="badge s-pending">Not started</span>';
  if (t.status === 'in_progress') return `<span class="badge s-in_progress">Still working</span>${t.overdue ? ` <span class="badge s-overdue">Over by ${dur(t.late_by_minutes)}</span>` : ''}`;
  if (t.status === 'on_hold') return `<span class="badge s-on_hold">On hold</span>${t.overdue ? ` <span class="badge s-overdue">Over by ${dur(t.late_by_minutes)}</span>` : ''}`;
  if (t.is_late) return `<span class="badge s-overdue">Late by ${dur(t.late_by_minutes)}</span>${t.reason_status === 'accepted' ? ' <span class="badge r-accepted">Reason OK</span>' : ''}`;
  return '<span class="badge s-completed">On time</span>';
}

function extraTime(t) {
  if (t.worked_minutes == null || t.planned_minutes == null) return '<span class="muted">—</span>';
  const diff = t.worked_minutes - t.planned_minutes;
  if (Math.abs(diff) < 1) return '<span class="muted">Exact</span>';
  return diff > 0 ? `<b style="color:var(--red)">+${dur(diff)} more</b>` : `<span style="color:var(--green)">${dur(-diff)} less</span>`;
}

function employeeDaySection(r) {
  const tasks = r.tasks;
  const total = tasks.reduce((s, t) => s + (t.worked_minutes || 0), 0);
  const longest = tasks.find((t) => t.id === r.longest_task_id);
  return `<div class="card day-emp" id="emp-${r.user.id}" style="margin-bottom:18px">
    <div class="card-h">
      ${avatar(r.user.name)}
      <div><h3>${esc(r.user.name)} ${leaveBadge(r.leave)}</h3><div class="t-sub">${esc([r.user.designation, r.user.department].filter(Boolean).join(' · '))}</div></div>
      ${amAdmin() ? `<div class="right" style="text-align:right">
        <div style="font-size:26px;font-weight:700;color:${scoreColor(r.score)};line-height:1">${r.score != null ? r.score + '%' : '—'}</div>
        <div>${stars(r.stars)} <span class="t-sub">${r.grade}</span></div>
      </div>` : ''}
    </div>
    <div class="day-stats">
      <div><b>${tasks.length}</b><span>Total tasks</span></div>
      <div><b>${r.completed}</b><span>Completed</span></div>
      <div><b style="color:var(--green)">${r.on_time}</b><span>On time</span></div>
      <div><b style="color:var(--red)">${r.late + r.overdue_open}</b><span>Late / over time</span></div>
      <div><b>${dur(total)}</b><span>Total time worked</span></div>
      <div><b>${dur(r.break_minutes || 0)}</b><span>Breaks</span></div>
      <div><b style="color:${r.overtime_minutes ? 'var(--amber)' : 'inherit'}">${dur(r.overtime_minutes || 0)}</b><span>Overtime (over ${r.work_hours || 8}h)</span></div>
    </div>
    ${tasks.length ? `<div class="table-wrap"><table class="day-table">
      <thead><tr><th>#</th><th>Task</th><th>Start</th><th>Expected end</th><th>Finished at</th><th>Planned</th><th>Time taken</th><th>Extra time</th><th>Result</th></tr></thead>
      <tbody>${tasks.map((t, i) => `<tr class="click ${t.id === r.longest_task_id && tasks.length > 1 ? 'longest' : ''}" data-open="${t.id}">
        <td>${i + 1}</td>
        <td><div class="t-title">${esc(t.title)} ${t.id === r.longest_task_id && tasks.length > 1 ? '<span class="badge plain tone-violet">⏱ Most time</span>' : ''}</div>
          <div class="t-sub">${prBadge(t.priority)}${t.parent_title ? ` ↳ came in during "${esc(t.parent_title)}"` : ''}</div>
          ${t.delay_reason ? `<div class="t-sub" style="color:var(--amber)">Reason: ${esc(t.delay_reason)}</div>` : ''}</td>
        <td class="nowrap">${t.start_time && t.status !== 'pending' ? fmtTimeOnly(t.start_time) : '—'}</td>
        <td class="nowrap">${fmtTimeOnly(t.expected_end)}</td>
        <td class="nowrap">${t.status === 'completed' ? fmtTimeOnly(t.actual_end) : '—'}</td>
        <td class="nowrap">${dur(t.planned_minutes)}</td>
        <td class="nowrap" style="min-width:130px"><b>${dur(t.worked_minutes)}</b>
          ${total && t.worked_minutes ? `<div class="bar" style="margin-top:4px"><i style="width:${Math.round((t.worked_minutes / total) * 100)}%;background:${t.id === r.longest_task_id ? 'var(--violet)' : 'var(--primary-2)'}"></i></div>` : ''}</td>
        <td class="nowrap">${extraTime(t)}</td>
        <td class="nowrap">${dayResult(t)}</td>
      </tr>`).join('')}</tbody></table></div>
      ${longest && longest.worked_minutes ? `<div class="day-foot">⏱ Most time spent on: <b>${esc(longest.title)}</b> — ${dur(longest.worked_minutes)} (${Math.round((longest.worked_minutes / Math.max(total, 1)) * 100)}% of the day)</div>` : ''}`
    : empty('📭', 'No tasks recorded for this day')}
  </div>`;
}

const fmtTimeOnly = (iso) => {
  if (!iso) return '—';
  const d = new Date(iso);
  const t = d.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', hour12: true });
  const day = new Date(state.reportDate + 'T00:00');
  return d.toDateString() === day.toDateString() ? t : `${d.toLocaleDateString('en-IN', { day: '2-digit', month: 'short' })}, ${t}`;
};

async function renderDailyReport() {
  clearInterval(state.refreshTimer);
  if (!state.reportDate) state.reportDate = toLocalInput(new Date()).slice(0, 10);
  const dayStart = new Date(state.reportDate + 'T00:00');
  const dayEnd = new Date(dayStart); dayEnd.setDate(dayEnd.getDate() + 1);
  const isAdmin = state.user.role === 'admin';
  const rows = await api('GET', `/api/reports/daily?${qs({ from: dayStart.toISOString(), to: dayEnd.toISOString() })}`);
  const isToday = state.reportDate === toLocalInput(new Date()).slice(0, 10);
  const dayLabel = dayStart.toLocaleDateString('en-IN', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });

  $('#view').innerHTML = `
    <div class="page-head">
      <div><h2>${isAdmin ? 'Daily Report' : 'My Daily Report'}</h2><div class="muted">${dayLabel}${isToday ? ' · Today (updates live)' : ''}</div></div>
      <div class="right no-print">
        <button class="btn" id="d-prev">◀</button>
        <input type="date" id="d-date" value="${state.reportDate}" max="${toLocalInput(new Date()).slice(0, 10)}" style="width:auto">
        <button class="btn" id="d-next" ${isToday ? 'disabled' : ''}>▶</button>
        <button class="btn" id="d-today" ${isToday ? 'disabled' : ''}>Today</button>
        <button class="btn primary" onclick="window.print()">🖨 Print</button>
      </div>
    </div>
    ${isAdmin ? `<div class="card" style="margin-bottom:18px">
      <div class="card-h"><h3>Team summary</h3><span class="right muted small">Click a name to see that person's tasks</span></div>
      ${rows.length ? `<div class="table-wrap"><table>
        <thead><tr><th>Employee</th><th>Day rating</th><th>Tasks</th><th>Completed</th><th>On time</th><th>Late / over time</th><th>Total time worked</th><th>Breaks</th><th>Overtime</th><th>Most time spent on</th></tr></thead>
        <tbody>${rows.map((r) => {
          const longest = r.tasks.find((t) => t.id === r.longest_task_id);
          const total = r.tasks.reduce((s, t) => s + (t.worked_minutes || 0), 0);
          return `<tr class="click" data-jump="${r.user.id}">
            <td><div class="row" style="gap:10px;flex-wrap:nowrap">${avatar(r.user.name, 'sm')}<b>${esc(r.user.name)}</b> ${leaveBadge(r.leave)}</div></td>
            <td class="nowrap"><b style="color:${scoreColor(r.score)};font-size:16px">${r.score != null ? r.score + '%' : '—'}</b> ${stars(r.stars)}</td>
            <td>${r.tasks.length}</td><td>${r.completed}</td>
            <td style="color:var(--green);font-weight:600">${r.on_time}</td>
            <td style="color:${r.late + r.overdue_open ? 'var(--red)' : 'inherit'};font-weight:600">${r.late + r.overdue_open}</td>
            <td><b>${dur(total)}</b></td>
            <td>${dur(r.break_minutes || 0)}</td>
            <td style="color:${r.overtime_minutes ? 'var(--amber)' : 'inherit'};font-weight:600">${r.overtime_minutes ? dur(r.overtime_minutes) : '—'}</td>
            <td>${longest && longest.worked_minutes ? `${esc(longest.title)} <span class="t-sub">(${dur(longest.worked_minutes)})</span>` : '<span class="muted">—</span>'}</td>
          </tr>`;
        }).join('')}</tbody></table></div>` : empty('👥', 'No employees yet')}
    </div>` : ''}
    ${rows.map(employeeDaySection).join('')}
    ${isAdmin ? `<div class="card card-b small muted">Day rating = how well tasks were finished within the expected time that day. On time = 100%. Late = planned time ÷ time taken (hold time not counted). Urgent/High tasks count more.</div>` : ''}`;

  const go = (d) => { state.reportDate = d; renderDailyReport(); };
  const shift = (n) => { const d = new Date(dayStart); d.setDate(d.getDate() + n); go(toLocalInput(d).slice(0, 10)); };
  $('#d-prev').onclick = () => shift(-1);
  $('#d-next').onclick = () => shift(1);
  $('#d-today').onclick = () => go(toLocalInput(new Date()).slice(0, 10));
  $('#d-date').onchange = (e) => e.target.value && go(e.target.value);
  $$('[data-jump]').forEach((tr) => tr.onclick = () => $(`#emp-${tr.dataset.jump}`).scrollIntoView({ behavior: 'smooth' }));
  if (state.scrollTo) { $(`#emp-${state.scrollTo}`)?.scrollIntoView({ behavior: 'smooth' }); state.scrollTo = null; }
  if (isToday) state.refreshTimer = setInterval(() => { if (!$('.modal-back') && location.hash === '#/daily') renderDailyReport(); }, 60000);
}

// ============================================================ ADMIN: dashboard
async function renderAdminDashboard() {
  clearInterval(state.refreshTimer);
  const d0 = new Date(); d0.setHours(0, 0, 0, 0);
  const d1 = new Date(d0); d1.setDate(d1.getDate() + 1);
  const [d, ratings, today, trend] = await Promise.all([
    api('GET', '/api/stats/dashboard'),
    api('GET', `/api/stats/ratings?${qs(periodRange('month'))}`),
    api('GET', `/api/reports/daily?${qs({ from: d0.toISOString(), to: d1.toISOString() })}`),
    loadTrend(14),
  ]);
  const k = d.kpi;
  const todayScored = today.filter((r) => r.score != null);
  const teamToday = todayScored.length ? Math.round(todayScored.reduce((s, r) => s + r.score, 0) / todayScored.length) : null;
  const hoursToday = today.reduce((s, r) => s + r.tasks.reduce((x, t) => x + (t.worked_minutes || 0), 0), 0);
  const kpi = (ico, tone, val, lbl, sub, href) => `<a class="card kpi" ${href ? `href="${href}"` : ''} style="color:inherit"><div class="k-ico tone-${tone}">${ico}</div>
    <div><div class="k-val">${val}</div><div class="k-lbl">${lbl}</div>${sub ? `<div class="k-sub">${sub}</div>` : ''}</div></a>`;
  const evTone = { created: 'blue', started: 'blue', paused: 'amber', resumed: 'blue', completed: 'green', edited: 'gray', reviewed: 'violet', reason: 'amber' };
  const evIco = { created: '➕', started: '▶', paused: '⏸', resumed: '▶', completed: '✓', edited: '✎', reviewed: '⚖', reason: '✎' };
  const hr = new Date().getHours();
  const stateLabel = { working: '● Working', on_hold: '⏸ On hold', idle: 'Idle', on_leave: '🌴 On leave' };
  await pollUnread();
  const newComments = state.unreadRows || [];
  const attention = k.overdue + k.pending_reviews + newComments.length;

  const empCard = (l) => {
    const r = today.find((x) => x.user.id === l.user.id) || { tasks: [], completed: 0, on_time: 0, late: 0, overdue_open: 0, score: null };
    const run = l.tasks.find((t) => t.status === 'in_progress') || l.tasks[0];
    const total = r.tasks.reduce((s, t) => s + (t.worked_minutes || 0), 0);
    const longest = r.tasks.find((t) => t.id === r.longest_task_id);
    return `<div class="emp-card">
      <div class="ec-top">${avatar(l.user.name)}
        <div style="min-width:0"><div class="ec-name">${esc(l.user.name)}</div><div class="ec-role">${esc(l.user.designation || l.user.department || 'Employee')}</div></div>
        <span class="ec-state ${l.state}">${l.state === 'on_leave' && l.leave?.type === 'holiday' ? '🎉 Holiday' : stateLabel[l.state]}</span></div>
      <div class="ec-now">${run ? `<div class="lbl">${run.status === 'on_hold' ? 'On hold' : 'Working on now'}</div>
          <div class="row" style="flex-wrap:nowrap;gap:8px"><a href="#" class="ttl" data-open="${run.id}">${esc(run.title)}</a>
          <span style="margin-left:auto" class="timer" data-live="timer" ${liveAttrs(run)}></span></div>
          <div class="small" data-live="remain" ${liveAttrs(run)}></div>`
        : `<div class="lbl">Working on now</div><div class="muted">No active task</div>`}</div>
      <div class="ec-body">
        <div class="mini-ring" style="--v:${r.score ?? 0};--c:${scoreColor(r.score)}"><div><div><b>${r.score != null ? r.score + '%' : isOff(r.leave) ? '🌴' : '—'}</b><span>${r.score == null && isOff(r.leave) ? (r.leave.type === 'holiday' ? 'holiday' : 'on leave') : 'today'}</span></div></div></div>
        <div class="ec-stats">
          <div><b>${r.completed}/${r.tasks.length}</b><span>Tasks done</span></div>
          <div><b>${dur(total)}</b><span>Time worked</span></div>
          <div><b style="color:var(--green)">${r.on_time}</b><span>On time</span></div>
          <div><b style="color:${r.late + r.overdue_open ? 'var(--red)' : 'inherit'}">${r.late + r.overdue_open}</b><span>Late</span></div>
        </div>
      </div>
      <div class="ec-foot"><span class="most">${longest && longest.worked_minutes ? `⏱ Most time: <b>${esc(longest.title)}</b> (${dur(longest.worked_minutes)})` : '<span class="muted">No time logged yet today</span>'}</span>
        <a href="#/daily" data-scroll-emp="${l.user.id}" class="nowrap">Day report →</a></div>
    </div>`;
  };

  $('#view').innerHTML = `
    <div class="hero">
      <div style="position:relative;z-index:1">
        <h2>Good ${hr < 12 ? 'morning' : hr < 17 ? 'afternoon' : 'evening'}, ${esc(state.user.name.split(' ')[0])} 👋</h2>
        <div class="hero-date">${new Date().toLocaleDateString('en-IN', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })}</div>
        <div class="hero-line">
          <span>👥 ${k.working_now} of ${k.employees} working now</span>${k.on_leave ? `<span>🌴 ${k.on_leave} on leave</span>` : ''}
          <span>✓ ${k.completed_today} tasks completed today</span>
          <span>${attention ? `⚠ ${attention} need your attention` : '✅ Nothing needs attention'}</span>
        </div>
      </div>
      <div class="hero-actions">
        <button class="btn light" id="ai-btn">✨ Assistant</button>
        <a class="btn light" href="#/daily">📅 Today's report</a>
        <button class="btn white" id="assign-btn">＋ Assign task</button>
      </div>
    </div>
    <div class="kpis">
      ${kpi('🏆', 'violet', teamToday != null ? teamToday + '%' : '—', 'Team rating today', teamToday != null ? gradeText(teamToday) : 'No completed work yet', '#/daily')}
      ${kpi('👥', 'green', `${k.working_now}/${k.employees}`, 'Working right now', `${k.on_hold} on hold${k.on_leave ? ` · ${k.on_leave} on leave` : ''}`)}
      ${kpi('✓', 'blue', k.completed_today, 'Completed today', `${dur(hoursToday)} worked in total`, '#/daily')}
      ${kpi('⚠', 'red', k.overdue, 'Overdue right now', k.overdue ? 'Crossed expected end time' : 'All on schedule', '#/tasks')}
      ${kpi('📝', 'amber', k.pending_reviews, 'Delay reasons to review', k.pending_reviews ? 'Waiting for your decision' : 'All reviewed', '#/reviews')}
    </div>

    <div class="section-title"><h3>Your team today</h3><span class="muted small">Live — updates every 30 seconds</span>
      <a class="right small" href="#/employees">Manage employees →</a></div>
    ${d.live.length ? `<div class="emp-grid">${d.live.map(empCard).join('')}</div>`
      : `<div class="card">${empty('👥', 'No employees yet.<br><br><a class="btn primary" href="#/employees">＋ Add your first employee</a>')}</div>`}

    <div class="section-title"><h3>Office progress</h3><span class="muted small">Ratings are visible to admin only</span>
      <a class="right small" href="#/performance">Full progress report →</a></div>
    <div class="grid g-3-1">
      <div class="card">
        <div class="card-h"><div class="h-ico tone-violet">📈</div><div><h3>Team rating — last 14 days</h3><div class="t-sub">Average rating of all employees, each day</div></div></div>
        <div class="card-b">${lineChart(trendPoints(trend), { h: 210 })}</div>
      </div>
      <div class="stack">
        <div class="card">
          <div class="card-h"><div class="h-ico tone-blue">🗂</div><h3>Today's tasks</h3><span class="right t-sub">${today.reduce((s, r) => s + r.tasks.length, 0)} total</span></div>
          <div class="card-b">${statusSplit(today.flatMap((r) => r.tasks))}</div>
        </div>
      </div>
    </div>
    <div class="card" style="margin-top:20px">
      <div class="card-h"><div class="h-ico tone-green">🏅</div><h3>Employee-wise rating — this month</h3><span class="right t-sub">Click a name for the full report</span></div>
      <div class="card-b">${ratingBars(ratings, true)}</div>
    </div>

    <div class="grid g-2" style="margin-top:20px">
      <div class="card">
        <div class="card-h"><div class="h-ico tone-red">⚠</div><h3>Needs attention</h3><a class="right small" href="#/tasks">All tasks →</a></div>
        <div class="live-list">
          ${k.pending_reviews ? `<a class="live-row click" href="#/reviews" style="color:inherit"><div class="lr-main"><div class="t-title">📝 ${k.pending_reviews} delay reason(s) waiting for review</div>
            <div class="lr-task">Accept or reject so ratings are fair</div></div><span class="btn sm warn">Review</span></a>` : ''}
          ${newComments.slice(0, 5).map((r) => `<a class="live-row click" href="#" data-comments="${r.task_id}" style="color:inherit">
            ${avatar(r.last_by || '?', 'sm')}<div class="lr-main"><div class="t-title">💬 ${esc(r.last_by)} commented on “${esc(r.title)}”</div>
            <div class="lr-task">${esc(r.last_body)}</div></div><span class="badge plain tone-blue">${r.count} new</span></a>`).join('')}
          ${d.overdue.map((t) => `<div class="live-row click" data-open="${t.id}" style="cursor:pointer">
            ${avatar(t.user_name, 'sm')}<div class="lr-main"><div class="t-title">${esc(t.title)}</div><div class="lr-task">${esc(t.user_name)} · was due ${fmtSmart(t.expected_end)}</div></div>
            <span class="badge s-overdue">${dur(t.late_by_minutes)} over</span></div>`).join('')}
          ${!attention ? empty('✅', 'All good — nothing overdue, nothing to review, no new comments.') : ''}
        </div>
      </div>
      <div class="card">
        <div class="card-h"><div class="h-ico tone-blue">🕒</div><h3>Recent activity</h3></div>
        <div class="feed">${d.activity.length ? d.activity.map((e) => `<div class="feed-item">
          <div class="feed-ico tone-${evTone[e.type] || 'gray'}">${evIco[e.type] || '•'}</div>
          <div style="flex:1;min-width:0"><b>${esc(e.user_name || '—')}</b> ${esc(e.type)} <a href="#" data-open="${e.task_id}">${esc(e.task_title)}</a>
            ${e.note && e.type !== 'started' && e.type !== 'created' ? `<div class="t-sub">${esc(e.note.slice(0, 120))}</div>` : ''}</div>
          <div class="t-sub nowrap">${fmtSmart(e.at)}</div></div>`).join('') : empty('🕒', 'No activity yet')}</div>
      </div>
    </div>`;
  $('#assign-btn').onclick = () => taskFormModal();
  $('#ai-btn').onclick = () => showAssistant();
  tick();
  state.refreshTimer = setInterval(() => { if (!$('.modal-back')) router(); }, 30000);
}

function leaderboard(rows, compact = false) {
  if (!rows.length) return empty('🏆', 'No employees yet');
  return `<div class="table-wrap"><table><thead><tr><th>#</th><th>Employee</th><th>Score</th><th>Rating</th>${compact ? '' : '<th>Tasks</th><th>Completed</th><th>On time</th><th>Late</th><th>Overdue now</th><th>Hours worked</th>'}</tr></thead>
    <tbody>${rows.map((r, i) => `<tr class="click" onclick="location.hash='#/employee/${r.user.id}'">
      <td><div class="rank ${r.score != null && i < 3 ? 'r' + (i + 1) : ''}">${i + 1}</div></td>
      <td><div class="row" style="gap:10px;flex-wrap:nowrap">${avatar(r.user.name, 'sm')}<div><div class="t-title">${esc(r.user.name)}</div><div class="t-sub">${esc(r.user.designation || r.user.department || '')}</div></div></div></td>
      <td>${scoreCell(r.score)}</td>
      <td class="nowrap">${stars(r.stars)}<div class="t-sub">${r.grade}</div></td>
      ${compact ? '' : `<td>${r.total}</td><td>${r.completed}</td><td>${r.on_time_rate != null ? r.on_time_rate + '%' : '—'} <span class="t-sub">(${r.on_time})</span></td>
        <td>${r.late}</td><td>${r.overdue_open ? `<span class="badge s-overdue">${r.overdue_open}</span>` : '0'}</td><td>${dur(r.worked_minutes)}</td>`}
    </tr>`).join('')}</tbody></table></div>`;
}

// ============================================================ ADMIN: all tasks
async function renderAllTasks() {
  const f = state.taskFilters || (state.taskFilters = { user_id: '', status: '', priority: '', period: 'week', q: '' });
  const employees = state.users.filter((u) => u.role === 'employee');
  $('#view').innerHTML = `
    <div class="page-head"><div><h2>All tasks</h2><div class="muted">Every task of every employee. Use the filters to find anything; click a row to see its full history.</div></div>
      <div class="right"><button class="btn" id="export-btn">⬇ Export Excel (CSV)</button><button class="btn primary" id="assign-btn">＋ Assign Task</button></div></div>
    <div class="card">
      <div class="filters">
        <input type="search" id="f-q" placeholder="Search task, category…" value="${esc(f.q)}">
        <select id="f-user"><option value="">All employees</option>${employees.map((u) => `<option value="${u.id}" ${String(u.id) === String(f.user_id) ? 'selected' : ''}>${esc(u.name)}</option>`).join('')}</select>
        <select id="f-status"><option value="">All statuses</option>${[['active', 'Active (running + hold)'], ['in_progress', 'In Progress'], ['on_hold', 'On Hold'], ['pending', 'Planned'], ['completed', 'Completed'], ['overdue', 'Overdue'], ['archived', '🗃 Archived']].map(([v, l]) => `<option value="${v}" ${f.status === v ? 'selected' : ''}>${l}</option>`).join('')}</select>
        <select id="f-priority"><option value="">All priorities</option>${Object.entries(PRIORITY_LABEL).map(([v, l]) => `<option value="${v}" ${f.priority === v ? 'selected' : ''}>${l}</option>`).join('')}</select>
        <select id="f-period">${PERIODS.map(([v, l]) => `<option value="${v}" ${f.period === v ? 'selected' : ''}>${l}</option>`).join('')}</select>
      </div>
      <div id="task-list"><div class="empty">Loading…</div></div>
    </div>`;
  const params = () => ({ user_id: f.user_id, status: f.status, priority: f.priority, q: f.q, ...periodRange(f.period) });
  const load = async () => {
    const tasks = await api('GET', `/api/tasks?${qs(params())}`);
    $('#task-list').innerHTML = `<div class="card-h" style="border-top:0"><span class="muted">${tasks.length} task(s)</span></div>${taskTable(tasks, { showUser: true })}`;
    tick();
  };
  const bind = (id, key, ev = 'change') => $(id).addEventListener(ev, (e) => { f[key] = e.target.value; load(); });
  bind('#f-user', 'user_id'); bind('#f-status', 'status'); bind('#f-priority', 'priority'); bind('#f-period', 'period');
  let tmr; $('#f-q').addEventListener('input', (e) => { clearTimeout(tmr); tmr = setTimeout(() => { f.q = e.target.value; load(); }, 300); });
  $('#assign-btn').onclick = () => taskFormModal();
  $('#export-btn').onclick = () => { location.href = `/api/export/tasks.csv?${qs(params())}`; };
  await load();
}

// ============================================================ ADMIN: reviews
async function renderReviews() {
  const tab = state.reviewTab || 'pending';
  const tasks = await api('GET', `/api/tasks?reason_status=${tab}`);
  $('#view').innerHTML = `
    <div class="page-head"><div><h2>Delay reason reviews</h2><div class="muted">When an employee finishes late, they must give a reason. Accept fair reasons so their score is not reduced.</div></div></div>
    <div class="card">
      <div class="tabs">${[['pending', 'Waiting for review'], ['accepted', 'Accepted'], ['rejected', 'Rejected']].map(([v, l]) => `<button data-tab="${v}" class="${tab === v ? 'on' : ''}">${l}</button>`).join('')}</div>
      ${tasks.length ? `<div class="table-wrap"><table><thead><tr><th>Employee</th><th>Task</th><th>Expected → Actual</th><th>Late by</th><th>Reason</th><th></th></tr></thead><tbody>
        ${tasks.map((t) => `<tr class="click" data-open="${t.id}">
          <td class="nowrap"><div class="row" style="gap:8px">${avatar(t.user_name, 'sm')}${esc(t.user_name)}</div></td>
          <td><div class="t-title">${esc(t.title)}</div><div class="t-sub">${prBadge(t.priority)}</div></td>
          <td class="nowrap">${fmtSmart(t.expected_end)}<br>→ ${fmtSmart(t.actual_end)}</td>
          <td><span class="badge s-overdue">${dur(t.late_by_minutes)}</span></td>
          <td style="max-width:360px">${esc(t.delay_reason)}${t.admin_note ? `<div class="t-sub">Your note: ${esc(t.admin_note)}</div>` : ''}</td>
          <td class="nowrap"><button class="btn sm ${tab === 'pending' ? 'warn' : ''}" data-act="review" data-id="${t.id}">${tab === 'pending' ? 'Review' : 'Change'}</button></td></tr>`).join('')}
      </tbody></table></div>` : empty('✅', tab === 'pending' ? 'No reasons waiting for review' : 'Nothing here')}
    </div>`;
  $$('[data-tab]').forEach((b) => b.addEventListener('click', () => { state.reviewTab = b.dataset.tab; renderReviews(); }));
}

// ============================================================ charts (plain SVG, no internet needed)
const shortDay = (iso) => new Date(iso).toLocaleDateString('en-IN', { day: '2-digit', month: 'short' });
const longDay = (iso) => new Date(iso).toLocaleDateString('en-IN', { weekday: 'short', day: 'numeric', month: 'short' });

// Single-series trend line (0-100%). Gaps where there is no data.
function lineChart(pts, { h = 230, max = 100, suffix = '%' } = {}) {
  if (!pts.length) return empty('📈', 'No data yet');
  const W = 680, H = h, L = 40, R = 14, T = 16, B = 30;
  const n = pts.length, step = (W - L - R) / Math.max(n - 1, 1);
  const x = (i) => (n === 1 ? (L + W - R) / 2 : L + i * step);
  const y = (v) => T + (1 - v / max) * (H - T - B);
  const grid = [0, 25, 50, 75, 100].map((g) => `<line x1="${L}" x2="${W - R}" y1="${y(g)}" y2="${y(g)}" stroke="${g ? '#eceef4' : '#d9dce7'}"/>
    <text x="${L - 8}" y="${y(g) + 4}" text-anchor="end" class="ax">${g}${suffix}</text>`).join('');
  // contiguous segments without nulls
  const segs = []; let cur = [];
  pts.forEach((p, i) => { if (p.value == null) { if (cur.length) segs.push(cur); cur = []; } else cur.push([x(i), y(p.value)]); });
  if (cur.length) segs.push(cur);
  const line = segs.map((s) => `<path d="M${s.map((q) => q.join(',')).join('L')}" fill="none" stroke="var(--primary)" stroke-width="2.5" stroke-linejoin="round" stroke-linecap="round"/>`).join('');
  const area = segs.filter((s) => s.length > 1).map((s) => `<path d="M${s[0][0]},${y(0)}L${s.map((q) => q.join(',')).join('L')}L${s[s.length - 1][0]},${y(0)}Z" fill="url(#lg-area)"/>`).join('');
  const every = Math.ceil(n / 8);
  const labels = pts.map((p, i) => (i % every === 0 || i === n - 1 ? `<text x="${x(i)}" y="${H - 8}" text-anchor="middle" class="ax">${esc(p.label)}</text>` : '')).join('');
  const dots = pts.map((p, i) => (p.value == null ? '' : `<circle cx="${x(i)}" cy="${y(p.value)}" r="4" fill="#fff" stroke="var(--primary)" stroke-width="2"/>`)).join('');
  const hits = pts.map((p, i) => `<rect x="${x(i) - step / 2}" y="${T}" width="${Math.max(step, 20)}" height="${H - T - B}" fill="transparent" data-tip="${esc(p.tip)}"/>`).join('');
  return `<svg class="chart" viewBox="0 0 ${W} ${H}" role="img"><defs><linearGradient id="lg-area" x1="0" x2="0" y1="0" y2="1">
    <stop offset="0" stop-color="#6366f1" stop-opacity=".22"/><stop offset="1" stop-color="#6366f1" stop-opacity="0"/></linearGradient></defs>
    ${grid}${area}${line}${dots}${labels}${hits}</svg>`;
}

// Single-series vertical bars (counts)
function barChart(pts, { h = 230, color = 'var(--primary-2)' } = {}) {
  if (!pts.length) return empty('📊', 'No data yet');
  const W = 680, H = h, L = 40, R = 14, T = 16, B = 30;
  const max = Math.max(4, ...pts.map((p) => p.value || 0));
  const nice = Math.ceil(max / 4) * 4;
  const n = pts.length, slot = (W - L - R) / n, bw = Math.min(34, slot - 4);
  const y = (v) => T + (1 - v / nice) * (H - T - B);
  const grid = [0, .25, .5, .75, 1].map((f) => `<line x1="${L}" x2="${W - R}" y1="${y(nice * f)}" y2="${y(nice * f)}" stroke="${f ? '#eceef4' : '#d9dce7'}"/>
    <text x="${L - 8}" y="${y(nice * f) + 4}" text-anchor="end" class="ax">${Math.round(nice * f)}</text>`).join('');
  const every = Math.ceil(n / 8);
  const bars = pts.map((p, i) => {
    const cx = L + slot * i + slot / 2, v = p.value || 0, top = y(v), bh = y(0) - top;
    return `${v ? `<path d="M${cx - bw / 2},${y(0)}V${top + Math.min(4, bh)}Q${cx - bw / 2},${top} ${cx - bw / 2 + 4},${top}H${cx + bw / 2 - 4}Q${cx + bw / 2},${top} ${cx + bw / 2},${top + Math.min(4, bh)}V${y(0)}Z" fill="${color}"/>` : ''}
      ${i % every === 0 || i === n - 1 ? `<text x="${cx}" y="${H - 8}" text-anchor="middle" class="ax">${esc(p.label)}</text>` : ''}
      <rect x="${cx - slot / 2}" y="${T}" width="${slot}" height="${H - T - B}" fill="transparent" data-tip="${esc(p.tip)}"/>`;
  }).join('');
  return `<svg class="chart" viewBox="0 0 ${W} ${H}" role="img">${grid}${bars}</svg>`;
}

// Employee-wise rating: horizontal bars with value + grade text (never colour alone)
function ratingBars(rows, wide = false) {
  if (!rows.length) return empty('👥', 'No employees yet');
  return `<div class="hbars ${wide ? 'wide' : ''}">${rows.map((r) => `<a class="hbar" href="#/employee/${r.user.id}" data-tip="${esc(`<b>${esc(r.user.name)}</b><br>Rating: ${r.score != null ? r.score + '%' : 'no data'}<br>${r.completed} completed · ${r.on_time} on time · ${r.late} late`)}">
      <div class="hb-name">${avatar(r.user.name, 'sm')}<span>${esc(r.user.name)}</span></div>
      <div class="hb-track"><i style="width:${r.score ?? 0}%;background:${scoreColor(r.score)}"></i></div>
      <div class="hb-val"><b>${r.score != null ? r.score + '%' : '—'}</b><span>${r.score != null ? r.grade : 'No data'}</span></div>
    </a>`).join('')}</div>`;
}

// Employee × day grid of daily ratings
function ratingHeatmap(trend) {
  const days = trend.days.slice(-14);
  if (!trend.users.length) return empty('👥', 'No employees yet');
  return `<div class="table-wrap"><table class="heat"><thead><tr><th>Employee</th>${days.map((d) => `<th class="c">${new Date(d.day).toLocaleDateString('en-IN', { weekday: 'narrow' })}<br><span>${new Date(d.day).getDate()}</span></th>`).join('')}</tr></thead>
    <tbody>${trend.users.map((u) => `<tr><td class="nowrap"><div class="row" style="gap:8px;flex-wrap:nowrap">${avatar(u.name, 'sm')}${esc(u.name)}</div></td>
      ${days.map((d) => {
        const e = d.employees.find((x) => x.id === u.id);
        const s = e ? e.score : null;
        const tip = `<b>${esc(u.name)}</b> · ${longDay(d.day)}<br>${s != null ? `Rating ${s}% (${gradeText(s)})` : 'No rated work'}<br>${e ? `${e.completed}/${e.tasks} tasks done` : ''}`;
        if (s == null && e && (e.leave === 'leave' || e.leave === 'holiday')) {
          return `<td class="c"><span class="hc lv" data-tip="${esc(`<b>${esc(u.name)}</b> · ${longDay(d.day)}<br>${e.leave === 'holiday' ? 'Office holiday' : 'On leave'}`)}">${e.leave === 'holiday' ? 'H' : 'L'}</span></td>`;
        }
        return `<td class="c"><span class="hc ${s == null ? 'none' : s >= 90 ? 'g' : s >= 75 ? 'b' : s >= 60 ? 'a' : 'r'}" data-tip="${esc(tip)}">${s != null ? s : '·'}</span></td>`;
      }).join('')}</tr>`).join('')}</tbody></table></div>
    <div class="legend"><span><i class="hc g"></i>90+ Excellent</span><span><i class="hc b"></i>75–89 Good</span><span><i class="hc a"></i>60–74 Average</span><span><i class="hc r"></i>Below 60</span><span><i class="hc lv"></i>L / H = Leave / Holiday</span><span><i class="hc none"></i>No work logged</span></div>`;
}

// Today's tasks split by state, as one stacked bar + labelled legend
function statusSplit(tasks) {
  const parts = [
    ['On time', tasks.filter((t) => t.status === 'completed' && !t.is_late).length, 'var(--green)'],
    ['Late', tasks.filter((t) => t.status === 'completed' && t.is_late).length, 'var(--red)'],
    ['In progress', tasks.filter((t) => t.status === 'in_progress').length, 'var(--blue)'],
    ['On hold', tasks.filter((t) => t.status === 'on_hold').length, 'var(--amber)'],
    ['Not started', tasks.filter((t) => t.status === 'pending').length, '#c3c9d6'],
  ];
  const total = parts.reduce((s, p) => s + p[1], 0);
  if (!total) return empty('🗒️', 'No tasks today yet');
  return `<div class="stackbar">${parts.filter((p) => p[1]).map(([l, v, c]) => `<i style="flex:${v};background:${c}" data-tip="<b>${l}</b>: ${v} task(s)"></i>`).join('')}</div>
    <div class="split-legend">${parts.map(([l, v, c]) => `<div><i style="background:${c}"></i><span>${l}</span><b>${v}</b></div>`).join('')}</div>`;
}

// Shared hover tooltip for every [data-tip]
(() => {
  const tip = document.createElement('div');
  tip.className = 'chart-tip';
  document.body.appendChild(tip);
  document.addEventListener('mousemove', (e) => {
    const el = e.target.closest && e.target.closest('[data-tip]');
    if (!el) { tip.style.opacity = 0; return; }
    tip.innerHTML = el.dataset.tip;
    const r = tip.getBoundingClientRect();
    tip.style.left = `${Math.min(e.clientX + 14, window.innerWidth - r.width - 8)}px`;
    tip.style.top = `${Math.max(8, e.clientY - r.height - 12)}px`;
    tip.style.opacity = 1;
  });
})();

async function loadTrend(days) {
  const d0 = new Date(); d0.setHours(0, 0, 0, 0); d0.setDate(d0.getDate() - (days - 1));
  return api('GET', `/api/stats/trend?${qs({ from: d0.toISOString(), days })}`);
}
const trendPoints = (trend) => trend.days.map((d) => ({
  label: shortDay(d.day), value: d.team_score,
  tip: `<b>${longDay(d.day)}</b><br>Team rating: ${d.team_score != null ? d.team_score + '%' : 'no data'}<br>${d.completed} task(s) completed · ${dur(d.worked_minutes)} worked`,
}));
const completedPoints = (trend) => trend.days.map((d) => ({
  label: shortDay(d.day), value: d.completed, tip: `<b>${longDay(d.day)}</b><br>${d.completed} task(s) completed<br>${dur(d.worked_minutes)} worked`,
}));

// ============================================================ ADMIN: office progress
async function renderPerformance() {
  const days = state.trendDays || 14;
  const [ratings, trend] = await Promise.all([
    api('GET', `/api/stats/ratings?${qs(periodRange(state.period))}`),
    loadTrend(days),
  ]);
  const scored = ratings.filter((r) => r.score != null);
  const avg = scored.length ? Math.round(scored.reduce((s, r) => s + r.score, 0) / scored.length) : null;
  const best = scored[0];
  const totalDone = ratings.reduce((s, r) => s + r.completed, 0);
  const totalMin = ratings.reduce((s, r) => s + r.worked_minutes, 0);
  const onTime = ratings.reduce((s, r) => s + r.on_time, 0);
  const valid = trend.days.filter((d) => d.team_score != null);
  const change = valid.length >= 2 ? valid[valid.length - 1].team_score - valid[0].team_score : null;
  const periodName = PERIODS.find((p) => p[0] === state.period)[1];
  const kpi = (ico, tone, val, lbl, sub) => `<div class="card kpi"><div class="k-ico tone-${tone}">${ico}</div><div><div class="k-val">${val}</div><div class="k-lbl">${lbl}</div>${sub ? `<div class="k-sub">${sub}</div>` : ''}</div></div>`;

  $('#view').innerHTML = `
    <div class="page-head"><div><h2>Office progress</h2><div class="muted">How the team and each employee are performing. Visible to admin only.</div></div>
      <div class="right">${periodSelect()}<button class="btn" onclick="window.print()">🖨 Print</button></div></div>
    <div class="kpis">
      ${kpi('🏆', 'violet', avg != null ? avg + '%' : '—', `Team rating · ${periodName}`, avg != null ? gradeText(avg) : 'No completed work yet')}
      ${kpi('⭐', 'green', best ? esc(best.user.name.split(' ')[0]) : '—', 'Top performer', best ? `${best.score}% · ${best.grade}` : '')}
      ${kpi('✓', 'blue', totalDone, 'Tasks completed', totalDone ? `${Math.round((onTime / totalDone) * 100)}% finished on time` : '')}
      ${kpi('⏱', 'amber', dur(totalMin), 'Total time worked', `${ratings.length} employee(s)`)}
    </div>
    <div class="grid g-3-1" style="margin-bottom:20px">
      <div class="card">
        <div class="card-h"><div class="h-ico tone-violet">📈</div><div><h3>Team rating — day by day</h3>
          <div class="t-sub">${change != null ? `${change >= 0 ? '▲' : '▼'} ${Math.abs(change)} points over this period` : 'Average of all employees each day'}</div></div>
          <div class="right"><div class="seg" style="margin:0" id="days-seg">${[7, 14, 30].map((d) => `<button data-days="${d}" class="${d === days ? 'on' : ''}">${d} days</button>`).join('')}</div></div></div>
        <div class="card-b">${lineChart(trendPoints(trend))}</div>
      </div>
      <div class="card">
        <div class="card-h"><div class="h-ico tone-green">🏅</div><h3>Employee ratings</h3><span class="right t-sub">${periodName}</span></div>
        <div class="card-b">${ratingBars(ratings)}</div>
      </div>
    </div>
    <div class="grid g-2" style="margin-bottom:20px">
      <div class="card">
        <div class="card-h"><div class="h-ico tone-blue">📊</div><h3>Tasks completed per day</h3><span class="right t-sub">Last ${days} days</span></div>
        <div class="card-b">${barChart(completedPoints(trend))}</div>
      </div>
      <div class="card">
        <div class="card-h"><div class="h-ico tone-amber">🗓</div><h3>Daily rating by employee</h3><span class="right t-sub">Last ${Math.min(days, 14)} days — hover a cell</span></div>
        <div class="card-b" style="padding-top:8px">${ratingHeatmap(trend)}</div>
      </div>
    </div>
    <div class="card" style="margin-bottom:20px">
      <div class="card-h"><div class="h-ico tone-violet">🏆</div><h3>Full ranking</h3><span class="right t-sub">${periodName} · click a name for the full report</span></div>
      ${leaderboard(ratings)}
    </div>
    ${scoringHelp()}`;
  $('#period').onchange = (e) => { state.period = e.target.value; renderPerformance(); };
  $$('#days-seg [data-days]').forEach((b) => b.onclick = () => { state.trendDays = Number(b.dataset.days); renderPerformance(); });
}

function scoringHelp() {
  return `<div class="card"><div class="card-h"><h3>How is the score calculated?</h3></div><div class="card-b" style="color:var(--text-2)">
    <ul style="margin:0;padding-left:18px;line-height:1.9">
      <li>Finished on or before the <b>expected end time</b> → <b>100%</b> for that task.</li>
      <li>Finished late → score = planned time ÷ actual working time (e.g. planned 2h, took 4h → 50%). <b>Hold time is not counted</b>, so interruptions don't hurt.</li>
      <li>If admin <b>accepts</b> the delay reason → that task gets 100%. If <b>rejected</b> → 10 points are cut.</li>
      <li>Open tasks that crossed their expected end also count (planned tasks never started = 0%).</li>
      <li>Urgent tasks count 4×, High 3×, Medium 2×, Low 1× in the final average.</li>
      <li>Rating: ★★★★★ 90%+ Excellent · ★★★★ 75%+ Good · ★★★ 60%+ Average · ★★ 40%+ Needs improvement · ★ below 40%.</li>
    </ul></div></div>`;
}

// ============================================================ ADMIN: employees
async function renderEmployees() {
  state.users = await api('GET', '/api/users');
  const ratings = await api('GET', `/api/stats/ratings?${qs(periodRange('month'))}`);
  const byId = Object.fromEntries(ratings.map((r) => [r.user.id, r]));
  $('#view').innerHTML = `
    <div class="page-head"><div><h2>Employees</h2><div class="muted">Create a login for every employee. They open the app from their own PC and log in.</div></div>
      <div class="right"><button class="btn" id="pc-setup">💻 Employee PC setup</button><button class="btn primary" id="add-emp">＋ Add Employee</button></div></div>
    <div class="card"><div class="table-wrap"><table>
      <thead><tr><th>Name</th><th>Username</th><th>Department</th><th>Role</th><th>Status</th><th>Score (month)</th><th></th></tr></thead>
      <tbody>${state.users.map((u) => `<tr>
        <td><div class="row" style="gap:10px;flex-wrap:nowrap">${avatar(u.name, 'sm')}<div><div class="t-title">${esc(u.name)}</div><div class="t-sub">${esc(u.designation)}</div></div></div></td>
        <td><code>${esc(u.username)}</code></td>
        <td>${esc(u.department) || '—'}</td>
        <td>${u.role === 'admin' ? '<span class="badge plain tone-violet">Admin</span>' : '<span class="badge plain tone-gray">Employee</span>'}</td>
        <td>${u.active ? '<span class="badge s-completed">Active</span>' : '<span class="badge s-pending">Deactivated</span>'}${u.active && u.must_change_password ? '<div class="t-sub">🔑 Must set own password</div>' : ''}</td>
        <td>${u.role === 'employee' ? scoreCell(byId[u.id]?.score ?? null) : '—'}</td>
        <td class="nowrap">${u.role === 'employee' ? `<a class="btn sm" href="#/employee/${u.id}">Report</a>` : ''}
          <button class="btn sm" data-edit-user="${u.id}">Edit</button>
          <button class="btn sm" data-reset-user="${u.id}">Reset password</button>
          ${u.id === state.user.id ? '' : u.active ? `<button class="btn sm" data-signout-user="${u.id}" title="End all their sign-ins now">Sign out</button>
          <button class="btn sm danger" data-deact-user="${u.id}">Deactivate</button>` : `<button class="btn sm success" data-react-user="${u.id}">Reactivate</button>`}</td>
      </tr>`).join('')}</tbody></table></div></div>`;
  $('#add-emp').onclick = () => userModal();
  $('#pc-setup').onclick = async () => {
    const info = await api('GET', '/api/server-info').catch(() => ({ urls: [location.origin] }));
    pcSetupModal(info.urls);
  };
  const pcSetupModal = (urls) => modal({
    title: '💻 Put WorkTrack on an employee\'s PC',
    body: `<div class="callout blue">Only a desktop icon is installed on their PC. No data is stored there — everything stays safely online (HTTPS). Works from office or home.</div>
      <b>Steps on the employee's PC (one time, ~1 minute):</b>
      <ol class="steps">
        <li>Open Chrome / Edge and go to <b>${esc(urls[0])}</b>${urls.length > 1 ? ` <span class="t-sub">(or ${urls.slice(1).map(esc).join(' / ')})</span>` : ''}</li>
        <li>On the login page click <b>“💻 Install WorkTrack icon on this PC”</b> — a small zip downloads.</li>
        <li>Right-click the zip → <b>Extract All</b> → open the folder → double-click <b>Install WorkTrack.bat</b>.<br>
          <span class="t-sub">If Windows says “Windows protected your PC”: More info → Run anyway.</span></li>
        <li>A <b>WorkTrack</b> icon appears on their Desktop. They log in with the username &amp; password you created.</li>
      </ol>
      <div class="hint" style="margin-top:10px">You can also download the setup here and share it on a pendrive / shared folder.</div>`,
    footer: `<a class="btn" href="/download/WorkTrack-Setup.zip" download>⬇ Download setup zip</a><button type="button" class="btn primary" data-close>Done</button>`,
  });
  $$('[data-edit-user]').forEach((b) => b.onclick = () => userModal(state.users.find((u) => u.id === Number(b.dataset.editUser))));
  const who = (id) => state.users.find((x) => x.id === Number(id));
  $$('[data-deact-user]').forEach((b) => b.onclick = async () => {
    const u = who(b.dataset.deactUser);
    if (!(await confirmBox(`Deactivate ${esc(u.name)}?`, `<b>${esc(u.name)}</b> will be signed out right away and cannot sign in.<br><span class="t-sub">Their past tasks, reports and history are kept. You can reactivate them any time.</span>`, 'Deactivate'))) return;
    await api('PUT', `/api/users/${u.id}`, { active: false }); toast(`${u.name} deactivated and signed out`); refresh();
  });
  $$('[data-react-user]').forEach((b) => b.onclick = async () => {
    const u = who(b.dataset.reactUser);
    await api('PUT', `/api/users/${u.id}`, { active: true }); toast(`${u.name} can sign in again`); refresh();
  });
  $$('[data-signout-user]').forEach((b) => b.onclick = async () => {
    const u = who(b.dataset.signoutUser);
    if (!(await confirmBox(`Sign out ${esc(u.name)}?`, 'All their open sign-ins (on any computer) end now. They can sign in again with their password.', 'Sign out', 'primary'))) return;
    const r = await api('POST', `/api/users/${u.id}/signout`); toast(`${u.name} signed out (${r.ended} sign-in${r.ended === 1 ? '' : 's'} ended)`);
  });
  $$('[data-reset-user]').forEach((b) => b.onclick = () => {
    const u = state.users.find((x) => x.id === Number(b.dataset.resetUser));
    modal({
      title: `Reset password — ${esc(u.name)}`,
      body: `<label>New temporary password<input name="password" required minlength="6"><div class="hint">Give it to ${esc(u.name)} in person. They will be signed out now and must choose their own password when they sign in.</div></label>`,
      submitText: 'Reset password',
      onSubmit: async (d) => { await api('POST', `/api/users/${u.id}/reset-password`, d); toast('Temporary password set'); refresh(); },
    });
  });
}

function userModal(u) {
  const editing = !!u;
  modal({
    title: editing ? `Edit — ${esc(u.name)}` : 'Add employee',
    body: `<div class="form-grid">
      <label class="full">Full name<input name="name" required value="${esc(u?.name)}"></label>
      ${editing ? '' : `<label>Username (for login)<input name="username" required placeholder="e.g. rahul.s"></label>
      <label>Temporary password<input name="password" required minlength="6"><div class="hint">They must choose their own password the first time they sign in.</div></label>`}
      <label>Department<input name="department" value="${esc(u?.department)}" placeholder="e.g. Accounts"></label>
      <label>Designation<input name="designation" value="${esc(u?.designation)}" placeholder="e.g. Executive"></label>
      <label>Role<select name="role"><option value="employee">Employee</option><option value="admin" ${u?.role === 'admin' ? 'selected' : ''}>Admin</option></select></label>

    </div>`,
    submitText: editing ? 'Save' : 'Create employee',
    onSubmit: async (d) => {
      if (editing) await api('PUT', `/api/users/${u.id}`, d);
      else await api('POST', '/api/users', d);
      toast(editing ? 'Employee updated' : 'Employee created');
      refresh();
    },
  });
}

// ============================================================ ADMIN: leave & holidays
const dayKey = (d) => toLocalInput(d).slice(0, 10);
const LEAVE_LABEL = { leave: 'Full day leave', half_day: 'Half day', holiday: 'Holiday' };
const isOff = (l) => !!l && (l.type === 'leave' || l.type === 'holiday');
const leaveBadge = (l) => (!l ? '' : `<span class="badge plain lv-badge ${l.type}" title="${esc(l.note || '')}">${l.type === 'holiday' ? '🎉 Holiday' : l.type === 'half_day' ? '½ Half day' : '🌴 On leave'}${l.note && l.type === 'holiday' ? ' · ' + esc(l.note) : ''}</span>`);
const leaveChip = (l) => (l.type === 'holiday'
  ? `<div class="lv-chip holiday" title="Holiday: ${esc(l.note)}">🎉 ${esc(l.note)}</div>`
  : `<div class="lv-chip ${l.type}" title="${esc(l.user_name)} — ${LEAVE_LABEL[l.type]}${l.note ? ': ' + esc(l.note) : ''}">${l.type === 'half_day' ? '½ ' : ''}${esc(l.user_name)}</div>`);

async function renderLeaves() {
  if (!state.leaveMonth) { const d = new Date(); state.leaveMonth = { y: d.getFullYear(), m: d.getMonth() }; }
  const { y, m } = state.leaveMonth;
  const first = new Date(y, m, 1), last = new Date(y, m + 1, 0);
  const [rows, users] = await Promise.all([api('GET', `/api/leaves?${qs({ from: dayKey(first), to: dayKey(last) })}`), api('GET', '/api/users')]);
  state.users = users;
  const byDay = {};
  rows.forEach((l) => (byDay[l.day] = byDay[l.day] || []).push(l));
  const todayK = dayKey(new Date());
  const offset = (first.getDay() + 6) % 7;
  const cells = Math.ceil((offset + last.getDate()) / 7) * 7;
  const holidays = rows.filter((l) => l.type === 'holiday');
  const leaveDays = rows.filter((l) => l.type !== 'holiday').reduce((s, l) => s + (l.type === 'half_day' ? 0.5 : 1), 0);
  const todayOff = (byDay[todayK] || []).filter((l) => l.type !== 'holiday');
  const monthName = first.toLocaleDateString('en-IN', { month: 'long', year: 'numeric' });

  let grid = '';
  for (let i = 0; i < cells; i++) {
    const d = new Date(y, m, 1 - offset + i);
    const k = dayKey(d), inMonth = d.getMonth() === m;
    const list = inMonth ? (byDay[k] || []) : [];
    const hol = list.find((l) => l.type === 'holiday');
    grid += `<div class="cal-cell ${inMonth ? '' : 'out'} ${k === todayK ? 'today' : ''} ${d.getDay() === 0 ? 'sun' : ''} ${hol ? 'hol' : ''}" ${inMonth ? `data-day="${k}"` : ''}>
      <div class="cal-num">${d.getDate()}</div>${list.slice(0, 3).map(leaveChip).join('')}${list.length > 3 ? `<div class="lv-more">+${list.length - 3} more</div>` : ''}</div>`;
  }

  $('#view').innerHTML = `
    <div class="page-head"><div><h2>Leave & holidays</h2><div class="muted">Mark leave days and office holidays. On these days ratings are not reduced and reports show “On leave”.</div></div>
      <div class="right"><button class="btn" id="add-hol">🎉 Add holiday</button><button class="btn primary" id="add-leave">＋ Mark leave</button></div></div>
    <div class="kpis">
      <div class="card kpi"><div class="k-ico tone-violet">🌴</div><div><div class="k-val">${todayOff.length}</div><div class="k-lbl">On leave today</div><div class="k-sub">${todayOff.map((l) => esc(l.user_name)).join(', ') || 'Everyone is in'}</div></div></div>
      <div class="card kpi"><div class="k-ico tone-red">🎉</div><div><div class="k-val">${holidays.length}</div><div class="k-lbl">Holidays in ${first.toLocaleDateString('en-IN', { month: 'long' })}</div><div class="k-sub">${holidays.map((h) => `${new Date(h.day + 'T12:00').getDate()} — ${esc(h.note)}`).join(', ') || '—'}</div></div></div>
      <div class="card kpi"><div class="k-ico tone-amber">📋</div><div><div class="k-val">${leaveDays}</div><div class="k-lbl">Leave days this month</div><div class="k-sub">All employees together</div></div></div>
    </div>
    <div class="card" style="margin-bottom:20px">
      <div class="card-h"><button class="btn sm" id="m-prev">◀</button><h3 style="min-width:150px;text-align:center">${monthName}</h3><button class="btn sm" id="m-next">▶</button>
        <button class="btn sm" id="m-today">This month</button>
        <div class="right legend" style="margin:0"><span><i class="lv-dot holiday"></i>Holiday</span><span><i class="lv-dot leave"></i>Full day leave</span><span><i class="lv-dot half_day"></i>Half day</span></div></div>
      <div class="cal-head">${['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].map((d) => `<div>${d}</div>`).join('')}</div>
      <div class="cal-grid">${grid}</div>
      <div class="card-b t-sub" style="padding-top:10px">Tip: click on any date to mark leave for that day.</div>
    </div>
    <div class="card">
      <div class="card-h"><h3>Entries in ${monthName}</h3><span class="right t-sub">${rows.length} entr${rows.length === 1 ? 'y' : 'ies'}</span></div>
      ${rows.length ? `<div class="table-wrap"><table><thead><tr><th>Date</th><th>Who</th><th>Type</th><th>Reason / Name</th><th></th></tr></thead><tbody>
        ${rows.map((l) => `<tr>
          <td class="nowrap"><b>${new Date(l.day + 'T12:00').toLocaleDateString('en-IN', { weekday: 'short', day: 'numeric', month: 'short' })}</b></td>
          <td>${l.type === 'holiday' ? '<span class="muted">Everyone</span>' : `<div class="row" style="gap:8px;flex-wrap:nowrap">${avatar(l.user_name, 'sm')}${esc(l.user_name)}</div>`}</td>
          <td><span class="badge plain lv-badge ${l.type}">${LEAVE_LABEL[l.type]}</span></td>
          <td>${esc(l.note) || '<span class="muted">—</span>'}</td>
          <td class="nowrap"><button class="btn sm danger" data-del-leave="${l.id}">Remove</button></td></tr>`).join('')}
      </tbody></table></div>` : empty('🌴', 'No leave or holidays marked for this month')}
    </div>`;

  const go = (dm) => { const d = new Date(y, m + dm, 1); state.leaveMonth = { y: d.getFullYear(), m: d.getMonth() }; renderLeaves(); };
  $('#m-prev').onclick = () => go(-1);
  $('#m-next').onclick = () => go(1);
  $('#m-today').onclick = () => { state.leaveMonth = null; renderLeaves(); };
  $('#add-leave').onclick = () => leaveModal();
  $('#add-hol').onclick = () => holidayModal();
  $$('[data-day]').forEach((c) => c.onclick = () => leaveModal(c.dataset.day));
  $$('[data-del-leave]').forEach((b) => b.onclick = async () => {
    if (!(await confirmBox('Remove entry?', 'This leave / holiday entry will be removed.', 'Remove'))) return;
    await api('DELETE', `/api/leaves/${b.dataset.delLeave}`);
    toast('Removed');
    renderLeaves();
  });
}

function leaveModal(day) {
  const d = day || dayKey(new Date());
  const employees = state.users.filter((u) => u.role === 'employee' && u.active);
  modal({
    title: '🌴 Mark leave',
    body: `<label>Employee<select name="user_id" required><option value="">— Select employee —</option>
        ${employees.map((u) => `<option value="${u.id}">${esc(u.name)}${u.department ? ' · ' + esc(u.department) : ''}</option>`).join('')}</select></label>
      <input type="hidden" name="type" value="leave">
      <div class="seg" id="lv-seg"><button type="button" class="on" data-t="leave">Full day</button><button type="button" data-t="half_day">Half day</button></div>
      <div class="form-grid">
        <label>From<input type="date" name="from" value="${d}" required></label>
        <label>To<input type="date" name="to" value="${d}" required></label>
      </div>
      <label class="row" style="gap:8px;font-size:13.5px;color:var(--text)"><input type="checkbox" name="skip_sundays" checked style="width:auto"> Skip Sundays</label>
      <label>Reason (optional)<input name="note" placeholder="e.g. Sick leave, family function"></label>
      <div class="hint">Full day: rating is not counted for that day. Half day: rating counts, report shows “Half day”.</div>`,
    submitText: 'Save leave',
    onOpen: (form) => {
      $('#lv-seg', form).addEventListener('click', (e) => {
        const b = e.target.closest('[data-t]'); if (!b) return;
        $$('#lv-seg button', form).forEach((x) => x.classList.toggle('on', x === b));
        form.elements.type.value = b.dataset.t;
      });
      form.elements.from.addEventListener('change', () => { if (form.elements.to.value < form.elements.from.value) form.elements.to.value = form.elements.from.value; });
    },
    onSubmit: async (f) => {
      const r = await api('POST', '/api/leaves', { ...f, skip_sundays: !!f.skip_sundays });
      toast(`Leave saved for ${r.added} day(s)`);
      refresh();
    },
  });
}

function holidayModal(day) {
  const d = day || dayKey(new Date());
  modal({
    title: '🎉 Add office holiday',
    body: `<label>Holiday name<input name="note" required placeholder="e.g. Diwali"></label>
      <div class="form-grid">
        <label>From<input type="date" name="from" value="${d}" required></label>
        <label>To<input type="date" name="to" value="${d}" required></label>
      </div>
      <div class="hint">A holiday applies to everyone. Nobody's rating is counted on that day.</div>`,
    submitText: 'Add holiday',
    onOpen: (form) => form.elements.from.addEventListener('change', () => { if (form.elements.to.value < form.elements.from.value) form.elements.to.value = form.elements.from.value; }),
    onSubmit: async (f) => {
      const r = await api('POST', '/api/leaves', { ...f, type: 'holiday' });
      toast(`Holiday added (${r.added} day${r.added > 1 ? 's' : ''})`);
      refresh();
    },
  });
}

// ============================================================ performance view (admin report & employee self)
async function performanceView(userId, { adminView }) {
  const range = periodRange(state.period);
  const [ratingRows, tasks] = await Promise.all([
    api('GET', `/api/stats/ratings?${qs({ ...range, user_id: userId })}`),
    api('GET', `/api/tasks?${qs({ ...range, user_id: userId })}`),
  ]);
  const r = ratingRows[0];
  if (!r) throw new Error('Employee not found or inactive');
  const scored = tasks.filter((t) => t.score != null);
  const byPriority = Object.keys(PRIORITY_LABEL).map((p) => {
    const ts = scored.filter((t) => t.priority === p);
    return [p, ts.length, ts.length ? Math.round(ts.reduce((s, t) => s + t.score, 0) / ts.length) : null];
  });
  $('#view').innerHTML = `
    <div class="page-head">
      ${adminView ? `<a class="btn" href="#/employees">← Back</a>` : ''}
      <div class="row">${avatar(r.user.name)}<div><h2>${esc(r.user.name)}</h2><div class="muted">${esc([r.user.designation, r.user.department].filter(Boolean).join(' · '))}</div></div></div>
      <div class="right">${periodSelect()}${adminView ? `<button class="btn" id="export-emp">⬇ Export</button><button class="btn primary" id="assign-emp">＋ Assign Task</button>` : ''}</div>
    </div>
    <div class="grid g-1-2" style="margin-bottom:18px">
      <div class="card card-b">
        <div class="score-hero" style="flex-direction:column;align-items:center;text-align:center">
          <div class="score-ring" style="--v:${r.score ?? 0};--c:${scoreColor(r.score)}"><div><div><b>${r.score != null ? r.score + '%' : '—'}</b><span>performance</span></div></div></div>
          <div>${stars(r.stars)}<div style="font-weight:700;font-size:16px">${r.grade}</div></div>
        </div>
      </div>
      <div class="card card-b"><div class="mini-stats" style="grid-template-columns:repeat(3,1fr)">
        <div><b>${r.total}</b><span>Total tasks</span></div>
        <div><b>${r.completed}</b><span>Completed</span></div>
        <div><b style="color:var(--green)">${r.on_time_rate != null ? r.on_time_rate + '%' : '—'}</b><span>On-time rate</span></div>
        <div><b style="color:var(--green)">${r.on_time}</b><span>Finished on time</span></div>
        <div><b style="color:var(--amber)">${r.late}</b><span>Finished late</span></div>
        <div><b style="color:var(--red)">${r.overdue_open}</b><span>Overdue now</span></div>
        <div><b>${dur(r.worked_minutes)}</b><span>Total time worked</span></div>
        <div><b>${r.counts.in_progress + r.counts.on_hold}</b><span>Active now</span></div>
        <div><b>${r.counts.pending}</b><span>Planned</span></div>
      </div>
      <div style="margin-top:14px"><div class="small muted" style="margin-bottom:6px;font-weight:600">SCORE BY PRIORITY</div>
        ${byPriority.map(([p, n, s]) => `<div class="row" style="flex-wrap:nowrap;margin-bottom:6px"><span style="width:80px">${prBadge(p)}</span><div style="flex:1">${scoreCell(s)}</div><span class="t-sub" style="width:60px;text-align:right">${n} task${n === 1 ? '' : 's'}</span></div>`).join('')}
      </div></div>
    </div>
    <div class="card"><div class="card-h"><h3>Tasks in this period</h3></div>${taskTable(tasks)}</div>
    ${adminView ? '' : `<div style="margin-top:18px">${scoringHelp()}</div>`}`;
  $('#period').onchange = (e) => { state.period = e.target.value; router(); };
  if (adminView) {
    $('#assign-emp').onclick = () => { taskFormModal(); setTimeout(() => { const s = $('select[name=user_id]'); if (s) s.value = userId; }, 0); };
    $('#export-emp').onclick = () => { location.href = `/api/export/tasks.csv?${qs({ ...range, user_id: userId })}`; };
  }
  tick();
}
function renderEmployeeReport(id) { return performanceView(Number(id), { adminView: true }); }
function renderMyPerformance() { return performanceView(state.user.id, { adminView: false }); }

// ============================================================ EMPLOYEE: dashboard + day planner
// Employees can write down their day first ("9:00–9:30 Check emails", "10–11 Client call"),
// then start each task with one click when its time comes. A reminder pops up at the planned time.

// "9-9:30 Emails", "10:00 - 11:00 Call", "2pm-3pm Report", "9.30 to 10 Tea"  ->  { from, to, title }
function parsePlanLine(line) {
  const m = String(line).trim().match(/^(\d{1,2})(?:[:.](\d{2}))?\s*(am|pm)?\s*(?:-|–|—|to)\s*(\d{1,2})(?:[:.](\d{2}))?\s*(am|pm)?\s*[-:,]?\s*(.+)$/i);
  if (!m) return { title: String(line).trim() };
  const toH = (h, ap, ref) => {
    h = Number(h);
    if (ap) { ap = ap.toLowerCase(); if (ap === 'pm' && h < 12) h += 12; if (ap === 'am' && h === 12) h = 0; return h; }
    if (ref != null && h < ref && h + 12 < 24) return h + 12; // "11-1" -> 11:00 to 13:00
    return h >= 1 && h <= 7 ? h + 12 : h;                    // office hours: "2-3" means 2 PM
  };
  const fh = toH(m[1], m[3] || m[6]), th = toH(m[4], m[6] || m[3], fh);
  const at = (h, mi) => { const d = new Date(); d.setHours(h, Number(mi || 0), 0, 0); return d; };
  const from = at(fh, m[2]), to = at(th, m[5]);
  if (to <= from) to.setTime(from.getTime() + 30 * 60000);
  return { from, to, title: m[7].trim() };
}
const hhmm = (d) => new Date(d).toLocaleTimeString('en-IN', { hour: 'numeric', minute: '2-digit', hour12: true }).replace(' ', ' ');

async function quickStart(t) {
  const planned = t.start_time ? Math.max(5, Math.round((Date.parse(t.expected_end) - Date.parse(t.start_time)) / 60000)) : 30;
  const running = await myRunningTasks(t.id);
  if (running.length) return startModal(t); // asks to switch (hold the running task)
  const now = new Date();
  await api('POST', `/api/tasks/${t.id}/start`, { start_time: now.toISOString(), expected_end: new Date(now.getTime() + planned * 60000).toISOString() });
  toast(`▶ Started “${t.title}” — ${dur(planned)} planned`);
  refresh();
}

function showPlanReminder(t) {
  const el = document.createElement('div');
  el.className = 'alert-card';
  el.innerHTML = `<div class="ac-ico">⏰</div>
    <div class="ac-main"><div class="ac-title">Time to start: ${esc(t.title)}</div>
      <div class="ac-body">Planned ${hhmm(t.start_time)} – ${hhmm(t.expected_end)}</div>
      <div class="ac-actions"><button class="btn primary sm" data-a="start">▶ Start now</button><button class="btn sm" data-a="snooze">Remind in 10 min</button><button class="btn sm" data-a="ok">OK</button></div></div>
    <button class="icon-btn ac-x" data-a="ok" aria-label="Dismiss">✕</button>`;
  el.addEventListener('click', async (e) => {
    const a = e.target.closest('[data-a]')?.dataset.a; if (!a) return;
    el.classList.add('out'); setTimeout(() => el.remove(), 200);
    if (a === 'start') quickStart(await api('GET', `/api/tasks/${t.id}`)).catch((x) => toast(x.message, 'error'));
    if (a === 'snooze') setTimeout(() => { if (state.user) showPlanReminder(t); playChime(); }, 10 * 60000);
  });
  pushAlert(el);
  playChime();
  flashTitle(`⏰ Time to start: ${t.title}`);
}

// "Starts in 10 minutes" heads-up before a planned task
function showUpcomingReminder(t) {
  const mins = Math.max(1, Math.round((Date.parse(t.start_time) - Date.now()) / 60000));
  const el = document.createElement('div');
  el.className = 'alert-card';
  el.innerHTML = `<div class="ac-ico">🔔</div>
    <div class="ac-main"><div class="ac-title">Starts in ${mins} min: ${esc(t.title)}</div>
      <div class="ac-body">Planned ${hhmm(t.start_time)} – ${hhmm(t.expected_end)}</div>
      <div class="ac-actions"><button class="btn primary sm" data-a="start">▶ Start now</button><button class="btn sm" data-a="ok">OK</button></div></div>
    <button class="icon-btn ac-x" data-a="ok" aria-label="Dismiss">✕</button>`;
  el.addEventListener('click', async (e) => {
    const a = e.target.closest('[data-a]')?.dataset.a; if (!a) return;
    el.classList.add('out'); setTimeout(() => el.remove(), 200);
    if (a === 'start') quickStart(await api('GET', `/api/tasks/${t.id}`)).catch((x) => toast(x.message, 'error'));
  });
  pushAlert(el);
  playChime();
}

// "Your plan for today / tomorrow" summary card
function showDayPlanCard(kind, todayList, tomorrowList) {
  const lines = (list) => `${[...list].sort((a, b) => Date.parse(a.start_time) - Date.parse(b.start_time)).slice(0, 4).map((t) => `<div class="dp-line"><b>${hhmm(t.start_time)}</b> ${esc(t.title)}</div>`).join('')}${list.length > 4 ? `<div class="dp-line muted">+ ${list.length - 4} more</div>` : ''}`;
  const el = document.createElement('div');
  el.className = 'alert-card dayplan';
  el.innerHTML = `<div class="ac-ico">📅</div>
    <div class="ac-main">
      ${kind === 'today' && todayList.length ? `<div class="ac-title">Today you have ${todayList.length} task${todayList.length > 1 ? 's' : ''} planned</div><div class="ac-body">${lines(todayList)}</div>` : ''}
      ${tomorrowList.length ? `<div class="ac-title" ${kind === 'today' && todayList.length ? 'style="margin-top:10px"' : ''}>Reminder: tomorrow you have ${tomorrowList.length} task${tomorrowList.length > 1 ? 's' : ''}</div><div class="ac-body">${lines(tomorrowList)}</div>` : ''}
      <div class="ac-actions">${kind === 'today' ? '<button class="btn primary sm" data-a="today">Open Today</button>' : ''}<button class="btn sm" data-a="cal">Open Calendar</button><button class="btn sm" data-a="ok">OK</button></div>
    </div>
    <button class="icon-btn ac-x" data-a="ok" aria-label="Dismiss">✕</button>`;
  el.addEventListener('click', (e) => {
    const a = e.target.closest('[data-a]')?.dataset.a; if (!a) return;
    el.classList.add('out'); setTimeout(() => el.remove(), 200);
    if (a === 'today') location.hash = '#/my';
    if (a === 'cal') location.hash = '#/calendar';
  });
  pushAlert(el);
  playChime();
}

// remember "shown once today" per person (falls back to memory if the browser blocks storage)
function onceToday(name) {
  const key = `wt-${name}-${state.user.id}-${dayKey(new Date())}`;
  try { if (localStorage.getItem(key)) return false; localStorage.setItem(key, '1'); return true; } catch {
    if (state.notified.has(key)) return false; state.notified.add(key); return true;
  }
}

// true only the first time today for this key (kept across page reloads, so reminders don't repeat)
function onceForTask(key) {
  const store = `wt-once-${state.user.id}-${dayKey(new Date())}`;
  let seen = [];
  try { seen = JSON.parse(localStorage.getItem(store) || '[]'); } catch { /* ignore */ }
  if (seen.includes(key) || state.notified.has(key)) return false;
  seen.push(key); state.notified.add(key);
  try { localStorage.setItem(store, JSON.stringify(seen)); } catch { /* ignore */ }
  return true;
}

// called every second from tick(): reminders for planned tasks
function checkPlanReminders(now) {
  if (!state.user) return;
  const mine = state.pendingMine || state.planWatch || [];
  const d0 = new Date(); d0.setHours(0, 0, 0, 0);
  const d1 = new Date(d0); d1.setDate(d1.getDate() + 1);
  const d2 = new Date(d1); d2.setDate(d2.getDate() + 1);
  const today = mine.filter((t) => Date.parse(t.start_time) >= d0 && Date.parse(t.start_time) < d1);
  for (const t of today) {
    const s = Date.parse(t.start_time);
    // 10 minutes before
    if (now >= s - remindMinutes() * 60000 && now < s - 60000 && !state.notified.has(`pre-${t.id}`)) {
      state.notified.add(`pre-${t.id}`);
      showUpcomingReminder(t);
    }
    // at the start time
    if (now >= s && now - s < 120000 && !state.notified.has(`plan-${t.id}`)) {
      state.notified.add(`plan-${t.id}`);
      showPlanReminder(t);
    }
  }
  if (!state.pendingMine) return; // the checks below need the full, fresh list
  // not started 15 min after its start time, or its whole planned time has passed (shown once per task per day)
  const attention = [];
  for (const t of today) {
    const s = Date.parse(t.start_time), e = Date.parse(t.expected_end);
    if (now >= e + 60000) { if (onceForTask(`miss-${t.id}`)) { onceForTask(`ls-${t.id}`); attention.push([t, true]); } }
    else if (now >= s + 15 * 60000 && onceForTask(`ls-${t.id}`)) attention.push([t, false]);
  }
  if (attention.length > 2) showMissedSummary(attention.map(([t]) => t));
  else attention.forEach(([t, missed]) => showNotStarted(t, missed));
  const tomorrow = mine.filter((t) => Date.parse(t.start_time) >= d1 && Date.parse(t.start_time) < d2);
  const upcomingToday = today.filter((t) => Date.parse(t.start_time) > now - 30 * 60000);
  const evening = new Date().getHours() >= 17;
  // once a day: the day's plan (and tomorrow's, if it is already evening)
  if ((upcomingToday.length || (evening && tomorrow.length)) && onceToday('dayplan')) {
    showDayPlanCard('today', upcomingToday, evening ? tomorrow : []);
    if (evening) onceToday('tomorrow');
  } else if (evening && tomorrow.length && onceToday('tomorrow')) {
    // in the evening: a reminder about tomorrow's tasks
    showDayPlanCard('tomorrow', [], tomorrow);
  }
}

// ------------------------------------------------------------ simple employee screens ("Today" + Calendar)
// Plain words, one button per task, everything else tucked away.
const planMin = (t) => (t.start_time ? Math.max(5, Math.round((Date.parse(t.expected_end) - Date.parse(t.start_time)) / 60000)) : 30);
const DUR_OPTS = [[15, '15 min'], [30, '30 min'], [45, '45 min'], [60, '1 hour'], [90, '1.5 hours'], [120, '2 hours'], [180, '3 hours'], [240, '4 hours']];
const durSelect = (id, val = 30) => `<select id="${id}" class="sa-dur" aria-label="How long will it take">${DUR_OPTS.map(([v, l]) => `<option value="${v}" ${v === val ? 'selected' : ''}>${l}</option>`).join('')}</select>`;

// one row in a simple task list: time | name | one button
function simpleRow(t, now = Date.now()) {
  const s = t.start_time ? Date.parse(t.start_time) : null;
  let cls = '', right = '';
  if (t.status === 'completed') {
    // record: how long it really took vs. the plan
    const over = t.worked_minutes > (t.planned_minutes || 0) + 1;
    const acc = taskAccuracy(t);
    cls = 'done'; right = `<span class="sr-tag ${over ? 'over' : 'ok'}">✓ Took ${dur(t.worked_minutes)}<small>Plan ${dur(t.planned_minutes)}${acc != null ? ` · ${acc}% accurate` : ''}</small></span>`;
  } else if (t.status === 'in_progress') {
    cls = 'run'; right = `<button class="btn success sm" data-act="complete" data-id="${t.id}">✓ Done</button>`;
  } else if (t.status === 'on_hold') {
    cls = 'hold'; right = `<button class="btn primary sm" data-act="resume" data-id="${t.id}">▶ Resume</button>`;
  } else {
    const missed = Date.parse(t.expected_end) < now;
    cls = missed ? 'missed' : s && s <= now ? 'due' : '';
    right = `<button class="btn ${cls ? 'primary' : ''} sm" data-act="qstart" data-id="${t.id}">▶ Start</button>`;
  }
  const note = t.status === 'in_progress' ? '<span class="sr-note run">● In progress</span>'
    : t.status === 'on_hold' ? '<span class="sr-note hold">⏸ Paused</span>'
    : cls === 'missed' ? '<span class="sr-note bad">Missed</span>'
    : cls === 'due' ? '<span class="sr-note due">⏰ Due now</span>'
    : t.status === 'pending' ? `<span class="sr-note">Plan ${dur(planMin(t))}</span>` : '';
  const endIso = t.status === 'completed' ? t.actual_end : t.status === 'pending' ? t.expected_end : null;
  return `<div class="sr ${cls} ${t.id === state.flashTaskId ? 'just-added' : ''}" data-open="${t.id}">
    <span class="sr-time">${s ? hhmm(t.start_time) : '—'}${endIso ? `<small>– ${hhmm(endIso)}</small>` : ''}</span>
    <span class="sr-name">${esc(t.title)} ${note}</span>
    <span class="sr-act">${right}${canArchiveTask(t) ? `<button type="button" class="icon-btn sr-del" title="Archive this task (added by mistake)" aria-label="Archive ${esc(t.title)}" data-act="archive" data-id="${t.id}">🗃</button>` : ''}</span>
  </div>`;
}

// ------------------------------------------------------------ My progress (employee): on-time % for today / week / month
// On time = finished within the planned time (paused time never counts), or late with a reason your admin accepted.
// (The admin's rating is not shown to employees.)
const isOnTime = (t) => !t.is_late || t.reason_status === 'accepted' || t.excused;

// Time accuracy of ONE finished task - how close it finished to its planned time (paused time not counted):
//   finished within the plan -> 100%;  took longer -> planned ÷ time taken   (30 min plan, took 36 min -> 83%)
function taskAccuracy(t) {
  if (t.status !== 'completed' || !t.planned_minutes) return null;
  if (t.excused) return 100; // admin approved a review: counts as on plan
  const took = t.worked_minutes || 0;
  return took <= t.planned_minutes ? 100 : Math.round((t.planned_minutes / took) * 100);
}

// Accuracy for a day / week / month = the average accuracy of the tasks finished in it
function progressStats(list) {
  const done = list.length;
  const onTime = list.filter(isOnTime).length;
  const accs = list.map(taskAccuracy).filter((a) => a != null);
  return {
    done, onTime,
    pct: accs.length ? Math.round(accs.reduce((s, a) => s + a, 0) / accs.length) : null, // time accuracy
    onTimePct: done ? Math.round((onTime / done) * 100) : null,
    worked: list.reduce((s, t) => s + (t.worked_minutes || 0), 0),
    planned: list.reduce((s, t) => s + (t.planned_minutes || 0), 0),
  };
}
const pctTone = (p) => (p == null ? 'none' : p >= 90 ? 'good' : p >= 70 ? 'mid' : 'low');

async function loadMyProgress() {
  const box = $('#my-progress');
  if (!box) return;
  const now = new Date();
  const dayStart = new Date(now); dayStart.setHours(0, 0, 0, 0);
  const weekStart = new Date(dayStart); weekStart.setDate(weekStart.getDate() - ((weekStart.getDay() + 6) % 7)); // Monday
  const monthStart = new Date(now.getFullYear(), now.getMonth(), 1);
  const from = new Date(Math.min(weekStart, monthStart));
  from.setDate(from.getDate() - 7); // a task finished this week may have started a little earlier
  let rows;
  try { rows = await api('GET', `/api/tasks?${qs({ status: 'completed', from: from.toISOString() })}`); } catch { box.innerHTML = ''; return; }
  const finishedIn = (a, b) => rows.filter((t) => Date.parse(t.actual_end) >= a && Date.parse(t.actual_end) < b);
  const end = new Date(dayStart); end.setDate(end.getDate() + 1);
  const period = state.progPeriod || 'today';
  const range = { today: [dayStart, end], week: [weekStart, end], month: [monthStart, end] }[period];
  const st = progressStats(finishedIn(range[0].getTime(), range[1].getTime()));

  // breakdown: days of this week, or weeks of this month
  let parts = [];
  if (period === 'week') {
    for (let i = 0; i < 7; i++) {
      const a = new Date(weekStart); a.setDate(a.getDate() + i);
      const b = new Date(a); b.setDate(b.getDate() + 1);
      parts.push({ label: a.toLocaleDateString('en-IN', { weekday: 'short' }), sub: a.getDate(), future: a > now, today: a.getTime() === dayStart.getTime(), ...progressStats(finishedIn(a, b)) });
    }
  } else if (period === 'month') {
    for (let a = new Date(monthStart), n = 1; a < end; n++) {
      const b = new Date(a); b.setDate(b.getDate() + 7 - ((a.getDay() + 6) % 7)); // to next Monday
      const stop = new Date(Math.min(b, new Date(now.getFullYear(), now.getMonth() + 1, 1)));
      parts.push({ label: `Week ${n}`, sub: `${a.getDate()}–${new Date(stop - 86400000).getDate()}`, future: a > now, ...progressStats(finishedIn(a, stop)) });
      a = stop;
    }
  }
  const tabs = [['today', 'Today'], ['week', 'This week'], ['month', 'This month']];
  const tone = pctTone(st.pct);
  box.innerHTML = `
    <div class="aaj-h"><h3>My progress</h3>
      <div class="seg mini prog-tabs">${tabs.map(([v, l]) => `<button type="button" data-prog="${v}" class="${v === period ? 'on' : ''}">${l}</button>`).join('')}</div></div>
    <div class="prog-main">
      <div class="prog-pct ${tone}"><b>${st.pct == null ? '—' : `${st.pct}%`}</b><span>accuracy</span></div>
      <div class="prog-facts">
        <div class="prog-sentence">${st.done ? `<b>${st.onTime} of ${st.done}</b> task${st.done > 1 ? 's' : ''} finished within the planned time${st.done - st.onTime ? ` · <b>${st.done - st.onTime}</b> took longer` : ''}`
          : period === 'today' ? 'No tasks finished yet today. Finish a task to see your accuracy.' : 'No tasks finished in this period yet.'}</div>
        ${st.done ? `<div class="prog-bar ${tone}"><i style="width:${st.pct}%"></i></div>` : ''}
        <div class="prog-nums">
          <div><b>${st.done}</b><span>Tasks done</span></div>
          <div><b>${dur(st.worked)}</b><span>Time worked</span></div>
          <div><b>${dur(st.planned)}</b><span>Time planned</span></div>
        </div>
      </div>
    </div>
    ${parts.length ? `<div class="prog-parts ${period}">${parts.map((p) => `<div class="pp ${p.future ? 'future' : pctTone(p.pct)} ${p.today ? 'is-today' : ''}"
        title="${p.done ? `Accuracy ${p.pct}% · ${p.onTime} of ${p.done} within plan · ${dur(p.worked)} worked` : 'No tasks finished'}">
        <span class="pp-l">${p.label}</span><span class="pp-s">${p.sub}</span><b>${p.future ? '' : p.pct == null ? '—' : `${p.pct}%`}</b>
        <span class="pp-n">${p.done ? `${p.done} done` : ''}</span></div>`).join('')}</div>` : ''}
    ${st.done ? `<details class="prog-tasks"><summary>See accuracy of each task (${st.done})</summary>
      ${finishedIn(range[0].getTime(), range[1].getTime()).sort((a, b) => Date.parse(b.actual_end) - Date.parse(a.actual_end)).map((t) => {
        const acc = taskAccuracy(t);
        return `<div class="pt-row"><span class="pt-name">${esc(t.title)}<small>${new Date(t.actual_end).toLocaleDateString('en-IN', { day: 'numeric', month: 'short' })}</small></span>
          <span class="pt-times">Plan ${dur(t.planned_minutes)} · Took ${dur(t.worked_minutes)}</span><b class="acc ${pctTone(acc)}">${acc == null ? '—' : `${acc}%`}</b></div>`;
      }).join('')}</details>` : ''}
    <div class="prog-help"><b>Accuracy</b> = how close each task finished to its planned time. Finished within the plan = 100%. Took longer = plan ÷ time taken (e.g. 30 min plan done in 36 min = 83%). The day, week and month show the average of their tasks. Paused time is not counted.
      <a href="#" class="how-calc" id="how-calc">How is my progress calculated? →</a></div>`;
  $('#how-calc', box)?.addEventListener('click', (e) => { e.preventDefault(); window.explainProgress?.(); });
  $$('[data-prog]', box).forEach((b) => b.onclick = () => { state.progPeriod = b.dataset.prog; loadMyProgress(); });
}

// ------------------------------------------------------------ ✨ Task assistant (built in - works without internet)
// Shows a short summary, what to do next (with one-click buttons) and why tasks get delayed.
const AI_BTN = {
  complete: ['✓ Done', 'success', 'act'], pause: ['⏸ Pause', 'warn', 'act'], resume: ['▶ Resume', 'primary', 'act'],
  qstart: ['▶ Start', 'primary', 'act'], reason: ['✎ Update reason', '', 'act'], move: ['⏰ Move +1 hour', '', 'move'],
  messages: ['💬 Open messages', '', 'go'], today: ['Open Today', '', 'go'], calendar: ['Open Calendar', '', 'go'],
  reviews: ['Review now', 'warn', 'go'], overview: ['Open Overview', '', 'go'], assign: ['＋ Assign task', 'primary', 'go'], employee: ['Open report', '', 'go'],
};
function aiActionButtons(a) {
  return (a.buttons || []).map((b) => {
    const [label, cls, kind] = AI_BTN[b] || [b, '', 'go'];
    if (kind === 'act') return `<button type="button" class="btn sm ${cls}" data-act="${b}" data-id="${a.task_id}" data-close>${label}</button>`;
    return `<button type="button" class="btn sm ${cls}" data-ai="${b}" data-id="${a.task_id || ''}" data-user="${a.user_id || ''}" data-close>${label}</button>`;
  }).join(' ');
}
function aiAction(btn) {
  const k = btn.dataset.ai, id = btn.dataset.id, uid = btn.dataset.user;
  if (k === 'move') return api('GET', `/api/tasks/${id}`).then((t) => reschedule(t, inOneHourFrom()));
  if (k === 'messages') { $('#bell').click(); return null; }
  if (k === 'assign') return taskFormModal();
  location.hash = { today: '#/my', calendar: '#/calendar', reviews: '#/reviews', overview: '#/dashboard', employee: `#/employee/${uid}` }[k] || location.hash;
  return null;
}
document.addEventListener('click', (e) => {
  const b = e.target.closest('[data-ai]');
  if (b) Promise.resolve(aiAction(b)).catch((x) => toast(x.message, 'error'));
});

function reasonBars(list, total) {
  if (!list.length) return '<div class="muted small">Nothing to show yet.</div>';
  return `<div class="ai-bars">${list.map((r) => `<div class="ai-bar"><span>${esc(r.label)}</span>
    <div class="bar"><i style="width:${r.pct}%"></i></div><b>${r.pct}%</b><small>${r.count}${total ? ` of ${total}` : ''}</small></div>`).join('')}</div>`;
}

async function showAssistant() {
  const a = await api('GET', '/api/assistant');
  const ins = a.insights;
  const isAdmin = a.for === 'admin';
  modal({
    title: '✨ Task assistant',
    wide: true,
    body: `
      <div class="ai-summary"><div class="ai-ico">✨</div><p>${esc(a.summary)}</p></div>
      <h4 class="ai-h">What to do next</h4>
      ${a.actions.length ? `<div class="ai-actions">${a.actions.map((x) => `<div class="ai-act"><span class="ai-act-i">${x.icon}</span>
          <div class="ai-act-t">${esc(x.text)}</div><div class="ai-act-b">${aiActionButtons(x)}</div></div>`).join('')}</div>`
        : '<div class="callout green">✅ All clear — nothing needs your attention right now.</div>'}
      <h4 class="ai-h">Why tasks get delayed <span class="t-sub">(${ins.period}${isAdmin ? ', whole team' : ''})</span></h4>
      <div class="ai-grid">
        <div class="ai-stat"><b>${ins.finished}</b><span>tasks finished</span></div>
        <div class="ai-stat"><b>${ins.late}</b><span>finished late (${ins.late_pct}%)</span></div>
        <div class="ai-stat"><b>${ins.time_used_pct == null ? '—' : `${ins.time_used_pct}%`}</b><span>of planned time used</span></div>
      </div>
      ${ins.late ? `<div class="ai-sub">Main reasons for delays</div>${reasonBars(ins.reasons, ins.late)}` : '<div class="muted small" style="margin:8px 0">No late tasks in this period. 👍</div>'}
      ${ins.interruptions.length ? `<div class="ai-sub">What interrupts work most (pauses)</div><div class="ai-chips">${ins.interruptions.map((r) => `<span>${esc(r.label)} · ${r.count}</span>`).join('')}</div>` : ''}
      ${ins.tip ? `<div class="callout blue" style="margin-top:14px">💡 ${esc(ins.tip)}</div>` : ''}
      ${isAdmin && a.people.length ? `<h4 class="ai-h">Team at a glance</h4><div class="table-wrap"><table>
        <thead><tr><th>Employee</th><th>Running</th><th>Overdue</th><th>Planned today</th><th>Late (30 days)</th><th>Main delay reason</th></tr></thead>
        <tbody>${a.people.map((p) => `<tr class="click" onclick="location.hash='#/employee/${p.id}'">
          <td><div class="row" style="gap:8px;flex-wrap:nowrap">${avatar(p.name, 'sm')}<b>${esc(p.name)}</b>${p.on_leave ? ' <span class="badge plain lv-badge leave">On leave</span>' : ''}</div></td>
          <td>${p.running}</td><td>${p.overdue ? `<span class="badge s-overdue">${p.overdue}</span>` : '0'}</td><td>${p.planned_today}</td>
          <td>${p.late_pct == null ? '—' : `${p.late_pct}% <span class="t-sub">of ${p.finished}</span>`}</td><td>${esc(p.top_reason || '—')}</td></tr>`).join('')}</tbody></table></div>` : ''}
      <div class="t-sub" style="margin-top:14px">The assistant reads your tasks, times and delay reasons. It runs inside WorkTrack — no data leaves the app.</div>`,
    footer: '<button type="button" class="btn primary" data-close>Close</button>',
  });
}

// employee: the single most useful suggestion, shown under the greeting
async function loadAssistantTip() {
  const box = $('#ai-tip');
  if (!box) return;
  try {
    const a = await api('GET', '/api/assistant');
    const top = a.actions[0];
    if (!top || !$('#ai-tip')) return;
    box.innerHTML = `<div class="ai-tip"><span class="ai-tip-i">✨</span><div class="ai-tip-t"><b>Suggestion:</b> ${esc(top.text)}</div>
      <div class="ai-tip-b">${aiActionButtons(top).replace(/ data-close/g, '')}${a.actions.length > 1 ? `<button type="button" class="btn sm" id="ai-more">+${a.actions.length - 1} more</button>` : ''}</div></div>`;
    $('#ai-more')?.addEventListener('click', () => showAssistant());
  } catch { /* the assistant is optional */ }
}

// A task list in 3 clear groups:
//   To do   - newest added on top (so a task you just added is right under the Add box)
//   Started - running or paused, the one started last on top
//   Done    - the one finished last on top
function groupedList(tasks, now = Date.now(), emptyText = '') {
  const ts = (iso) => (iso ? Date.parse(iso) : 0);
  const todo = tasks.filter((t) => t.status === 'pending').sort((a, b) => ts(b.created_at) - ts(a.created_at) || b.id - a.id);
  const started = tasks.filter((t) => t.status === 'in_progress' || t.status === 'on_hold')
    .sort((a, b) => (a.status === b.status ? 0 : a.status === 'in_progress' ? -1 : 1) || ts(b.updated_at) - ts(a.updated_at));
  const done = tasks.filter((t) => t.status === 'completed').sort((a, b) => ts(b.actual_end) - ts(a.actual_end));
  if (!tasks.length) return `<div class="empty" style="padding:28px">${emptyText}</div>`;
  const group = (icon, label, list, cls) => (list.length ? `<div class="sr-head ${cls}"><span>${icon} ${label}</span><b>${list.length}</b></div>${list.map((t) => simpleRow(t, now)).join('')}` : '');
  return group('📝', 'To do', todo, 'todo') + group('▶', 'Started', started, 'started') + group('✓', 'Done', done, 'done');
}

const GUIDE_KEY = 'wt-guide-seen';
function showGuide() {
  modal({
    title: 'How to use WorkTrack',
    body: `<div class="guide-steps">
        <div><span>1</span><b>Add your task</b><p>On the <b>Today</b> page, type the task name, set the <b>start</b> and <b>end</b> time and click <b>＋ Add</b>. For tomorrow or next week, use the <b>Calendar</b> — you will get a reminder.</p></div>
        <div><span>2</span><b>Click ▶ Start</b><p>Click Start when you begin. The timer starts automatically.</p></div>
        <div><span>3</span><b>Click ✓ Done</b><p>Click Done when you finish. If you forget, WorkTrack will remind you.</p></div>
      </div>
      <div class="callout blue" style="margin-top:14px">Something else came up? Click <b>⏸ Pause</b> — paused time is not counted.</div>`,
    footer: '<button type="button" class="btn primary" data-close>Got it</button>',
  });
  try { localStorage.setItem(GUIDE_KEY, '1'); } catch { /* ignore */ }
}

async function renderMyDashboard() {
  clearInterval(state.refreshTimer);
  const d0 = new Date(); d0.setHours(0, 0, 0, 0);
  const d1 = new Date(d0); d1.setDate(d1.getDate() + 1);
  const [all, offToday] = await Promise.all([
    api('GET', '/api/tasks'),
    api('GET', `/api/leaves?${qs({ from: dayKey(d0), to: dayKey(d0) })}`).then((r) => r[0]).catch(() => null),
  ]);
  const now = Date.now();
  const inDay = (iso) => iso && Date.parse(iso) >= d0.getTime() && Date.parse(iso) < d1.getTime();
  const running = all.filter((t) => t.status === 'in_progress');
  const forgotten = all.filter((t) => t.status === 'on_hold' && t.auto_paused);
  const needReason = all.filter((t) => t.status === 'completed' && t.is_late && t.reason_status === 'rejected');
  const today = all.filter((t) => (t.status === 'in_progress' || (t.status === 'on_hold' && !t.auto_paused))
      || (t.status === 'pending' && inDay(t.start_time)) || (t.status === 'completed' && inDay(t.actual_end)))
    .sort((a, b) => Date.parse(b.start_time || b.created_at) - Date.parse(a.start_time || a.created_at)); // newest on top
  const leftOver = all.filter((t) => t.status === 'pending' && t.start_time && Date.parse(t.start_time) < d0.getTime());
  const future = all.filter((t) => t.status === 'pending' && t.start_time && Date.parse(t.start_time) >= d1.getTime());
  const pendingToday = today.filter((t) => t.status === 'pending');
  const done = today.filter((t) => t.status === 'completed');
  const workedToday = today.reduce((s, t) => s + (t.worked_minutes || 0), 0);
  // the next task is the earliest one still to come (the list itself shows newest on top)
  const byTime = [...pendingToday].sort((a, b) => Date.parse(a.start_time) - Date.parse(b.start_time));
  const nextUp = byTime.find((t) => Date.parse(t.expected_end) > now) || byTime[0];
  state.watch = running;
  state.planWatch = pendingToday;

  // ① what am I doing now
  const main = running[0];
  const nowCard = main ? `<div class="now-card">
      <div class="nc-main"><div class="nc-lbl">Working on now</div><div class="nc-title" data-open="${main.id}">${esc(main.title)}</div>
        <div class="nc-left" data-live="remain" data-hi="1" ${liveAttrs(main)}></div></div>
      <div class="nc-clock" data-live="timer" ${liveAttrs(main)}>00:00:00</div>
      <div class="nc-btns"><button class="btn warn" data-act="pause" data-id="${main.id}">⏸ Pause</button>
        <button class="btn success" data-act="complete" data-id="${main.id}">✓ Done</button></div>
    </div>
    ${running.length > 1 ? `<div class="nc-more">Also running: ${running.slice(1).map((t) => `<a href="#" data-open="${t.id}">${esc(t.title)}</a>`).join(', ')}</div>` : ''}`
    : nextUp ? `<div class="now-card idle">
      <div class="nc-main"><div class="nc-lbl">Next task</div><div class="nc-title">${esc(nextUp.title)}</div>
        <div class="nc-left">At ${hhmm(nextUp.start_time)} · ${dur(planMin(nextUp))}</div></div>
      <div class="nc-btns"><button class="btn primary" data-act="qstart" data-id="${nextUp.id}">▶ Start now</button></div></div>`
    : `<div class="now-card idle"><div class="nc-main"><div class="nc-lbl">No task running</div>
        <div class="nc-left">Add a task below and click ▶ Start.</div></div></div>`;

  // only one message strip at a time - the most important one
  const strip = offToday ? `${offToday.type === 'holiday' ? `🎉 Today is a holiday — ${esc(offToday.note)}` : offToday.type === 'half_day' ? '½ You are on a half day today' : '🌴 You are on leave today'}`
    : needReason.length ? `📝 Your admin returned the delay reason for ${needReason.length} task(s). Open the task from the <a href="#/calendar">Calendar</a> to update the reason.` : '';

  $('#view').innerHTML = `
    <div class="page-head"><div><h2>Hello, ${esc(state.user.name.split(' ')[0])}</h2>
      <div class="muted">${new Date().toLocaleDateString('en-IN', { weekday: 'long', day: 'numeric', month: 'long' })}</div></div>
      <div class="right"><button class="btn" id="break-btn">☕ Take a break</button><button class="btn ai-btn" id="ai-btn">✨ Assistant</button><button class="btn" id="help-btn" title="How to use WorkTrack">❔ Help</button></div></div>
    <div id="break-bar"></div>
    ${strip ? `<div class="one-strip">${strip}</div>` : ''}
    ${notifyBanner()}
    <div id="ai-tip"></div>
    ${forgotten.length ? forgotCard(forgotten) : ''}
    <div class="aaj">
      <section class="aaj-part">${nowCard}<div id="day-extras"></div></section>

      <section class="aaj-part card">
        <div class="aaj-h"><h3>Today's tasks</h3><span class="muted small">${done.length} of ${today.length} done</span></div>
        <form class="simple-add" id="sa" autocomplete="off">
          ${addFields('Add a task… (e.g. Call the client)', defaultSlot(pendingToday))}
        </form>
        <div class="sa-foot"><a href="#" id="sa-more">More options (time, priority, note)</a></div>
        ${leftOver.length ? `<div class="sr-group">Not started from earlier days (${leftOver.length})</div>${leftOver.map((t) => simpleRow(t, now)).join('')}` : ''}
        <div class="sr-list">${groupedList(today, now, 'No tasks for today yet. Add your first task above.')}</div>
        ${future.length ? `<a class="sr-future" href="#/calendar">🗓️ ${future.length} upcoming task(s) in your Calendar →</a>` : ''}
      </section>

      <section class="card" id="my-progress"><div class="empty" style="padding:20px">Loading your progress…</div></section>
    </div>`;

  $('#help-btn').onclick = showGuide;
  $('#ai-btn').onclick = () => showAssistant();
  $('#notif-yes')?.addEventListener('click', async () => { await enableNotifications(); $('#notif-banner')?.remove(); });
  $('#notif-later')?.addEventListener('click', () => { try { localStorage.setItem('wt-notif-later', dayKey(new Date())); } catch { /* ignore */ } $('#notif-banner')?.remove(); });
  loadAssistantTip();
  window.initBreakUI?.();
  window.loadDayExtras?.();
  $('#sa-more').onclick = (e) => { e.preventDefault(); taskFormModal(); };
  bindForgotButtons();
  loadMyProgress();
  bindSimpleAdd($('#sa'), () => dayKey(new Date()));
  if (state.focusQuickAdd) { $('#sa-title').focus(); state.focusQuickAdd = false; }
  tick();
  try { if (!localStorage.getItem(GUIDE_KEY)) showGuide(); } catch { /* ignore */ }
  // refresh every minute, but never while the person is typing
  state.refreshTimer = setInterval(() => {
    const inp = $('#sa-title');
    if (!$('.modal-back') && !(inp && (inp.value || document.activeElement === inp))) renderMyDashboard();
  }, 60000);
}

// ------------------------------------------------------------ Calendar: plan tasks for any future day
async function renderMyCalendar() {
  clearInterval(state.refreshTimer);
  if (!state.calMonth) { const d = new Date(); state.calMonth = { y: d.getFullYear(), m: d.getMonth() }; }
  const { y, m } = state.calMonth;
  const first = new Date(y, m, 1), last = new Date(y, m + 1, 0);
  const gridStart = new Date(first); gridStart.setDate(1 - ((first.getDay() + 6) % 7));
  const gridEnd = new Date(last); gridEnd.setDate(last.getDate() + (7 - ((last.getDay() + 6) % 7)));
  const [tasks, offs] = await Promise.all([
    api('GET', `/api/tasks?${qs({ from: gridStart.toISOString(), to: gridEnd.toISOString() })}`),
    api('GET', `/api/leaves?${qs({ from: dayKey(gridStart), to: dayKey(gridEnd) })}`),
  ]);
  const byDay = {};
  for (const t of tasks) {
    const k = dayKey(new Date(t.status === 'completed' ? t.actual_end : (t.start_time || t.created_at)));
    (byDay[k] = byDay[k] || []).push(t);
  }
  // newest on top
  Object.values(byDay).forEach((l) => l.sort((a, b) => Date.parse(b.start_time || b.created_at) - Date.parse(a.start_time || a.created_at)));
  const offBy = Object.fromEntries(offs.map((l) => [l.day, l]));
  const todayK = dayKey(new Date());
  if (!state.calDay) state.calDay = todayK;
  const sel = state.calDay;

  let grid = '';
  for (let d = new Date(gridStart); d < gridEnd; d.setDate(d.getDate() + 1)) {
    const k = dayKey(d), list = byDay[k] || [], off = offBy[k];
    const doneN = list.filter((t) => t.status === 'completed').length;
    grid += `<button type="button" class="cal-day ${d.getMonth() === m ? '' : 'out'} ${k === todayK ? 'today' : ''} ${k === sel ? 'sel' : ''} ${k < todayK ? 'past' : ''}" data-cal="${k}">
      <span class="cd-n">${d.getDate()}</span>
      ${off ? `<span class="cd-off">${off.type === 'holiday' ? '🎉' : '🌴'}</span>` : ''}
      ${list.length ? `<span class="cd-dots">${list.slice(0, 4).map((t) => `<i class="${t.status === 'completed' ? 'ok' : t.status === 'pending' ? 'plan' : 'run'}"></i>`).join('')}</span>
        <span class="cd-count">${k < todayK ? `${doneN}/${list.length} done` : `${list.length} task${list.length > 1 ? 's' : ''}`}</span>` : ''}
    </button>`;
  }
  const selDate = new Date(`${sel}T12:00`);
  const selList = byDay[sel] || [];
  const isPast = sel < todayK;
  const selOff = offBy[sel];

  $('#view').innerHTML = `
    <div class="page-head"><div><h2>Calendar</h2><div class="muted">Plan tasks for any date. On that day they appear in your Today list automatically.</div></div>
      <div class="right"><button class="btn" id="help-btn">❔ Help</button></div></div>
    <div class="cal-wrap">
      <div class="card cal-card">
        <div class="cal-top">
          <button class="btn sm" id="c-prev" aria-label="Previous month">◀</button>
          <b>${first.toLocaleDateString('en-IN', { month: 'long', year: 'numeric' })}</b>
          <button class="btn sm" id="c-next" aria-label="Next month">▶</button>
          <button class="btn sm" id="c-today">Today</button>
        </div>
        <div class="cal-wk">${['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].map((w) => `<span>${w}</span>`).join('')}</div>
        <div class="cal-days">${grid}</div>
        <div class="cal-legend"><span><i class="plan"></i>Planned</span><span><i class="ok"></i>Done</span><span><i class="run"></i>In progress / paused</span></div>
      </div>

      <div class="card day-card">
        <div class="aaj-h"><h3>${sel === todayK ? 'Today · ' : ''}${selDate.toLocaleDateString('en-IN', { weekday: 'long', day: 'numeric', month: 'long' })}</h3></div>
        ${selOff ? `<div class="one-strip" style="margin:0 16px 10px">${selOff.type === 'holiday' ? `🎉 Holiday — ${esc(selOff.note)}` : selOff.type === 'half_day' ? '½ Half day' : '🌴 On leave'}</div>` : ''}
        ${isPast ? `
        <form class="simple-add" id="ca" autocomplete="off">
          ${addFields('Forgot to add a finished task? Write it here', new Date(`${sel}T10:00`), ['done'])}
        </form>
        <div class="sa-foot" style="padding-top:0">Past date — you can only add work you already finished.</div>` : `
        <form class="simple-add" id="ca" autocomplete="off">
          ${addFields('What do you need to do on this day?', sel === todayK ? defaultSlot(selList.filter((t) => t.status === 'pending')) : new Date(`${sel}T10:00`), sel === todayK ? ['plan', 'done'] : ['plan'])}
        </form>`}
        <div class="sr-list">${groupedList(selList, Date.now(), isPast ? 'No tasks on this day.' : 'No tasks planned yet. Add one above.')}</div>
        ${selList.length ? `<div class="aaj-sum" style="margin:0;border-radius:0 0 var(--radius) var(--radius)">${selList.filter((t) => t.status === 'completed').length} of ${selList.length} done · ${dur(selList.reduce((s, t) => s + (t.worked_minutes || 0), 0))} worked${(() => { const p = progressStats(selList.filter((t) => t.status === 'completed')).pct; return p == null ? '' : ` · <b>${p}% accuracy</b>`; })()}</div>` : ''}
      </div>
    </div>`;

  const go = (dm) => { const d = new Date(y, m + dm, 1); state.calMonth = { y: d.getFullYear(), m: d.getMonth() }; renderMyCalendar(); };
  $('#c-prev').onclick = () => go(-1);
  $('#c-next').onclick = () => go(1);
  $('#c-today').onclick = () => { state.calMonth = null; state.calDay = todayK; renderMyCalendar(); };
  $('#help-btn').onclick = showGuide;
  $$('[data-cal]').forEach((b) => b.onclick = () => { state.calDay = b.dataset.cal; renderMyCalendar(); });
  if ($('#ca')) {
    bindSimpleAdd($('#ca'), () => sel, sel === todayK ? '' : selDate.toLocaleDateString('en-IN', { weekday: 'short', day: 'numeric', month: 'short' }));
  }
  if (state.focusQuickAdd) { $('#sa-title')?.focus(); state.focusQuickAdd = false; }
  tick();
}
// Tasks that were left running and got stopped automatically at the end of the day
function forgotCard(list) {
  return `<div class="card forgot-card">
    <div class="card-h"><div class="h-ico tone-violet">🌙</div><div><h3>${list.length === 1 ? 'A task was' : `${list.length} tasks were`} left running</h3>
      <div class="t-sub">The timer was stopped automatically at the end of the day, so no extra time was counted. Please confirm when you finished.</div></div></div>
    ${list.map((t) => {
      const planEnd = Date.parse(t.expected_end) + (t.paused_minutes || 0) * 60000;
      const end = new Date(Math.min(planEnd, Date.parse(t.paused_at)));
      return `<div class="forgot-row">
        <div style="min-width:0"><b>${esc(t.title)}</b>
          <div class="t-sub">Started ${fmtSmart(t.start_time)} · planned until ${fmtSmart(new Date(planEnd).toISOString())} · timer stopped ${fmtSmart(t.paused_at)}</div></div>
        <div class="row" style="flex-wrap:wrap;justify-content:flex-end">
          <button class="btn success sm" data-forgot-end="${t.id}" data-at="${end.toISOString()}">✓ Finished at ${hhmm(end)}</button>
          <button class="btn sm" data-act="complete" data-id="${t.id}">Other time…</button>
          <button class="btn sm" data-act="resume" data-id="${t.id}">▶ Still working</button>
        </div></div>`;
    }).join('')}
  </div>`;
}
function bindForgotButtons() {
  $$('[data-forgot-end]').forEach((b) => b.addEventListener('click', async () => {
    b.disabled = true;
    try {
      await api('POST', `/api/tasks/${b.dataset.forgotEnd}/complete`, { actual_end: b.dataset.at });
      toast('✓ Saved with the correct finish time');
      refresh();
    } catch (x) {
      if (/reason/i.test(x.message)) completeModal(await api('GET', `/api/tasks/${b.dataset.forgotEnd}`)); else toast(x.message, 'error');
      b.disabled = false;
    }
  }));
}

// The add box: task name + start time + end time. The planned time is saved now;
// the real time is counted only from the moment you press ▶ Start until ✓ Done.
function defaultSlot(pendingList) {
  // a new task starts where the plan ends, or in a few minutes
  const lastEnd = Math.max(...pendingList.map((t) => Date.parse(t.expected_end)), 0);
  const d = new Date(Math.max(lastEnd, Date.now() + 60000));
  d.setSeconds(0, 0);
  d.setMinutes(Math.ceil(d.getMinutes() / 5) * 5); // round UP, so it never overlaps the previous task
  return d;
}
// kinds: 'plan' = ＋ Add (to do later), 'done' = ✓ Already done (forgot to add a finished task)
function addFields(placeholder, start, kinds = ['plan', 'done']) {
  const end = new Date(start.getTime() + 30 * 60000);
  return `<input id="sa-title" maxlength="150" placeholder="${esc(placeholder)}" required>
    <label class="sa-t"><span>Start</span><input type="time" id="sa-from" value="${timeStr(start)}" step="300" required></label>
    <label class="sa-t"><span>End</span><input type="time" id="sa-to" value="${timeStr(end)}" step="300" required></label>
    ${kinds.includes('plan') ? '<button class="btn primary" type="submit" data-kind="plan">＋ Add</button>' : ''}
    ${kinds.includes('done') ? `<button class="btn ${kinds.includes('plan') ? '' : 'primary'} sa-done" type="submit" data-kind="done" title="Already finished this task? Save it straight to Done">✓ Already done</button>` : ''}
    <div class="sa-plan" id="sa-plan"></div>`;
}

// After adding a task: it is only added to the list. The person decides whether to start it now.
// (Tasks for another day are just confirmed - they cannot be started before their day.)
function askToStart(t, dayLabel = '') {
  setTimeout(() => { if (state.flashTaskId === t.id) state.flashTaskId = null; }, 8000);
  // this question already covers a task that starts within the reminder time - no extra "starts soon" popup on top of it
  const startsIn = Date.parse(t.start_time) - Date.now();
  if (startsIn < remindMinutes() * 60000) state.notified.add(`pre-${t.id}`);
  if (startsIn < 120000) state.notified.add(`plan-${t.id}`);
  const isToday = dayKey(new Date(t.start_time)) === dayKey(new Date());
  if (!isToday) { toast(`Added: ${t.title} · ${dayLabel || niceTime(new Date(t.start_time))}`); state.focusQuickAdd = true; return; }
  modal({
    title: '✓ Task added',
    body: `<div class="ask-start">
        <div class="as-title">${esc(t.title)}</div>
        <div class="t-sub">Planned ${hhmm(t.start_time)} – ${hhmm(t.expected_end)} · ${dur(planMin(t))}</div>
        <p>It is in your <b>To do</b> list. Do you want to start it now?</p>
      </div>`,
    footer: `<button type="button" class="btn" id="as-later" data-close>Later</button>
      <button type="button" class="btn primary" id="as-start" data-close>▶ Start now</button>`,
    onOpen: (form) => {
      $('#as-start', form).addEventListener('click', async () => {
        try { quickStart(await api('GET', `/api/tasks/${t.id}`)); } catch (x) { toast(x.message, 'error'); }
      });
      $('#as-later', form).addEventListener('click', () => { toast('Added to your To do list'); state.focusQuickAdd = true; setTimeout(() => $('#sa-title')?.focus(), 50); });
      setTimeout(() => $('#as-start', form).focus(), 40);
    },
  });
}

// `dayOf()` gives the day (YYYY-MM-DD) the task is for.
// (Typing "10-11 Client call" also fills the times; pasting many lines adds many tasks.)
function bindSimpleAdd(form, dayOf, dayLabel = '') {
  const title = $('#sa-title', form), from = $('#sa-from', form), to = $('#sa-to', form), plan = $('#sa-plan', form);
  const doneOnly = !form.querySelector('[data-kind="plan"]');
  const at = (hm) => new Date(`${dayOf()}T${hm}`);
  const minutes = () => Math.round((at(to.value) - at(from.value)) / 60000);
  const show = () => {
    const m = minutes();
    plan.textContent = m > 0 ? `${doneOnly ? 'Time taken' : 'Planned'}: ${dur(m)}${dayLabel ? ` · ${dayLabel}` : ''}` : 'End time must be after the start time';
    plan.classList.toggle('bad', !(m > 0));
  };
  let lastDur = 30;
  from.addEventListener('change', () => { // moving the start keeps the same planned length
    to.value = timeStr(new Date(at(from.value).getTime() + lastDur * 60000)); show();
  });
  to.addEventListener('change', () => { if (minutes() > 0) lastDur = minutes(); show(); });
  title.addEventListener('input', () => {
    const p = parsePlanLine(title.value);
    if (p.from) { from.value = timeStr(p.from); to.value = timeStr(p.to); lastDur = Math.max(5, minutes()); show(); }
  });
  show();

  form.addEventListener('submit', async (ev) => {
    ev.preventDefault();
    const kind = ev.submitter?.dataset.kind || (form.querySelector('[data-kind="plan"]') ? 'plan' : 'done');
    const p = parsePlanLine(title.value);
    if (!p.title) return title.focus();
    const s = at(from.value), e = at(to.value);
    if (e <= s) { toast('End time must be after the start time', 'error'); return to.focus(); }
    if (kind === 'done' && e.getTime() > Date.now() + 60000) { toast('“Already done” is for finished work — the end time cannot be in the future', 'error'); return to.focus(); }
    const btns = $$('button[type=submit]', form); btns.forEach((b) => { b.disabled = true; });
    try {
      if (kind === 'done') {
        // a finished task you forgot to add: it goes straight to Done with these exact times
        await api('POST', '/api/tasks', { title: p.title, priority: 'medium', mode: 'completed', start_time: s.toISOString(), expected_end: e.toISOString(), actual_end: e.toISOString() });
        toast(`✓ Saved as done: ${p.title} · ${dayLabel ? dayLabel + ', ' : ''}${hhmm(s)} – ${hhmm(e)} (${dur((e - s) / 60000)})`);
        state.focusQuickAdd = true;
        refresh();
        return;
      }
      const created = await api('POST', '/api/tasks', { title: p.title, priority: 'medium', mode: 'plan', start_time: s.toISOString(), expected_end: e.toISOString() });
      state.flashTaskId = created.id; // highlight it at the top of "To do"
      state.pendingMine = null; pollNotifications(); // reminders pick up the new task right away
      refresh();
      askToStart(created, dayLabel);
    } catch (x) { toast(x.message, 'error'); } finally { btns.forEach((b) => { b.disabled = false; }); }
  });
  const durSel = { get value() { return Math.max(5, minutes()); } };
  const startAt = () => at(from.value);
  // paste many lines -> many tasks, one after another
  title.addEventListener('paste', async (ev) => {
    const text = (ev.clipboardData || window.clipboardData).getData('text');
    const lines = text.split(/\r?\n/).map((l) => l.replace(/^\s*(?:[-*•]|\d{1,2}[.)])\s+/, '').trim()).filter(Boolean);
    if (lines.length < 2) return;
    ev.preventDefault();
    let cursor = startAt();
    try {
      for (const line of lines) {
        const p = parsePlanLine(line);
        let s = cursor, e = new Date(cursor.getTime() + Number(durSel.value) * 60000);
        if (p.from) { s = new Date(cursor); s.setHours(p.from.getHours(), p.from.getMinutes(), 0, 0); e = new Date(cursor); e.setHours(p.to.getHours(), p.to.getMinutes(), 0, 0); }
        if (doneOnly) {
          // past day: the pasted lines are finished work
          await api('POST', '/api/tasks', { title: p.title, priority: 'medium', mode: 'completed', start_time: s.toISOString(), expected_end: e.toISOString(), actual_end: e.toISOString() });
        } else {
          await api('POST', '/api/tasks', { title: p.title, priority: 'medium', mode: 'plan', start_time: s.toISOString(), expected_end: e.toISOString() });
        }
        cursor = e;
      }
      toast(`${lines.length} tasks added`);
      state.focusQuickAdd = true;
      refresh();
    } catch (x) { toast(x.message, 'error'); }
  });
}

// ============================================================ EMPLOYEE: all my tasks
async function renderMyTasks() {
  const f = state.myFilters || (state.myFilters = { status: '', priority: '', period: 'month', q: '' });
  $('#view').innerHTML = `
    <div class="page-head"><div><h2>My tasks</h2><div class="muted">All your tasks. Click a row to see details and its full history.</div></div><div class="right"><button class="btn primary" id="new-task">＋ New Task</button></div></div>
    <div class="card">
      <div class="filters">
        <input type="search" id="f-q" placeholder="Search…" value="${esc(f.q)}">
        <select id="f-status"><option value="">All statuses</option>${[['active', 'Active'], ['pending', 'Planned'], ['completed', 'Completed'], ['overdue', 'Overdue']].map(([v, l]) => `<option value="${v}" ${f.status === v ? 'selected' : ''}>${l}</option>`).join('')}</select>
        <select id="f-priority"><option value="">All priorities</option>${Object.entries(PRIORITY_LABEL).map(([v, l]) => `<option value="${v}" ${f.priority === v ? 'selected' : ''}>${l}</option>`).join('')}</select>
        <select id="f-period">${PERIODS.map(([v, l]) => `<option value="${v}" ${f.period === v ? 'selected' : ''}>${l}</option>`).join('')}</select>
      </div>
      <div id="task-list"></div>
    </div>`;
  const load = async () => {
    const tasks = await api('GET', `/api/tasks?${qs({ status: f.status, priority: f.priority, q: f.q, ...periodRange(f.period) })}`);
    $('#task-list').innerHTML = taskTable(tasks);
    tick();
  };
  ['status', 'priority', 'period'].forEach((k) => $(`#f-${k}`).addEventListener('change', (e) => { f[k] = e.target.value; load(); }));
  let tmr; $('#f-q').addEventListener('input', (e) => { clearTimeout(tmr); tmr = setTimeout(() => { f.q = e.target.value; load(); }, 300); });
  $('#new-task').onclick = () => taskFormModal();
  await load();
}

// ============================================================ profile
async function renderProfile() {
  const u = state.user;
  $('#view').innerHTML = `
    <div class="card card-b" style="max-width:560px">
      <div class="row" style="margin-bottom:18px">${avatar(u.name)}<div><h2>${esc(u.name)}</h2><div class="muted">${esc(u.username)} · ${u.role === 'admin' ? 'Administrator' : 'Employee'}</div></div></div>
      <div class="detail-grid" style="grid-template-columns:1fr 1fr">
        <div><span>Department</span><b>${esc(u.department) || '—'}</b></div>
        <div><span>Designation</span><b>${esc(u.designation) || '—'}</b></div>
      </div>
      ${u.role === 'admin' ? `<div class="row"><button class="btn primary" id="pw-btn">🔑 Change password</button>
          <a class="btn" href="/api/admin/backup" download>⬇ Download full backup</a></div>
        <div class="hint" style="margin-top:10px">Backup = complete copy of all data. A copy is also saved automatically in Firebase every evening at 7 PM (last 30 days kept).</div>`
        : '<button class="btn primary" id="pw-btn">🔑 Change password</button>'}
    </div>
    <div class="card card-b" style="max-width:560px;margin-top:20px" id="session-card"></div>
    <div class="card card-b" style="max-width:560px;margin-top:20px" id="remind-card">
      <h3 style="margin-bottom:6px">🔔 Reminders</h3>
      <div class="muted" style="margin-bottom:14px">You are reminded before a task starts and before its deadline. If the task is not done in time, you get an overdue alert.</div>
      <label style="max-width:260px">Remind me before start and deadline
        <select id="rm-min">${[5, 10, 15, 30].map((m) => `<option value="${m}" ${m === remindMinutes() ? 'selected' : ''}>${m} minutes before</option>`).join('')}</select></label>
      <div id="notif-state"></div>
    </div>
    ${u.role === 'admin' ? `<div class="card card-b" style="max-width:560px;margin-top:20px" id="autostop-card">
      <h3 style="margin-bottom:6px">🌙 End-of-day auto-stop</h3>
      <div class="muted" style="margin-bottom:14px">If an employee forgets to stop a task, its clock stops automatically at this time. Next day they are asked when they really finished — so forgotten tasks never count extra hours.</div>
      <div class="row">
        <label style="margin:0">Stop running tasks at<input type="time" id="as-time" step="300" style="width:140px"></label>
        <label class="row" style="margin:0;gap:8px;font-size:13.5px;color:var(--text)"><input type="checkbox" id="as-off" style="width:auto"> Turn off</label>
        <button class="btn primary" id="as-save" style="align-self:flex-end">Save</button>
      </div>
      <h3 style="margin:20px 0 6px">⏰ Working hours per day</h3>
      <div class="muted" style="margin-bottom:14px">Time worked beyond this in a day is shown as overtime in the daily report.</div>
      <div class="row"><label style="margin:0">Hours per day<input type="number" id="wh" min="1" max="16" step="0.5" style="width:110px"></label>
        <button class="btn primary" id="wh-save" style="align-self:flex-end">Save</button></div>
    </div>` : ''}`;
  window.renderSessionCard?.();
  if ($('#pw-btn')) $('#pw-btn').onclick = () => passwordModal(false);
  $('#rm-min').onchange = (e) => {
    try { localStorage.setItem(REMIND_KEY, e.target.value); } catch { /* ignore */ }
    toast(`You will be reminded ${e.target.value} minutes before`);
  };
  renderNotifState($('#notif-state'));
  if (u.role === 'admin') {
    const s = await api('GET', '/api/settings');
    const off = s.auto_stop_time === 'off';
    $('#as-time').value = off ? '20:00' : s.auto_stop_time;
    $('#wh').value = s.work_hours_per_day;
    $('#wh-save').onclick = async () => {
      try { const r = await api('PUT', '/api/settings', { work_hours_per_day: Number($('#wh').value) }); toast(`Working day set to ${r.work_hours_per_day} hours`); } catch (x) { toast(x.message, 'error'); }
    };
    $('#as-off').checked = off;
    $('#as-time').disabled = off;
    $('#as-off').onchange = (e) => { $('#as-time').disabled = e.target.checked; };
    $('#as-save').onclick = async () => {
      try {
        const r = await api('PUT', '/api/settings', { auto_stop_time: $('#as-off').checked ? 'off' : $('#as-time').value });
        toast(r.auto_stop_time === 'off' ? 'Auto-stop turned off' : `Running tasks will stop automatically at ${r.auto_stop_time}`);
      } catch (x) { toast(x.message, 'error'); }
    };
  }
}

// ============================================================ boot
(async () => {
  tick();
  try {
    const { user } = await api('GET', '/api/me');
    await startApp(user);
  } catch { showLogin(); }
})();

@echo off
title WorkTrack - Export office data for Firebase
cd /d "%~dp0"
set "NODE=node"
if exist "%~dp0..\runtime\node.exe" set "NODE=%~dp0..\runtime\node.exe"
"%NODE%" --no-warnings export-office-data.js
echo.
pause

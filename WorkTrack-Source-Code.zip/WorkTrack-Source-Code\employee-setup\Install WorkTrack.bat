@echo off
title Install WorkTrack
cd /d "%~dp0"
set "DEST=%LOCALAPPDATA%\WorkTrack"
echo Installing WorkTrack on this PC...
if not exist "%DEST%" mkdir "%DEST%"
copy /y "WorkTrack.vbs" "%DEST%\" >nul
copy /y "worktrack.ico" "%DEST%\" >nul
copy /y "config.txt" "%DEST%\" >nul
copy /y "Uninstall WorkTrack.bat" "%DEST%\" >nul
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$d = Join-Path $env:LOCALAPPDATA 'WorkTrack';" ^
  "Get-ChildItem $d | Unblock-File;" ^
  "$ws = New-Object -ComObject WScript.Shell;" ^
  "foreach ($p in @([Environment]::GetFolderPath('Desktop'), (Join-Path ([Environment]::GetFolderPath('Programs')) ''))) {" ^
  "  $l = $ws.CreateShortcut((Join-Path $p 'WorkTrack.lnk'));" ^
  "  $l.TargetPath = \"$env:WINDIR\System32\wscript.exe\";" ^
  "  $l.Arguments = '\"' + (Join-Path $d 'WorkTrack.vbs') + '\"';" ^
  "  $l.WorkingDirectory = $d;" ^
  "  $l.IconLocation = (Join-Path $d 'worktrack.ico') + ',0';" ^
  "  $l.Description = 'WorkTrack - Office Task Manager';" ^
  "  $l.Save() }"
echo.
echo Done! A "WorkTrack" icon is now on your Desktop (and in the Start menu).
echo Double-click it any time and log in with the username and password from your admin.
echo.
start "" "%WINDIR%\System32\wscript.exe" "%DEST%\WorkTrack.vbs"
pause

' WorkTrack - employee PC launcher
' Opens WorkTrack from the office server in its own app window.
' Nothing is stored on this PC: all data stays on the office server.
Option Explicit
Dim sh, fso, here, urls, line, f, url, found, edge, chrome

Set sh = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
here = fso.GetParentFolderName(WScript.ScriptFullName)

' server addresses (PC name first, then IP) are written in config.txt
urls = Array()
If fso.FileExists(here & "\config.txt") Then
  Set f = fso.OpenTextFile(here & "\config.txt", 1)
  Do Until f.AtEndOfStream
    line = Trim(f.ReadLine)
    If Left(LCase(line), 7) = "http://" Or Left(LCase(line), 8) = "https://" Then
      ReDim Preserve urls(UBound(urls) + 1)
      urls(UBound(urls)) = line
    End If
  Loop
  f.Close
End If

Function Reachable(u)
  Dim http
  Reachable = False
  On Error Resume Next
  Set http = CreateObject("MSXML2.ServerXMLHTTP.6.0")
  http.setTimeouts 5000, 5000, 15000, 20000   ' the online server may need a few seconds to wake up
  http.open "GET", u & "/api/me", False
  http.send
  If Err.Number = 0 Then
    If http.status = 200 Or http.status = 401 Then Reachable = True
  End If
  On Error GoTo 0
End Function

found = ""
For Each url In urls
  If Reachable(url) Then found = url : Exit For
Next

If found = "" Then
  MsgBox "WorkTrack cannot connect." & vbCrLf & vbCrLf & _
    "- Check that this PC is connected to the internet." & vbCrLf & _
    "- Then try again in a minute." & vbCrLf & vbCrLf & _
    "If it still does not open, please contact your admin.", vbExclamation, "WorkTrack"
  WScript.Quit 1
End If

edge = RegPath("HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\msedge.exe\")
chrome = RegPath("HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\chrome.exe\")
If edge <> "" Then
  sh.Run """" & edge & """ --app=" & found & " --window-size=1400,900", 1, False
ElseIf chrome <> "" Then
  sh.Run """" & chrome & """ --app=" & found & " --window-size=1400,900", 1, False
Else
  sh.Run found, 1, False
End If

Function RegPath(key)
  RegPath = ""
  On Error Resume Next
  RegPath = sh.RegRead(key)
  On Error GoTo 0
  If RegPath <> "" Then
    If Not fso.FileExists(RegPath) Then RegPath = ""
  End If
End Function

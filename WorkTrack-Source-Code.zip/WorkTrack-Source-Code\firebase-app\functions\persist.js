// Keeps the in-memory database saved. `store` is { load(), save(bytes, generation) } - Firebase Storage
// in the cloud (index.js) or a local file for testing (local-server.js).
const dbm = require('./db');

function createPersistence(store) {
  let savedChanges = 0;
  let queue = Promise.resolve();

  const totalChanges = () => dbm.db.changeCount();

  async function start() {
    const bytes = await store.load();
    await dbm.init(bytes);
    // first start (no file yet) or schema updates -> save right away
    if (!bytes || totalChanges() > 0) await store.save(dbm.db.export());
    savedChanges = totalChanges();
  }

  // Returns a promise when there is something to save, otherwise null (nothing changed)
  function saveIfChanged() {
    if (!dbm.db || totalChanges() === savedChanges) return null;
    queue = queue.then(async () => {
      const now = totalChanges();
      if (now === savedChanges) return;
      const bytes = dbm.db.export();
      for (let attempt = 1; ; attempt++) {
        try { await store.save(bytes); break; } catch (e) {
          if (attempt >= 3) throw e;
          await new Promise((r) => setTimeout(r, 400 * attempt));
        }
      }
      savedChanges = now;
    });
    return queue;
  }

  return { start, saveIfChanged };
}

module.exports = { createPersistence };

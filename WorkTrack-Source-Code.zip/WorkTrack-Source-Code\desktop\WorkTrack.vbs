' WorkTrack desktop launcher
' - starts the server silently in the background (if it is not already running)
' - opens WorkTrack in its own app window (no browser tabs / address bar)
Option Explicit
Dim sh, fso, appDir, url, i, edge, chrome

Set sh = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
appDir = fso.GetParentFolderName(fso.GetParentFolderName(WScript.ScriptFullName))
url = "http://localhost:3000"

Function ServerUp()
  Dim http
  ServerUp = False
  On Error Resume Next
  Set http = CreateObject("MSXML2.ServerXMLHTTP.6.0")
  http.setTimeouts 1000, 1000, 1000, 1000
  http.open "GET", url & "/api/me", False
  http.send
  If Err.Number = 0 Then
    If http.status = 200 Or http.status = 401 Then ServerUp = True
  End If
  On Error GoTo 0
End Function

If Not ServerUp() Then
  If Not fso.FolderExists(appDir & "\data") Then fso.CreateFolder appDir & "\data"
  sh.CurrentDirectory = appDir
  ' use the bundled Node.js (portable version) if present, otherwise the installed one
  Dim nodeExe
  nodeExe = "node"
  If fso.FileExists(appDir & "\runtime\node.exe") Then nodeExe = """" & appDir & "\runtime\node.exe"""
  ' window style 0 = hidden; output goes to data\server.log
  sh.Run "cmd /c """ & nodeExe & " --no-warnings server.js >> ""data\server.log"" 2>&1""", 0, False
  For i = 1 To 30
    WScript.Sleep 500
    If ServerUp() Then Exit For
  Next
  If Not ServerUp() Then
    MsgBox "WorkTrack could not start." & vbCrLf & vbCrLf & _
      "Please check that Node.js is installed, then open data\server.log for details.", vbCritical, "WorkTrack"
    WScript.Quit 1
  End If
End If

edge = RegPath("HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\msedge.exe\")
chrome = RegPath("HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\chrome.exe\")
If edge <> "" Then
  sh.Run """" & edge & """ --app=" & url & " --window-size=1400,900", 1, False
ElseIf chrome <> "" Then
  sh.Run """" & chrome & """ --app=" & url & " --window-size=1400,900", 1, False
Else
  sh.Run url, 1, False
End If

Function RegPath(key)
  RegPath = ""
  On Error Resume Next
  RegPath = sh.RegRead(key)
  On Error GoTo 0
  If RegPath <> "" Then
    If Not fso.FileExists(RegPath) Then RegPath = ""
  End If
End Function

// WorkTrack on Firebase
//  - "app"          : the whole API (same rules as the office version), behind Firebase Hosting
//  - "dailyBackup"  : copies the database every evening at 7 PM (India time), keeps 30 days
// The database is a single SQLite file kept in Firebase Storage: worktrack/taskmanager.sqlite
process.env.TZ = 'Asia/Kolkata'; // dates, "today" and leave days follow India time

const { onRequest } = require('firebase-functions/v2/https');
const { onSchedule } = require('firebase-functions/v2/scheduler');
const admin = require('firebase-admin');
const { createPersistence } = require('./persist');

admin.initializeApp();
const DB_PATH = 'worktrack/taskmanager.sqlite';
const REGION = 'asia-south1'; // Mumbai

const storageStore = {
  async load() {
    const file = admin.storage().bucket().file(DB_PATH);
    const [exists] = await file.exists();
    if (!exists) return null;
    const [bytes] = await file.download();
    return bytes;
  },
  async save(bytes) {
    await admin.storage().bucket().file(DB_PATH).save(bytes, {
      resumable: false, contentType: 'application/x-sqlite3', metadata: { cacheControl: 'no-store' },
    });
  },
};

const persistence = createPersistence(storageStore);
let ready = null;
let app = null;

exports.app = onRequest({
  region: REGION,
  maxInstances: 1,      // one copy of the database in memory = always consistent
  concurrency: 80,
  memory: '512MiB',
  timeoutSeconds: 60,
}, async (req, res) => {
  try {
    if (!ready) {
      ready = persistence.start().then(() => {
        const m = require('./app');
        m.hooks.beforeEnd = persistence.saveIfChanged;
        app = m.app;
      });
    }
    await ready;
  } catch (e) {
    ready = null;
    console.error('Start-up failed:', e);
    res.status(503).json({ error: 'Server is starting, please try again in a moment.' });
    return;
  }
  app(req, res);
});

exports.dailyBackup = onSchedule({ schedule: '0 19 * * *', timeZone: 'Asia/Kolkata', region: REGION }, async () => {
  const bucket = admin.storage().bucket();
  const src = bucket.file(DB_PATH);
  const [exists] = await src.exists();
  if (!exists) return;
  const day = new Date().toLocaleDateString('en-CA', { timeZone: 'Asia/Kolkata' }); // YYYY-MM-DD
  await src.copy(bucket.file(`worktrack/backups/${day}.sqlite`));
  const [files] = await bucket.getFiles({ prefix: 'worktrack/backups/' });
  const old = files.map((f) => f.name).sort().reverse().slice(30);
  await Promise.all(old.map((n) => bucket.file(n).delete().catch(() => {})));
  console.log(`Backup saved: worktrack/backups/${day}.sqlite`);
});

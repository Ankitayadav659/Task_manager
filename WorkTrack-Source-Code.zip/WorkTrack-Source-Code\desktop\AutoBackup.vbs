' Runs the WorkTrack backup silently (used by the daily Windows scheduled task).
' Output is appended to data\backup.log
Option Explicit
Dim sh, fso, appDir
Set sh = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
appDir = fso.GetParentFolderName(fso.GetParentFolderName(WScript.ScriptFullName))
sh.CurrentDirectory = appDir
Dim nodeExe
nodeExe = "node"
If fso.FileExists(appDir & "\runtime\node.exe") Then nodeExe = """" & appDir & "\runtime\node.exe"""
If Not fso.FolderExists(appDir & "\data") Then fso.CreateFolder appDir & "\data"
sh.Run "cmd /c ""(echo ===== %date% %time% & " & nodeExe & " --no-warnings backup.js) >> ""data\backup.log"" 2>&1""", 0, True

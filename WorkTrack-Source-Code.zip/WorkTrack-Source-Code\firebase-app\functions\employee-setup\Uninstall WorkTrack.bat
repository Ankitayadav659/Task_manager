@echo off
title Uninstall WorkTrack
del /q "%USERPROFILE%\Desktop\WorkTrack.lnk" 2>nul
powershell -NoProfile -Command "Remove-Item -Force -ErrorAction SilentlyContinue (Join-Path ([Environment]::GetFolderPath('Desktop')) 'WorkTrack.lnk'), (Join-Path ([Environment]::GetFolderPath('Programs')) 'WorkTrack.lnk')"
echo WorkTrack shortcuts removed from this PC.
echo (Your work is safe - it is stored online, not on this PC.)
cd /d "%TEMP%"
start "" /b cmd /c "timeout /t 2 >nul & rmdir /s /q ""%LOCALAPPDATA%\WorkTrack"""
pause

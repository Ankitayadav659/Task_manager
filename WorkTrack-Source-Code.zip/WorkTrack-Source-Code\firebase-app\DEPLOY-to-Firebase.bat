@echo off
title WorkTrack - Put online on Firebase
cd /d "%~dp0"
echo ============================================================
echo   WorkTrack  -^>  Firebase (online)
echo   Before this: finish steps 1-4 in FIREBASE-SETUP-GUIDE.txt
echo ============================================================
echo.
set /p PROJECT=Type your Firebase Project ID and press Enter:
if "%PROJECT%"=="" goto :eof
echo.
echo Step A: Google sign-in (a browser window opens - sign in with the account that owns the project)
call npx --yes firebase-tools@15 login
echo.
echo Step B: preparing the server code...
pushd functions
call npm install --omit=dev
popd
echo.
echo Step C: uploading WorkTrack to Firebase (takes 2-5 minutes the first time)...
call npx --yes firebase-tools@15 deploy --project %PROJECT%
echo.
echo ============================================================
echo  If you see "Deploy complete!", WorkTrack is online at:
echo     https://%PROJECT%.web.app
echo ============================================================
pause

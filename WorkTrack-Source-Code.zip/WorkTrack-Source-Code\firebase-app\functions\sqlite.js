// Small adapter that gives sql.js (SQLite compiled to WebAssembly, runs anywhere)
// the same API the office version uses from node:sqlite:  exec(), prepare().get/all/run()
const initSqlJs = require('sql.js');

let SQL = null;

const toParam = (v) => (v === undefined ? null : typeof v === 'boolean' ? (v ? 1 : 0) : v);

async function openDatabase(bytes) {
  SQL = SQL || await initSqlJs();
  const raw = bytes && bytes.length ? new SQL.Database(new Uint8Array(bytes)) : new SQL.Database();
  let changes = 0; // counts writes, so we know when the database must be saved

  const api = {
    changeCount: () => changes,
    exec(sql) {
      raw.exec(sql);
      if (!/^\s*(BEGIN|COMMIT|ROLLBACK)\b/i.test(sql)) changes++;
    },
    prepare(sql) {
      const withStmt = (params, fn) => {
        const st = raw.prepare(sql);
        try {
          if (params.length) st.bind(params.map(toParam));
          return fn(st);
        } finally { st.free(); }
      };
      return {
        get: (...p) => withStmt(p, (st) => (st.step() ? st.getAsObject() : undefined)),
        all: (...p) => withStmt(p, (st) => { const rows = []; while (st.step()) rows.push(st.getAsObject()); return rows; }),
        run: (...p) => {
          withStmt(p, (st) => { st.step(); });
          const n = raw.getRowsModified();
          changes += n;
          const id = raw.exec('SELECT last_insert_rowid() AS id')[0].values[0][0];
          return { changes: n, lastInsertRowid: id };
        },
      };
    },
    // full database file as bytes (for saving to Firebase Storage)
    export() {
      const bytes = raw.export();
      raw.exec('PRAGMA foreign_keys = ON;'); // export() resets pragmas
      return Buffer.from(bytes);
    },
  };
  return api;
}

module.exports = { openDatabase };

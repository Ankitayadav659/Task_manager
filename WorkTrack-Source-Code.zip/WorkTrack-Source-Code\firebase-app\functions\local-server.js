// Runs the Firebase version on this PC for testing (no Firebase account needed).
// Uses a local file instead of Firebase Storage and serves ../public like Firebase Hosting would.
//   node local-server.js            -> http://localhost:5050
process.env.TZ = process.env.TZ || 'Asia/Kolkata';
const fs = require('fs');
const path = require('path');
const express = require('express');
const { createPersistence } = require('./persist');

const PORT = Number(process.env.PORT) || 5050;
const FILE = process.env.DB_FILE || path.join(__dirname, 'local-test.sqlite');

const fileStore = {
  async load() { return fs.existsSync(FILE) ? fs.readFileSync(FILE) : null; },
  async save(bytes) { fs.writeFileSync(`${FILE}.tmp`, bytes); fs.renameSync(`${FILE}.tmp`, FILE); },
};

(async () => {
  const persistence = createPersistence(fileStore);
  await persistence.start();
  const m = require('./app');
  m.hooks.beforeEnd = persistence.saveIfChanged;
  const host = express();
  host.disable('x-powered-by');
  host.use(express.static(path.join(__dirname, '..', 'public')));
  host.use(m.app);
  host.listen(PORT, () => console.log(`WorkTrack (Firebase version, local test) on http://localhost:${PORT}`));
})();

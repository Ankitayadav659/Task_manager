// Copies ALL data from the office version (data/taskmanager.db) into one file that can be
// uploaded to Firebase Storage as  worktrack/taskmanager.sqlite
// Run with:  EXPORT-Data-For-Firebase.bat   (works while the office app is running)
const fs = require('fs');
const path = require('path');
const { DatabaseSync } = require('node:sqlite');

const src = path.join(__dirname, '..', 'data', 'taskmanager.db');
const outDir = path.join(__dirname, 'upload-to-firebase');
const out = path.join(outDir, 'taskmanager.sqlite');

if (!fs.existsSync(src)) { console.log('No office data found at', src); process.exit(1); }
fs.mkdirSync(outDir, { recursive: true });
fs.rmSync(out, { force: true });

const db = new DatabaseSync(src);
db.exec(`VACUUM INTO '${out.replace(/'/g, "''")}'`);
db.close();

// single-file mode (no WAL) so it opens in the cloud
const copy = new DatabaseSync(out);
copy.exec('PRAGMA journal_mode = DELETE;');
const ok = Object.values(copy.prepare('PRAGMA integrity_check').get())[0];
const n = (t) => copy.prepare(`SELECT COUNT(*) AS c FROM ${t}`).get().c;
console.log(`Exported: ${n('users')} users, ${n('tasks')} tasks, ${n('task_comments')} comments, ${n('leaves')} leave entries (integrity ${ok})`);
copy.close();
console.log(`\nFile ready:\n  ${out}\n\nUpload it in Firebase console -> Storage -> folder "worktrack" (name must stay taskmanager.sqlite).`);
